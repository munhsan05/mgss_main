# Generates src/lib/school-data.ts and public/img/staff/*.jpg from the teachers docx.
import sys, re, json, os
import docx
from docx.oxml.ns import qn
from PIL import Image

SRC, MEDIA, PROJ = sys.argv[1], sys.argv[2], sys.argv[3]
OUT_TS = os.path.join(PROJ, 'src/lib/school-data.ts')
OUT_IMG = os.path.join(PROJ, 'public/img/staff')
os.makedirs(OUT_IMG, exist_ok=True)

PHOTO = {3:'m-sugar',4:'j-saranchimeg',5:'m-tsogzolmaa',6:'j-jadambaa',7:'b-davaamaa',
 8:'l-tserenlkhundev',9:'s-mergenbaatar',10:'ch-dashdulam',11:'kh-oyunchimeg',
 12:'d-tungalag',13:'sh-amarbat',14:'b-oyungerel',15:'e-narantuya',16:'m-bayartsetseg',
 17:'s-mergenbaatar-2',18:'j-orkhon',19:'g-ulziijargal',20:'b-byambasuren',21:'n-dolgorsuren',22:'b-delgermaa',
 23:'j-jadambaa-2',24:'e-narantuya-2',25:'n-dolgorsuren-2',26:'l-tserenlkhundev-2',27:'ch-lkhagvasuren',
 28:'j-saranchimeg-2',29:'sh-amarbat-2',30:'s-ochirdulam',31:'d-naranjargal',32:'d-khishigsuren',
 33:'b-lkhagvasuren',34:'n-tseveen',35:'n-batjargal',36:'ts-bulgan',37:'j-sergelen',38:'g-dogsomsuren',
 39:'n-nansalmaa',40:'b-dolgormaa',41:'ts-norjmoo',42:'b-oyungerel-2',44:'d-lkhagvadorj',45:'g-orkhonzaya',
 46:'m-erdenechuluun',47:'d-maralmaa',48:'b-ichinnorov',49:'g-tserenchimed',50:'g-ganbold',51:'j-uuriintsolmon',
 52:'b-tumurdulam',53:'d-unenbayar',54:'ch-adyasuren',
 55:'m-bayartsetseg-2',56:'sh-amarbat-3',57:'n-narmandakh',58:'n-davaadorj',59:'ts-sunjidmaa',60:'u-enkh-orgil',
 61:'a-tserenlkhagva',62:'u-odjargal',63:'o-munkhtsetseg',64:'g-orkhonzaya-2',65:'p-gantuya',66:'u-byambanasan',
 67:'j-uuriintsolmon-2',68:'m-sainzaya',69:'b-lkhagvasuren-2',70:'j-sergelen-2',71:'s-dulamsuren',72:'j-munkhzolboo'}
MANUAL_CROP = {32: (440, 112, 790, 368), 5: (100, 75, 590, 400)}
ROTATE = {32: 90, 5: -90}  # both scans are stored on their side

# ---------- images ----------
def process_image(num):
    fn = [f for f in os.listdir(MEDIA) if re.fullmatch(rf'image{num}\.\w+', f)][0]
    im = Image.open(os.path.join(MEDIA, fn)).convert('RGB')
    if num in MANUAL_CROP:
        im = im.crop(MANUAL_CROP[num])
        if num in ROTATE: im = im.rotate(ROTATE[num], expand=True)
    else:
        # trim white margins
        px = im.point(lambda v: 255 if v < 235 else 0).convert('L')
        bb = px.getbbox()
        if bb and (bb[2]-bb[0]) > im.width*0.3 and (bb[3]-bb[1]) > im.height*0.3:
            im = im.crop(bb)
    w, h = im.size
    if w*4 > h*3:   # too wide -> center crop
        nw = h*3//4; x = (w-nw)//2; im = im.crop((x, 0, x+nw, h))
    elif h*3 > w*4:  # too tall -> crop from near the top
        nh = w*4//3; y = int((h-nh)*0.12); im = im.crop((0, y, w, y+nh))
    im = im.resize((480, 640), Image.LANCZOS)
    out = f'{PHOTO[num]}.jpg'
    im.save(os.path.join(OUT_IMG, out), 'JPEG', quality=82, optimize=True)
    return '/img/staff/' + out

photo_path = {n: process_image(n) for n in PHOTO}
print('images:', len(photo_path))

# ---------- docx ----------
d = docx.Document(SRC)
rels = {r.rId: r.target_ref for r in d.part.rels.values()}
def imgs_of(el):
    out = []
    for blip in el.iter(qn('a:blip')):
        t = rels.get(blip.get(qn('r:embed')), '')
        m = re.search(r'image(\d+)\.', t)
        if m: out.append(int(m.group(1)))
    return out
def ptext(p): return ''.join(t.text or '' for t in p.iter(qn('w:t')))
def clean(s): return re.sub(r'\s+', ' ', s).strip()

items = []  # ('p', text, imgs) | ('tbl', rows, [])
for child in d.element.body.iterchildren():
    tag = child.tag.split('}')[1]
    if tag == 'p':
        items.append(('p', clean(ptext(child)), imgs_of(child)))
    elif tag == 'tbl':
        rows = []
        for tr in child.iter(qn('w:tr')):
            rows.append([clean(' / '.join(ptext(p) for p in tc.findall(qn('w:p')))) for tc in tr.findall(qn('w:tc'))])
        items.append(('tbl', rows, []))

def find(text):
    for i, it in enumerate(items):
        if it[0] == 'p' and it[1].startswith(text): return i
    raise KeyError(text)

# ---------- years normalisation ----------
def years(s):
    s = clean(s)
    s = re.sub(r'(\d{4})\s*[-–]?\s*он(оос|осс)', r'\1 оноос', s)
    s = re.sub(r'(\d{4})\s*[-–]\s*оос', r'\1 оноос', s)
    s = re.sub(r'(\d{4})\s*[-–]\s*(\d{4})', r'\1–\2', s)
    s = re.sub(r'\s*,\s*/?\s*', ', ', s)
    s = re.sub(r'\s*[-–]\s*(?=,|$)', '', s)
    s = s.replace(' үүрэг гүйцэтгэгч', ', үүрэг гүйцэтгэгч').replace('(', '').replace(')', '')
    return s.strip(' ,')

# ---------- history paragraphs ----------
i0 = find('МАТЕМАТИКИЙН ГҮНЗГИЙРҮҮЛСЭН СУРГАЛТТАЙ СУРГУУЛЬ ҮҮСЭН')
i1 = find('СУРГУУЛИЙН ДУУ')
HISTORY = [it[1] for it in items[i0+1:i1] if it[0] == 'p' and it[1]]
assert len(HISTORY) == 5, len(HISTORY)

# anthem
i2 = find('Үг, Ая')
ANTHEM_LINES = []
for it in items[i2+1:]:
    if it[0] != 'p' or it[2]: break
    if it[1]: ANTHEM_LINES.append(it[1])
assert len(ANTHEM_LINES) == 18, ANTHEM_LINES
ANTHEM = [ANTHEM_LINES[i:i+6] for i in range(0, 18, 6)]

LOGO = [
  {"t": "Цэнхэр өнгөтэй хос гурвалжин", "d": "МАТЕМАТИК гэдэг үгийн эхний М үсгийг дүрсэлнэ. Бүхий л шинжлэх ухааны хаан болох математик бол манай сургалтын гол цөм гэсэн утгыг илэрхийлнэ."},
  {"t": "Нэг бүтэн, хоёр хагас дугуй", "d": "Багш, хүүхэд, эцэг эх гэсэн санааг дүрсэлнэ. Манай сургуулийн сургалт, хүмүүжлийн ажил багш – сурагч – эцэг эх гэсэн гуравласан холбоонд тулгуурлан явагддаг гэсэн утгыг илэрхийлнэ."},
  {"t": "Цагаан өнгөтэй ном", "d": "Багш, сурагчийн эрдэм боловсролын төлөө гэсэн цэвэр тунгалаг, хиргүй ариун сэтгэлийг илэрхийлнэ."},
  {"t": "Нар, гал", "d": "Эрдэм боловсролын төлөөх бидний хамтын үйл ажиллагаа, сургуулийн хөгжил дэвшил, амжилт бүтээл бүхэн нар адил мандахыг бэлгэднэ."},
  {"t": "Хөх өнгийн дэвсгэр", "d": "Сургууль болоод сурагчдын ирээдүй үүлгүй цэлмэг тэнгэр мэт үүрд бадрангуй гэрэлтэж байг гэсэн утгыг илэрхийлнэ."},
  {"t": "19/97 гэсэн тоо", "d": "Сургууль байгуулагдсан оныг логонд үүрд мөнхөлж, урьдын түүхэн уламжлалаар хойч үеийнхэн нь бахархан дуурайж явахын илэрхийлэл болно."},
]

TIMELINE = [
  {"years": "1997–2005", "label": "Математикийн Гүнзгийрүүлсэн Сургалттай Сургууль", "note": "10 жил"},
  {"years": "2005–2009", "label": "Гүнзгийрүүлсэн Сургалттай Ерөнхий Боловсролын Сургууль", "note": "11 жил"},
  {"years": "2009–2018", "label": "Гүнзгийрүүлсэн Сургалттай Ерөнхий Боловсролын Сургууль", "note": "12 жил"},
  {"years": "2018 оноос", "label": "Ерөнхий боловсролын Гүнзгий сургууль", "note": ""},
]

def P(slug, name, yrs):
    num = [k for k, v in PHOTO.items() if v == slug][0]
    return {"name": name, "photo": photo_path[num], "years": yrs}
LEADERS = [
  {"title": "Захирлууд", "people": [P('m-sugar','М.Сугар','1997–2011'), P('j-saranchimeg','Ж.Саранчимэг','2001–2002, үүрэг гүйцэтгэгч'), P('e-narantuya','Э.Нарантуяа','2011, үүрэг гүйцэтгэгч'), P('m-tsogzolmaa','М.Цогзолмаа','2012'), P('j-jadambaa','Ж.Жадамбаа','2013–2019'), P('b-davaamaa','Б.Даваамаа','2019 оноос')]},
  {"title": "Хичээлийн эрхлэгч, сургалтын менежерүүд", "people": [P('l-tserenlkhundev','Л.Цэрэнлхүндэв','1997–1999'), P('s-mergenbaatar','С.Мэргэнбаатар','1998–2002'), P('ch-dashdulam','Ч.Дашдулам','2002–2007'), P('kh-oyunchimeg','Х.Оюунчимэг','2007–2009'), P('d-tungalag','Д.Тунгалаг','2009–2011'), P('e-narantuya','Э.Нарантуяа','2011–2012, 2013 оноос'), P('sh-amarbat','Ш.Амарбат','2013, үүрэг гүйцэтгэгч'), P('b-oyungerel','Б.Оюунгэрэл','2012–2013, 2015'), P('m-bayartsetseg','М.Баярцэцэг','2022 оноос')]},
  {"title": "Хүмүүжлийн эрхлэгч, нийгмийн ажилтнууд", "people": [P('s-mergenbaatar-2','С.Мэргэнбаатар','2002–2008'), P('j-orkhon','Ж.Орхон','2008–2009'), P('g-ulziijargal','Г.Өлзийжаргал','2009–2011'), P('b-byambasuren','Б.Бямбасүрэн','2011–2014'), P('n-dolgorsuren','Н.Долгорсүрэн','2015 оноос')]},
  {"title": "Сэтгэл зүйч", "people": [P('b-delgermaa','Б.Дэлгэрмаа','2026 оноос')]},
]


FOUNDER = {
  "name": "М.Сугар", "full": "Мөнхдаш Сугар", "role": "Үүсгэн байгуулагч, анхны захирал (1997–2011)", "photo": photo_path[3],
  "honours": ["Алтан гадас одонт", "Улсын математикийн XXXIII олимпиадын мөнгөн медальт", "Аймгийн математикийн олимпиадын 5 удаагийн аварга"],
  "bio": [
    "Хархорин сумын 10 жилийн I сургуулийн математикийн багш, аймгийн математикийн олимпиадын 5 удаагийн аварга. 1997 оны 4-р сард Өвөрхангай аймгийн Хужирт суманд болсон Ц.Дашдоржийн нэрэмжит Улсын математикийн XXXIII олимпиадад Хархорин сумаас анх удаа баг бүрдүүлэн аймгаа төлөөлөн оролцож, баг нь II байрт шалгарч, багш өөрөө мөнгөн медаль хүртсэн нь Хархорин суманд математикийн гүнзгийрүүлсэн сургалттай сургууль байгуулах боломжтойг нотолсон юм.",
    "Шавь нарынх нь олон удаагийн амжилт, Улсын Багшийн Их Сургуулийн математикийн тэнхимийн багш В.Адъяасүрэн, ангийн анд, математикийн багш Н.Дайвий-Од нарын санал санаачилга, сурагч, эцэг эхчүүдийн хүсэлтэд тулгуурлан, аймгийн Засаг дарга О.Батмөнхийн дэмжлэгтэйгээр 1997 онд Математикийн гүнзгийрүүлсэн сургалттай сургуулийг үүсгэн байгуулж, 1997–2011 онд анхны захирлаар нь ажилласан.",
    "1997–1998 оны хичээлийн жилд 6 багш, 2 ажилчин, 137 сурагчтайгаар эхэлсэн энэ сургууль өнөөдөр түүний нэрэмжит Ерөнхий боловсролын гүнзгий сургууль болон үйл ажиллагаагаа үргэлжлүүлж байна.",
  ],
}

# ---------- tables ----------
tables = [it[1] for it in items if it[0] == 'tbl']
assert len(tables) == 3, len(tables)
def parse_groups(rows):
    groups = []
    for r in rows:
        cells = [c for c in r]
        if cells and cells[0] == '№': continue
        nonempty = [c for c in cells if c]
        if len(nonempty) == 1 and not re.fullmatch(r'\d+', nonempty[0]):
            groups.append({"title": nonempty[0].rstrip(':'), "rows": []})
            continue
        if len(cells) < 2: continue
        name = clean(cells[1]) if len(cells) > 1 else ''
        if not name: continue
        yrs = years(cells[2]) if len(cells) > 2 else ''
        groups[-1]["rows"].append({"n": name, "years": yrs})
    return groups
LEADER_HISTORY = parse_groups(tables[0])
TEACHER_HISTORY = parse_groups(tables[1])
WORKER_HISTORY = parse_groups(tables[2])
FIX = {"Жаргалсайхан Мөнхолбоо": "Жаргалсайхан Мөнхзолбоо", "Taiiy Briggs": "Tally Briggs", "Бор Хэнэдэхэв": "Бор Хэнмэдэхэв"}
for g in TEACHER_HISTORY + WORKER_HISTORY + LEADER_HISTORY:
    for r in g["rows"]:
        r["n"] = FIX.get(r["n"], r["n"])
        r["n"] = re.sub(r'\s*-\s*', '-', r["n"]).replace('Ня-Очир', 'Ням-Очир')

# ---------- profiles ----------
KEYS = ['УРГИЙН ОВОГ','ОВОГ','НЭР','ТӨРСӨН ОН','ТӨРСӨН ГАЗАР','ТӨГССӨН СУРГУУЛЬ','МЭРГЭЖИЛ','БОЛОВСРОЛЫН БАЙГУУЛЛАГАД АЖИЛЛАЖ БУЙ ЖИЛ','БОЛОВСРОЛЫН БАЙГУУЛАГАД АЖИЛЛАЖ БУЙ ЖИЛ','ЗЭРЭГ, ЦОЛ','МЭРГЭЖЛИЙН ЗЭРЭГ','МЭРЭЖЛИЙН ЗЭРЭГ','ШАГНАЛ','АЛБАН ТУШААЛ']
KEY_RE = re.compile('(' + '|'.join(re.escape(k) for k in KEYS) + r')\s*:')
NORM = {'БОЛОВСРОЛЫН БАЙГУУЛАГАД АЖИЛЛАЖ БУЙ ЖИЛ':'БОЛОВСРОЛЫН БАЙГУУЛЛАГАД АЖИЛЛАЖ БУЙ ЖИЛ','МЭРЭЖЛИЙН ЗЭРЭГ':'МЭРГЭЖЛИЙН ЗЭРЭГ','ТӨРСӨН ГАЗАР':'ТӨРСӨН ОН'}

def parse_entries(start, end, start_key):
    entries, cur, imgq = [], None, []
    for it in items[start:end]:
        if it[0] != 'p': continue
        text, imgs = it[1], it[2]
        imgq += [n for n in imgs if n in PHOTO]
        if not text: continue
        parts = KEY_RE.split(text)
        if len(parts) == 1:
            if cur and cur.get('_last'): cur[cur['_last']] = clean(cur[cur['_last']] + ' ' + text)
            continue
        if parts[0].strip() and cur and cur.get('_last'): cur[cur['_last']] = clean(cur[cur['_last']] + ' ' + parts[0])
        for k, v in zip(parts[1::2], parts[2::2]):
            k = NORM.get(k, k)
            if k == start_key:
                cur = {'_img': imgq.pop(0) if imgq else None}
                entries.append(cur)
            cur[k] = clean(v); cur['_last'] = k
    return entries

def tc(s): return s.lower().title() if s else ''
def sc(s):
    s = s.lower().strip(); return (s[:1].upper() + s[1:]) if s else ''
def jl(s): return int(re.search(r'\d+', s).group()) if s and re.search(r'\d+', s) else 0

ip0, ip1 = find('МАНАЙ ХАМТ ОЛОН'), find('2026-2027 ОНЫ ХИЧЭЭЛИЙН ЖИЛ')
raw_profiles = parse_entries(ip0, ip1, 'УРГИЙН ОВОГ')
assert len(raw_profiles) == 31, len(raw_profiles)
PROFILES = []
for e in raw_profiles:
    sur, giv = tc(e.get('ОВОГ', '')), tc(e.get('НЭР', ''))
    if not sur and giv == 'Ганболд': sur = 'Гэндэн'
    assert sur and giv and e['_img'], e
    PROFILES.append({
      "name": f"{sur[0]}.{giv}", "surname": sur, "given": giv, "clan": tc(e.get('УРГИЙН ОВОГ', '')),
      "photo": photo_path[e['_img']], "born": e.get('ТӨРСӨН ОН', '').rstrip('.'), "school": e.get('ТӨГССӨН СУРГУУЛЬ', '').rstrip(','),
      "profession": re.sub(r'\s*-\s*', '-', e.get('МЭРГЭЖИЛ', '')), "years": jl(e.get('БОЛОВСРОЛЫН БАЙГУУЛЛАГАД АЖИЛЛАЖ БУЙ ЖИЛ', '')),
      "degree": e.get('ЗЭРЭГ, ЦОЛ', ''), "rank": e.get('МЭРГЭЖЛИЙН ЗЭРЭГ', ''), "awards": e.get('ШАГНАЛ', '').rstrip('.'),
    })

raw_staff = parse_entries(ip1, len(items), 'ОВОГ')
assert len(raw_staff) == 26, len(raw_staff)
raw_staff[1]['ОВОГ'], raw_staff[1]['НЭР'] = 'ЭНХТУЯА', 'НАРАНТУЯА'   # docx repeats the director's name on the manager card; photo + table say Э.Нарантуяа
raw_staff[4]['НЭР'] = 'ДЭЛГЭРМАА'
STAFF = []
for e in raw_staff:
    sur, giv = tc(e['ОВОГ']), tc(e['НЭР'])
    assert e['_img'], e
    pos = sc(e.get('АЛБАН ТУШААЛ', ''))
    prof = sc(e.get('МЭРГЭЖИЛ', ''))
    STAFF.append({
      "name": f"{sur[0]}.{giv}", "surname": sur, "given": giv, "photo": photo_path[e['_img']],
      "role": pos or prof, "profession": prof, "position": pos, "degree": sc(e.get('МЭРГЭЖЛИЙН ЗЭРЭГ', '')),
      "years": jl(e.get('БОЛОВСРОЛЫН БАЙГУУЛЛАГАД АЖИЛЛАЖ БУЙ ЖИЛ', '')),
    })

# ---------- write TS ----------
def J(v): return json.dumps(v, ensure_ascii=False, indent=2)
ts = f'''// GENERATED from "Багш нарын танилцуулга зурагтай.docx" — edit the docx and re-run the generator rather than hand-editing.
// Static school facts: history, anthem, logo, leaders, 2026–2027 staff, detailed bios and staff history by subject.

export type Person = {{ name: string; photo: string; years: string }};
export type LeaderGroup = {{ title: string; people: Person[] }};
export type StaffMember = {{
  name: string; surname: string; given: string; photo: string;
  /** Shown under the name: position for leaders, profession for teachers. */
  role: string; profession: string; position: string; degree: string; years: number;
}};
export type Profile = {{
  name: string; surname: string; given: string; clan: string; photo: string; born: string; school: string;
  profession: string; years: number; degree: string; rank: string; awards: string;
}};
export type HistoryRow = {{ n: string; years: string }};
export type HistoryGroup = {{ title: string; rows: HistoryRow[] }};

export const FOUNDED = 1997;
export const SCHOOL_NAME = "Ерөнхий боловсролын гүнзгий сургууль";
export const ANTHEM_TITLE = "Миний сургууль";
export const ANTHEM_AUTHOR = "Үг, ая: Ш.Амарбат";

/** Founding history, one paragraph each. */
export const HISTORY: string[] = {J(HISTORY)};

export const TIMELINE: {{ years: string; label: string; note: string }}[] = {J(TIMELINE)};

/** School anthem, three stanzas. */
export const ANTHEM: string[][] = {J(ANTHEM)};

export const LOGO_MEANING: {{ t: string; d: string }}[] = {J(LOGO)};

export const LEADERS: LeaderGroup[] = {J(LEADERS)};

/** М.Сугар — founder and first director. Facts come from the founding-history text. */
export const FOUNDER: {{ name: string; full: string; role: string; photo: string; honours: string[]; bio: string[] }} = {J(FOUNDER)};

/** 2026–2027 хичээлийн жилийн удирдах ажилтан, багш нар (in the order of the source document). */
export const STAFF: StaffMember[] = {J(STAFF)};

export const STAFF_BY_NAME: Record<string, StaffMember> = Object.fromEntries(STAFF.map((s) => [s.name, s]));

/** Detailed bios ("Манай хамт олон"). */
export const PROFILES: Profile[] = {J(PROFILES)};

export const LEADER_HISTORY: HistoryGroup[] = {J(LEADER_HISTORY)};
export const TEACHER_HISTORY: HistoryGroup[] = {J(TEACHER_HISTORY)};
export const WORKER_HISTORY: HistoryGroup[] = {J(WORKER_HISTORY)};
'''
open(OUT_TS, 'w', encoding='utf-8', newline='\n').write(ts)
print('wrote', OUT_TS, len(ts), 'chars; staff', len(STAFF), 'profiles', len(PROFILES),
      'groups', len(LEADER_HISTORY), len(TEACHER_HISTORY), len(WORKER_HISTORY))
