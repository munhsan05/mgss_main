import type { NextConfig } from "next";

// Cache Components is off on purpose: almost every page depends on the
// signed-in user (Supabase session cookie + RLS), so pages render per request.
const nextConfig: NextConfig = {
  turbopack: {
    rules: {
      "*.css": {
        loaders: ["@tailwindcss/turbopack"],
        as: "*.css",
      },
    },
  },
  experimental: {
    serverActions: { bodySizeLimit: "2mb" },
  },
};

export default nextConfig;
