// Data access layer: every read goes through here. Runs on the server only and
// returns trimmed objects, so private fields (hidden phone numbers, job
// contacts for anonymous visitors, other users' ids) never reach the browser.
import "server-only";
import { cache } from "react";
import { createClient, supabaseConfigured } from "./supabase/server";
import { mergeContent, type Content } from "./content";

export type Viewer = {
  user: { id: string; email: string } | null;
  me: Profile | null;
  isAdmin: boolean;
};

export type Profile = {
  id: string;
  name: string;
  year: number;
  cat: string;
  job: string;
  org: string;
  loc: string;
  /** null when the viewer may not see it (anonymous, or the owner hid it). */
  phone: string | null;
  hide: boolean;
  tags: string[];
  fb: string;
  ig: string;
  photo: string;
  status: "pending" | "approved";
  createdAt: string;
  isMine: boolean;
};

export type EventItem = {
  id: string; date: string; type: string; title: string; place: string; descr: string;
  proposed: boolean; createdAt: string; going: number; myGoing: boolean; isMine: boolean;
};

export type Voice = {
  id: string; type: string; text: string; by: string; status: string; reply: string;
  createdAt: string; votes: number; myVote: boolean; isMine: boolean;
};

export type Job = {
  id: string; type: string; title: string; org: string; loc: string;
  /** null for anonymous visitors. */
  contact: string | null;
  descr: string; deadline: string | null; createdAt: string; isMine: boolean;
};

export type Booking = {
  id: string; name: string; phone: string; year: number | null; seats: number; note: string; status: string; createdAt: string;
};

type Row = Record<string, unknown>;
const s = (v: unknown) => (v == null ? "" : String(v));

export const getSupabase = cache(async () => (supabaseConfigured() ? createClient() : null));

/** Who is looking: auth user (verified with the Auth server), own profile, admin flag. */
export const getViewer = cache(async (): Promise<Viewer> => {
  const sb = await getSupabase();
  if (!sb) return { user: null, me: null, isAdmin: false };
  const { data } = await sb.auth.getUser();
  const u = data.user;
  if (!u) return { user: null, me: null, isAdmin: false };
  const [{ data: prof }, { data: admin }] = await Promise.all([
    sb.from("profiles").select("*").eq("user_id", u.id).maybeSingle(),
    sb.rpc("is_admin"),
  ]);
  const user = { id: u.id, email: u.email ?? "" };
  return { user, me: prof ? toProfile(prof, u.id, true, !!admin) : null, isAdmin: !!admin };
});

function toProfile(r: Row, viewerId: string | null, loggedIn: boolean, isAdmin: boolean): Profile {
  const isMine = !!viewerId && r.user_id === viewerId;
  const hide = !!r.hide;
  const canSeePhone = loggedIn && (!hide || isMine || isAdmin);
  return {
    id: s(r.id), name: s(r.name), year: Number(r.year) || 0, cat: s(r.cat), job: s(r.job), org: s(r.org), loc: s(r.loc),
    phone: canSeePhone ? s(r.phone) || null : null, hide, tags: Array.isArray(r.tags) ? (r.tags as string[]) : [],
    fb: s(r.fb), ig: s(r.ig), photo: s(r.photo), status: r.status === "approved" ? "approved" : "pending",
    createdAt: s(r.created_at), isMine,
  };
}

export const getContent = cache(async (): Promise<Content> => {
  const sb = await getSupabase();
  if (!sb) return mergeContent({});
  const { data, error } = await sb.from("site_content").select("key,data");
  if (error) console.error("[data] site_content:", error.message);
  const raw: Row = {};
  (data || []).forEach((r) => (raw[r.key as string] = r.data));
  return mergeContent(raw);
});

/** Profiles the viewer may see. Public pages show approved ones only. */
export const getPeople = cache(async (): Promise<Profile[]> => {
  const sb = await getSupabase();
  if (!sb) return [];
  const v = await getViewer();
  const cols = "id,user_id,name,year,cat,job,org,loc,tags,hide,fb,ig,photo,status,created_at" + (v.user ? ",phone" : "");
  const { data, error } = await sb.from("profiles").select(cols).order("created_at");
  if (error) console.error("[data] profiles:", error.message);
  return ((data || []) as unknown as Row[]).map((r) => toProfile(r, v.user?.id ?? null, !!v.user, v.isAdmin));
});

export const getApprovedPeople = cache(async () => (await getPeople()).filter((p) => p.status === "approved"));

export const getEvents = cache(async (): Promise<EventItem[]> => {
  const sb = await getSupabase();
  if (!sb) return [];
  const v = await getViewer();
  const [{ data: events, error }, { data: counts }, mine] = await Promise.all([
    sb.from("events").select("*").order("date"),
    sb.from("event_going_counts").select("*"),
    v.user ? sb.from("rsvps").select("event_id").eq("user_id", v.user.id) : Promise.resolve({ data: [] as Row[] }),
  ]);
  const n: Record<string, number> = {};
  (counts || []).forEach((c) => (n[c.event_id as string] = Number(c.n)));
  if (error) console.error("[data] events:", error.message);
  const going = new Set((mine.data || []).map((r) => r.event_id as string));
  return (events || []).map((r) => ({
    id: s(r.id), date: s(r.date), type: s(r.type), title: s(r.title), place: s(r.place), descr: s(r.descr),
    proposed: !!r.proposed, createdAt: s(r.created_at), going: n[r.id] || 0, myGoing: going.has(r.id),
    isMine: !!v.user && r.created_by === v.user.id,
  }));
});

export const getVoices = cache(async (): Promise<Voice[]> => {
  const sb = await getSupabase();
  if (!sb) return [];
  const v = await getViewer();
  const [{ data: voices, error }, { data: counts }, mine] = await Promise.all([
    sb.from("voices").select("*").order("created_at", { ascending: false }),
    sb.from("voice_vote_counts").select("*"),
    v.user ? sb.from("voice_votes").select("voice_id").eq("user_id", v.user.id) : Promise.resolve({ data: [] as Row[] }),
  ]);
  const n: Record<string, number> = {};
  (counts || []).forEach((c) => (n[c.voice_id as string] = Number(c.n)));
  if (error) console.error("[data] voices:", error.message);
  const voted = new Set((mine.data || []).map((r) => r.voice_id as string));
  return (voices || []).map((r) => ({
    id: s(r.id), type: s(r.type), text: s(r.text), by: s(r.by_name), status: s(r.status) || "Шинэ", reply: s(r.reply),
    createdAt: s(r.created_at), votes: n[r.id] || 0, myVote: voted.has(r.id), isMine: !!v.user && r.user_id === v.user.id,
  }));
});

export const getJobs = cache(async (): Promise<Job[]> => {
  const sb = await getSupabase();
  if (!sb) return [];
  const v = await getViewer();
  const { data, error } = await sb.from("jobs").select("*").order("created_at", { ascending: false });
  if (error) console.error("[data] jobs:", error.message);
  return (data || []).map((r) => ({
    id: s(r.id), type: s(r.type) || "Ажил", title: s(r.title), org: s(r.org), loc: s(r.loc),
    contact: v.user ? s(r.contact) : null, descr: s(r.descr), deadline: r.deadline ? s(r.deadline) : null,
    createdAt: s(r.created_at), isMine: !!v.user && r.created_by === v.user.id,
  }));
});

export const getNySeatsBooked = cache(async (): Promise<number> => {
  const sb = await getSupabase();
  if (!sb) return 0;
  const { data } = await sb.rpc("ny_seats_booked");
  return Number(data) || 0;
});

/** Admin only (RLS returns just the viewer's own rows otherwise). */
export const getBookings = cache(async (): Promise<Booking[]> => {
  const sb = await getSupabase();
  if (!sb) return [];
  const { data } = await sb.from("ny_bookings").select("*").order("created_at", { ascending: false });
  return (data || []).map((r) => ({
    id: s(r.id), name: s(r.name), phone: s(r.phone), year: r.year ? Number(r.year) : null, seats: Number(r.seats) || 1,
    note: s(r.note), status: s(r.status) || "pending", createdAt: s(r.created_at),
  }));
});

/** Admin view of every profile, phone included (RLS lets admins read all). */
export const getAllProfilesForAdmin = cache(async () => {
  const sb = await getSupabase();
  if (!sb) return [];
  const { data } = await sb.from("profiles").select("*").order("created_at", { ascending: false });
  return (data || []).map((r) => ({ ...toProfile(r, null, true, true), userId: r.user_id ? s(r.user_id) : null }));
});
