// Editable school content (site_content key "school"). The defaults come from the
// docx-generated modules, so the site works before anything is saved in Supabase;
// once the admin saves a section, that section comes from the database.
import { ANTHEM, ANTHEM_AUTHOR, ANTHEM_TITLE, HISTORY, LEADERS, LEADER_HISTORY, LOGO_MEANING, PROFILES, TEACHER_HISTORY, WORKER_HISTORY } from "./school-data";
import { ACHIEVEMENTS, ALUMNI, BUILDINGS, CLOSING, DIRECTORS, EESH_RESULTS, ENVIRONMENT, HISTORY_PHOTOS, INTERNATIONAL, KEY_FIGURES, MILESTONES, NAME_CHANGES, OLYMPIAD } from "./school-history";

export type Pic = { src: string; cap: string };
export type Director = { name: string; full: string; years: string; title: string; photo: string; intro: string; career: string[]; awards: string };
/** A titled text block with photos: buildings, olympiad, alumni association, environment. */
export type Block = { pill: string; title: string; text: string[]; photos: Pic[] };
export type ListCol = { title: string; rows: string[] };
export type LeaderGroup = { title: string; people: { name: string; photo: string; years: string }[] };
export type Profile = {
  name: string; surname: string; given: string; clan: string; photo: string; born: string; school: string;
  profession: string; years: number; degree: string; rank: string; awards: string;
};
export type HistGroup = { section: string; title: string; rows: { n: string; years: string }[] };

export type SchoolContent = {
  history: string[];
  historyPhotos: Pic[];
  closing: string;
  milestones: { year: string; t: string; d: string }[];
  keyFigures: { v: string; l: string }[];
  nameChanges: { years: string; decision: string; name: string }[];
  directors: Director[];
  buildings: Block[];
  olympiad: Block;
  alumni: Block;
  achievements: ListCol[];
  environment: Block;
  logoMeaning: { t: string; d: string }[];
  anthem: { title: string; author: string; stanzas: string[][] };
  leaders: LeaderGroup[];
  profiles: Profile[];
  staffHistory: HistGroup[];
  historyAlbum: Pic[];
};

export const SCHOOL_KEYS = [
  "history", "historyPhotos", "closing", "milestones", "keyFigures", "nameChanges", "directors", "buildings", "olympiad", "alumni",
  "achievements", "environment", "logoMeaning", "anthem", "leaders", "profiles", "staffHistory", "historyAlbum",
] as const satisfies readonly (keyof SchoolContent)[];
export type SchoolKey = (typeof SCHOOL_KEYS)[number];

export const SCHOOL_SECTION_LABELS: Record<SchoolKey, string> = {
  history: "Үүсэл түүх (догол мөр бүр)", historyPhotos: "Түүхийн хэсгийн зургууд", closing: "Төгсгөлийн өгүүлбэр",
  milestones: "Он дараалал (түүхэн үеүүд)", keyFigures: "Тоон үзүүлэлт", nameChanges: "Нэрийн өөрчлөлт",
  directors: "Үе үеийн захирлууд", buildings: "Хичээлийн байр", olympiad: "М.Сугар багшийн нэрэмжит олимпиад", alumni: "Төгсөгчдийн холбоо",
  achievements: "Амжилт (3 багана)", environment: "Сургалтын орчин", logoMeaning: "Логоны утга", anthem: "Сүлд дуу",
  leaders: "Үе үеийн удирдлагууд (зурагтай)", profiles: "Багш, ажилтнуудын намтар", staffHistory: "Үе үеийн багш, ажиллагсад (хүснэгт)", historyAlbum: "Түүхэн зургийн цомог",
};

export const DEFAULT_SCHOOL: SchoolContent = {
  history: HISTORY,
  historyPhotos: HISTORY_PHOTOS.slice(0, 2),
  closing: CLOSING,
  milestones: MILESTONES,
  keyFigures: KEY_FIGURES.map(([v, l]) => ({ v, l })),
  nameChanges: NAME_CHANGES,
  directors: DIRECTORS,
  buildings: [
    { pill: "2000–2019", title: BUILDINGS.old.title, text: [BUILDINGS.old.text], photos: [{ src: BUILDINGS.old.photo, cap: BUILDINGS.old.cap }] },
    { pill: "2019 оноос", title: BUILDINGS.new.title, text: [BUILDINGS.new.text], photos: [{ src: BUILDINGS.new.photo, cap: BUILDINGS.new.cap }] },
    { pill: "2020–2021", title: BUILDINGS.naming.title, text: [BUILDINGS.naming.text], photos: BUILDINGS.naming.photos },
  ],
  olympiad: { pill: "2001 оноос", title: OLYMPIAD.title, text: OLYMPIAD.text, photos: [{ src: OLYMPIAD.photo, cap: OLYMPIAD.cap }] },
  alumni: { pill: "2011 оноос", title: ALUMNI.title, text: ALUMNI.text, photos: [{ src: ALUMNI.photo, cap: ALUMNI.cap }] },
  achievements: [
    { title: "Байгууллагын амжилт", rows: ACHIEVEMENTS },
    { title: "Элсэлтийн ерөнхий шалгалт", rows: EESH_RESULTS },
    { title: "Олимпиад, спорт, урлаг", rows: INTERNATIONAL },
  ],
  environment: { pill: "Хөрөнгө оруулалт", title: ENVIRONMENT.title, text: [ENVIRONMENT.text], photos: ENVIRONMENT.photos },
  logoMeaning: LOGO_MEANING,
  anthem: { title: ANTHEM_TITLE, author: ANTHEM_AUTHOR, stanzas: ANTHEM },
  leaders: LEADERS,
  profiles: PROFILES,
  staffHistory: [
    ...LEADER_HISTORY.map((g) => ({ section: "Удирдлагууд", ...g })),
    ...TEACHER_HISTORY.map((g) => ({ section: "Багш нар", ...g })),
    ...WORKER_HISTORY.map((g) => ({ section: "Ажилчид", ...g })),
  ],
  historyAlbum: HISTORY_PHOTOS,
};

/** Stored sections override the defaults one key at a time (a section is saved whole). */
export function mergeSchool(raw: unknown): SchoolContent {
  const out = { ...DEFAULT_SCHOOL };
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) return out;
  const r = raw as Record<string, unknown>;
  for (const k of SCHOOL_KEYS) {
    const v = r[k];
    const d = DEFAULT_SCHOOL[k];
    if (v === undefined || v === null) continue;
    if (Array.isArray(d) ? Array.isArray(v) : typeof v === typeof d) (out as Record<string, unknown>)[k] = v;
  }
  return out;
}

/** Group staff-history rows back into their page sections, in first-seen order. */
export function groupStaffHistory(groups: HistGroup[]): { section: string; groups: HistGroup[] }[] {
  const out: { section: string; groups: HistGroup[] }[] = [];
  for (const g of groups) {
    const s = out.find((x) => x.section === g.section) || (out.push({ section: g.section, groups: [] }), out[out.length - 1]);
    s.groups.push(g);
  }
  return out;
}
