// Browser-side photo shrinking before upload.
//  - avatar:  320×320 square crop (shown as 46–52 px circles; sharp on 3× screens)
//  - gallery: longest side 1600 px (sharp full-screen on phones and laptops)
// WebP at quality 0.82 (falls back to JPEG if the browser can't encode WebP).
// Big originals are halved step by step with high-quality smoothing, which
// avoids the jagged/grainy look of one huge downscale.

export type ResizeMode = "avatar" | "gallery";

const QUALITY = 0.82;

export async function resizeImage(file: File, mode: ResizeMode): Promise<Blob> {
  if (!file.type.startsWith("image/")) throw new Error("Зөвхөн зураг оруулна уу.");
  const bmp = await decode(file);

  // Source rectangle and target size.
  let sx = 0, sy = 0, sw = bmp.width, sh = bmp.height, tw: number, th: number;
  if (mode === "avatar") {
    const k = Math.min(bmp.width, bmp.height);
    sx = (bmp.width - k) / 2; sy = (bmp.height - k) / 2; sw = sh = k;
    tw = th = Math.min(320, k);
  } else {
    const scale = Math.min(1, 1600 / Math.max(bmp.width, bmp.height));
    tw = Math.round(bmp.width * scale); th = Math.round(bmp.height * scale);
  }

  // Step down by halves until within 2× of the target, then draw the final size.
  let src: CanvasImageSource = bmp, cw = sw, ch = sh, cx = sx, cy = sy;
  while (cw / 2 >= tw * 2 && ch / 2 >= th * 2) {
    const c = canvas(Math.round(cw / 2), Math.round(ch / 2));
    draw(c, src, cx, cy, cw, ch);
    src = c; cx = 0; cy = 0; cw = c.width; ch = c.height;
  }
  const out = canvas(tw, th);
  draw(out, src, cx, cy, cw, ch);
  bmp.close?.();

  const webp = await toBlob(out, "image/webp", QUALITY);
  if (webp && webp.type === "image/webp" && webp.size <= SOFT_MAX) return webp;
  // Safari may not encode WebP: fall back to JPEG, lowering quality for very detailed photos.
  let jpeg = await toBlob(out, "image/jpeg", QUALITY);
  if (jpeg && jpeg.size > SOFT_MAX) jpeg = await toBlob(out, "image/jpeg", 0.7);
  if (!jpeg) throw new Error("Зургийг хөрвүүлж чадсангүй.");
  return jpeg;
}

const SOFT_MAX = 900 * 1024; // server limit is 1 MB

type Decoded = { width: number; height: number } & CanvasImageSource & { close?: () => void };

/** Decodes with the phone's rotation applied, trying the most capable API first. */
async function decode(file: File): Promise<Decoded> {
  try {
    return await createImageBitmap(file, { imageOrientation: "from-image" });
  } catch {}
  try {
    return await createImageBitmap(file); // older Safari rejects the options argument
  } catch {}
  // Last resort: <img> (browsers apply EXIF rotation to images by default).
  const url = URL.createObjectURL(file);
  try {
    const img = new Image();
    img.src = url;
    await img.decode();
    return Object.assign(img, { width: img.naturalWidth, height: img.naturalHeight });
  } catch {
    throw new Error("Зургийг уншиж чадсангүй. (HEIC бол JPEG болгож хадгалаад дахин оролдоно уу.)");
  } finally {
    URL.revokeObjectURL(url);
  }
}

function canvas(w: number, h: number) {
  const c = document.createElement("canvas");
  c.width = w; c.height = h;
  return c;
}

function draw(dst: HTMLCanvasElement, src: CanvasImageSource, sx: number, sy: number, sw: number, sh: number) {
  const ctx = dst.getContext("2d")!;
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "high";
  ctx.drawImage(src, sx, sy, sw, sh, 0, 0, dst.width, dst.height);
}

const toBlob = (c: HTMLCanvasElement, type: string, q: number) => new Promise<Blob | null>((r) => c.toBlob(r, type, q));

/** Resize + POST to /api/upload. Returns the stored R2 path. */
export async function uploadPhoto(file: File, kind: "avatar" | "gallery" | "cohort"): Promise<string> {
  const blob = await resizeImage(file, kind === "avatar" ? "avatar" : "gallery");
  const fd = new FormData();
  fd.append("kind", kind);
  fd.append("file", blob, blob.type === "image/webp" ? "photo.webp" : "photo.jpg");
  const res = await fetch("/api/upload", { method: "POST", body: fd });
  const json = (await res.json().catch(() => ({}))) as { path?: string; error?: string };
  if (!res.ok || !json.path) throw new Error(json.error || "Зураг хадгалагдсангүй.");
  return json.path;
}
