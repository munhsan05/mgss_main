// Photo albums shown under /gallery: admin-made albums plus albums derived from
// content that already exists elsewhere (New Year gallery, class photos).
import type { Content, GalleryItem } from "./content";

export type AlbumView = { id: string; title: string; date: string; cover: string; photos: GalleryItem[]; auto: boolean };

export function buildAlbums(c: Content): AlbumView[] {
  const list: AlbumView[] = c.albums
    .filter((a) => a && a.id && a.title)
    .map((a) => ({ ...a, photos: (a.photos || []).filter((g) => g && g.src), cover: a.cover || a.photos?.[0]?.src || "", auto: false }))
    .sort((a, b) => (b.date || "").localeCompare(a.date || ""));

  const ny = (c.ny.gallery || []).filter((g) => g && g.src);
  if (ny.length) list.push({ id: "ny", title: `Шинэ жилийн үдэшлэг`, date: c.ny.year ? String(c.ny.year) : "", cover: ny[0].src, photos: ny, auto: true });

  const cohorts = Object.entries(c.cohorts)
    .filter(([, v]) => v && v.photo)
    .sort(([a], [b]) => Number(b) - Number(a))
    .map(([y, v]) => ({ src: v.photo, cap: `${y} оны төгсөгчид` }));
  if (cohorts.length) list.push({ id: "cohorts", title: "Үе үеийн ангийн зургууд", date: "", cover: cohorts[0].src, photos: cohorts, auto: true });

  const hist = (c.school.historyAlbum || []).filter((g) => g && g.src);
  if (hist.length) list.push({ id: "history", title: "Сургуулийн түүхэн зургууд", date: "1997–2026", cover: (hist[3] || hist[0]).src, photos: hist, auto: true });
  return list;
}

export const findAlbum = (c: Content, id: string) => buildAlbums(c).find((a) => a.id === id);
