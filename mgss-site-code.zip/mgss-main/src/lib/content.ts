// site_content JSON shapes + defaults. Shapes match mgss1 exactly so the
// existing Supabase data loads unchanged.
import type { Match } from "./sports";
import { STAFF } from "./school-data";
import { DEFAULT_SCHOOL, mergeSchool, type SchoolContent } from "./school-content";

export type Site = { heroTitle: string; heroLead: string; schoolIntro: string; contactEmail: string; contactPhone: string };
export type EeshRow = { label: string; v: string; pct: number; c: string; note: string };
export type Teacher = { id: string; n: string; s: string; photo?: string; degree?: string; years?: number };
export type NyProgramItem = { t: string; l: string };
export type GalleryItem = { src: string; cap: string };
export type Album = { id: string; title: string; date: string; cover: string; photos: GalleryItem[] };
export type Ny = {
  on: boolean; title: string; year: string | number; date: string; place: string; address: string; organizer: string;
  price: string; priceNote: string; bankName: string; bankAccount: string; bankHolder: string; payNote: string;
  seats: number; program: NyProgramItem[]; gallery: GalleryItem[]; sponsors: { n: string }[];
};
export type Fee = { l: string; v: string };
export type Sport = {
  title: string; season: string; status: string; dates: string; place: string; address: string; organizer: string; intro: string;
  fees: Fee[]; bankName: string; iban: string; bankAccount: string; bankHolder: string; matches: Match[]; updated?: string;
};
export type Sports = { basket: Sport; volley: Sport };
export type Fund = {
  on: boolean; title: string; desc: string; goal: number; raised: number; donors: number;
  bankName: string; bankAccount: string; bankHolder: string; updates: string[];
};
export type Cohort = { photo: string; teacher: string; leader: string; memories: { t: string; by: string }[] };
export type NewsItem = { id: string; date: string; title: string; body: string };

export type Content = {
  site: Site; eesh: EeshRow[]; teachers: Teacher[]; ny: Ny; sports: Sports; fund: Fund;
  cohorts: Record<string, Cohort>; news: NewsItem[]; albums: Album[]; school: SchoolContent;
};
export type ContentKey = keyof Content;
export const CONTENT_KEYS: ContentKey[] = ["site", "eesh", "teachers", "ny", "sports", "fund", "cohorts", "news", "albums", "school"];

const emptySport = (s: Partial<Sport>): Sport => ({
  title: "", season: "", status: "", dates: "", place: "", address: "", organizer: "", intro: "",
  fees: [], bankName: "", iban: "", bankAccount: "", bankHolder: "", matches: [], ...s,
});

export const DEFAULTS: Content = {
  site: {
    heroTitle: "Хархорин МГСС Төгсөгчдийн холбоо",
    heroLead: "",
    schoolIntro:
      "Өвөрхангай аймгийн Хархорин сумын Ерөнхий боловсролын гүнзгий сургууль нь 1997 онд Математикийн гүнзгийрүүлсэн сургалттай сургууль нэртэйгээр М.Сугар захиралтай, 6 багш, 137 сурагчтайгаар үүсэн байгуулагдсан. Зарим хичээлийг гүнзгийрүүлэн заадаг улсын сургууль бөгөөд 10-р ангид 9-р ангийн төгсөгчдөөс сонгон шалгаруулалтаар элсүүлдэг. Сурагчид нь ЭЕШ-д улсын хэмжээнд тогтмол тэргүүлэгчдийн тоонд ордог.",
    contactEmail: "info@alumni.mn",
    contactPhone: "+976 0000 0000",
  },
  eesh: [
    { label: "2025 он", v: "№7", pct: 93, c: "#C42B3B", note: "Дундаж оноогоор улсын шилдэг 60 сургуулийн дунд 7-р байр" },
    { label: "2024 он", v: "611.2", pct: 68, c: "#0D47A8", note: "Дундаж оноогоор улсад 17-р байр" },
    { label: "2016 он", v: "600.2", pct: 67, c: "#0D47A8", note: "Аймагтаа тэргүүлэгч сургуулиудын нэг" },
    { label: "Улсын дундаж", v: "500", pct: 50, c: "#9CA3AF", note: "Харьцуулалтын суурь үзүүлэлт" },
  ],
  // 2026–2027 staff from school-data; the admin list (if saved) overrides this.
  teachers: STAFF.map((t) => ({ id: "teacher-" + t.photo.split("/").pop()!.replace(/\.jpg$/, ""), n: t.name, s: t.role, photo: t.photo, degree: t.degree, years: t.years })),
  ny: {
    on: true, title: "Шинэ жилийн үдэшлэг", year: 2027, date: "2026-12-27T18:00", place: "", address: "", organizer: "",
    price: "", priceNote: "", bankName: "", bankAccount: "", bankHolder: "",
    payNote: "Гүйлгээний утгад нэр, утас, төгссөн оноо бичнэ үү.", seats: 0, program: [], gallery: [], sponsors: [],
  },
  sports: {
    basket: emptySport({
      title: "Төгсөгчдийн сагсан бөмбөгийн аварга шалгаруулах тэмцээн", season: "2026", status: "Бүртгэл нээлттэй",
      dates: "2026 оны 11-р сарын 14, Бямба", place: "Чухаг спорт төв",
      address: "Дүнжингарав худалдааны төвийн замын эсрэг талд", organizer: "2016 оны төгсөлт",
      intro:
        "Төгсөгчид та бүхэн тэмцээндээ идэвхтэй оролцож, 10 жилийн найз нөхөдтэйгөө уулзан, нэг өдрийг хамтдаа дурсамж дүүрэн өнгөрүүлээрэй. Бусад дэлгэрэнгүй мэдээллийг удахгүй хүргэнэ.",
      fees: [
        { l: "2022 он болон түүнээс өмнөх төгсөлтүүд", v: "300,000₮" },
        { l: "2023, 2024, 2025, 2026 оны төгсөлтүүд", v: "150,000₮" },
      ],
    }),
    volley: emptySport({ title: "Гар бөмбөгийн аварга шалгаруулах тэмцээн", status: "Бүртгэл", place: "МГСС-ийн спорт заал" }),
  },
  fund: {
    on: true, title: "Сургуулийн хөгжлийн сан",
    desc: "Төгсөгчдийн хандиваар сурагчдад тэтгэлэг олгож, сургуулийнхаа орчныг сайжруулна.",
    goal: 0, raised: 0, donors: 0, bankName: "", bankAccount: "", bankHolder: "", updates: [],
  },
  cohorts: {},
  news: [],
  albums: [],
  school: DEFAULT_SCHOOL,
};

type Raw = Partial<Record<ContentKey, unknown>>;
const obj = <T,>(v: unknown, d: T): T => (v && typeof v === "object" && !Array.isArray(v) ? { ...d, ...(v as object) } : d);
const arr = <T,>(v: unknown, d: T[]): T[] => (Array.isArray(v) ? (v as T[]) : d);

/** Same merge rules as mgss1: stored values override defaults key by key. */
export function mergeContent(raw: Raw): Content {
  const sports = obj<Partial<Sports>>(raw.sports, {});
  return {
    site: obj(raw.site, DEFAULTS.site),
    eesh: arr(raw.eesh, DEFAULTS.eesh),
    teachers: arr(raw.teachers, DEFAULTS.teachers),
    ny: obj(raw.ny, DEFAULTS.ny),
    sports: { basket: obj(sports.basket, DEFAULTS.sports.basket), volley: obj(sports.volley, DEFAULTS.sports.volley) },
    fund: obj(raw.fund, DEFAULTS.fund),
    cohorts: obj<Record<string, Cohort>>(raw.cohorts, {}),
    news: arr(raw.news, []),
    albums: arr(raw.albums, []),
    school: mergeSchool(raw.school),
  };
}
