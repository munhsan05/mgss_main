/**
 * Turns a stored photo value into a URL.
 * - New uploads store only the R2 path ("avatars/<uid>/<ts>.webp"), joined
 *   with NEXT_PUBLIC_MEDIA_BASE_URL — change provider by changing one setting.
 * - Old mgss1 values (Supabase Storage URLs, pasted links) start with http and
 *   are used as they are.
 */
export function mediaUrl(value: string | null | undefined): string {
  const v = (value || "").trim();
  if (!v) return "";
  if (/^(https?:|data:|\/)/i.test(v)) return v;
  const base = (process.env.NEXT_PUBLIC_MEDIA_BASE_URL || "").replace(/\/+$/, "");
  return base ? `${base}/${v.replace(/^\/+/, "")}` : "";
}

/** True for values that point at our own R2 bucket (safe to delete). */
export const isR2Path = (value: string | null | undefined) => !!value && !/^(https?:|data:|\/)/i.test(value);
