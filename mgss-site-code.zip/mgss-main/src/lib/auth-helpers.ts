import "server-only";
import { headers } from "next/headers";
import type { SupabaseClient, User } from "@supabase/supabase-js";

export type PendingProfile = {
  name: string; year: number; cat: string; job: string; org: string; loc: string; phone: string; tags: string[];
};

/** Site origin for e-mail links (confirm, password reset). */
export async function siteOrigin() {
  const h = await headers();
  const origin = h.get("origin");
  if (origin) return origin;
  const host = h.get("x-forwarded-host") || h.get("host") || "localhost:3000";
  const proto = h.get("x-forwarded-proto") || (host.startsWith("localhost") ? "http" : "https");
  return `${proto}://${host}`;
}

/**
 * The join form's profile is stored in the user's metadata at sign-up and turned
 * into a profiles row on first confirmed sign-in. This replaces mgss1's
 * localStorage trick, so it also works when the e-mail link is opened on
 * another device.
 */
export async function ensureProfile(sb: SupabaseClient, user: User) {
  const pending = (user.user_metadata as { profile?: PendingProfile } | null)?.profile;
  if (!pending) return;
  const { data: existing } = await sb.from("profiles").select("id").eq("user_id", user.id).maybeSingle();
  if (existing) return;
  await sb.from("profiles").insert({
    user_id: user.id, name: pending.name, year: pending.year, cat: pending.cat, job: pending.job,
    org: pending.org || "—", loc: pending.loc || "—", phone: pending.phone, tags: pending.tags || [], hide: false,
  });
}

/** Only allow same-site relative redirects. */
export function safeNext(n: string | null | undefined, fallback = "/dashboard") {
  if (!n || !n.startsWith("/") || n.includes("\\")) return fallback;
  try {
    const u = new URL(n, "http://x");
    return u.origin === "http://x" ? u.pathname + u.search + u.hash : fallback;
  } catch {
    return fallback;
  }
}
