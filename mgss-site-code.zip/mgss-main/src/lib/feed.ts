import "server-only";
import { getContent, getEvents, getJobs } from "./data";

export type FeedItem = { kind: string; color: string; title: string; sub: string; ts: number; href: string };

/** Notification bell: news, events, jobs and the basketball tournament, newest first. */
export async function getFeed(): Promise<FeedItem[]> {
  const [c, events, jobs] = await Promise.all([getContent(), getEvents(), getJobs()]);
  const items: FeedItem[] = [];
  c.news.forEach((n) => items.push({ kind: "Мэдээ", color: "#D7263D", title: n.title, sub: n.body || "", ts: new Date(n.date || 0).getTime(), href: "/#news" }));
  events.forEach((e) => items.push({ kind: "Арга хэмжээ", color: "#3F78E0", title: e.title, sub: [e.date, e.place].filter(Boolean).join(" · "), ts: new Date(e.createdAt || e.date || 0).getTime(), href: "/events" }));
  jobs.forEach((j) => items.push({ kind: j.type || "Ажлын зар", color: "#1B9C85", title: j.title, sub: j.org, ts: new Date(j.createdAt || 0).getTime(), href: "/jobs" }));
  const sb = c.sports.basket;
  if (sb.dates) items.push({ kind: "Тэмцээн", color: "#E07B1F", title: sb.title, sub: `${sb.dates} · ${sb.place}`, ts: new Date(sb.updated || "2026-11-01").getTime(), href: "/#sports" });
  return items.filter((i) => i.title).sort((a, b) => b.ts - a.ts).slice(0, 12);
}
