// Pure helpers ported from mgss1 (no imports, so tests can run them directly).

export const FIRST_YEAR = 2000; // first graduating class (26 graduations 2000–2025)
export const TONES = ["#0D47A8", "#C42B3B", "#0B1A33", "#2F6B4F", "#8A5A12", "#5B3FA0"];
export const CATS = ["Автомашин", "Эрүүл мэнд", "Хууль", "Барилга", "IT", "Санхүү", "Боловсрол", "Худалдаа", "Аялал"];
export const ETYPES = ["Уулзалт", "Хурал, зөвлөгөөн", "Аялал", "Спорт", "Сайн дурын ажил"];
export const VOICE_TYPES = ["Санал", "Хүсэлт", "Хурлын санал", "Гомдол"];
export const VOICE_STATUSES = ["Шинэ", "Хэлэлцэж буй", "Шийдвэрлэсэн"];
export const JOB_TYPES = ["Ажил", "Дадлага", "Түр ажил"];
export const MONTHS = ["1-р сар", "2-р сар", "3-р сар", "4-р сар", "5-р сар", "6-р сар", "7-р сар", "8-р сар", "9-р сар", "10-р сар", "11-р сар", "12-р сар"];

/** "Б.Болд" → "Б" of the given name (last part after the dot). */
export const initial = (name: string) => (name.split(".").pop() || name).slice(0, 1);

/** Stable colour per name. */
export const tone = (name: string) => TONES[[...name].reduce((a, c) => a + c.charCodeAt(0), 0) % TONES.length];

/** Class number counted from the first graduating year. */
export const cohortNo = (year: number, first = FIRST_YEAR) => year - first + 1;

/**
 * Decade label with vowel harmony: 1960-аад, 1990-ээд, 2020-иод.
 * (жараад, далаад, наяад, ерээд, 2000-аад, арваад, хориод, гучаад …)
 */
export function decadeLabel(decade: number): string {
  const tens = Math.floor((decade % 100) / 10);
  const suffix = tens === 9 ? "ээд" : tens === 2 ? "иод" : "аад";
  return `${decade}-${suffix}`;
}

export function fmtAgo(t: string | number | Date, now = Date.now()): string {
  const ms = new Date(t).getTime();
  const d = (now - ms) / 864e5;
  if (isNaN(d)) return "";
  if (d < 1 / 24) return "Саяхан";
  if (d < 1) return Math.floor(d * 24) + " цагийн өмнө";
  if (d < 30) return Math.floor(d) + " өдрийн өмнө";
  const x = new Date(ms);
  return x.getFullYear() + "." + String(x.getMonth() + 1).padStart(2, "0") + "." + String(x.getDate()).padStart(2, "0");
}

/** "2026-11-14" → "11-р сарын 14" */
export function dayLabel(d: string): string {
  const x = new Date(d);
  return isNaN(x.getTime()) ? d : x.getMonth() + 1 + "-р сарын " + x.getDate();
}

/** "2026-12-27T18:00" → "2026 оны 12-р сарын 27, 18:00" */
export function longDateTime(d: string): string {
  const x = new Date(d);
  if (isNaN(x.getTime())) return d;
  return `${x.getFullYear()} оны ${x.getMonth() + 1}-р сарын ${x.getDate()}, ${String(x.getHours()).padStart(2, "0")}:${String(x.getMinutes()).padStart(2, "0")}`;
}

export function dayMonth(d: string): { d: string; m: string } {
  const x = new Date(d);
  if (isNaN(x.getTime())) return { d: "--", m: "" };
  return { d: String(x.getDate()).padStart(2, "0"), m: MONTHS[x.getMonth()] };
}

export const money = (n: number) => n.toLocaleString("en-US") + "₮";

export const eventTone = (type: string | null | undefined) =>
  type === "Аялал" ? "#2F6B4F" : type === "Спорт" ? "#8A5A12" : (type || "").startsWith("Хурал") ? "#C42B3B" : "#0D47A8";

export function socialLinks(fb?: string | null, ig?: string | null) {
  const f = (fb || "").trim();
  const i = (ig || "").trim().replace(/^@/, "");
  const out: { label: string; href: string; color: string }[] = [];
  if (f) out.push({ label: "Facebook", color: "#1877F2", href: /^https?:/i.test(f) ? f : "https://facebook.com/" + f.replace(/^\/+/, "") });
  if (i) out.push({ label: "Instagram", color: "#C13584", href: /^https?:/i.test(i) ? i : "https://instagram.com/" + i });
  return out;
}

export const splitTags = (s: string) => s.split(",").map((t) => t.trim()).filter(Boolean);

/** Strips spaces, dashes and the +976 prefix. */
export const normalizePhone = (s: string) => s.replace(/[\s-]/g, "").replace(/^\+?976/, "");

export const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

export type JoinInput = {
  email?: string; pw?: string; pw2?: string;
  name: string; year: string; cat: string; job: string; phone: string;
};

/** Join-form validation from mgss1. Returns field → message. */
export function validateJoin(v: JoinInput, needAccount: boolean, currentYear = new Date().getFullYear()): Record<string, string> {
  const fe: Record<string, string> = {};
  if (needAccount) {
    const em = (v.email || "").trim();
    if (!em) fe.email = "И-мэйл хаягаа оруулна уу.";
    else if (!EMAIL_RE.test(em)) fe.email = "И-мэйл хаяг буруу байна. Ж.нь: ner@gmail.com";
    if (!v.pw) fe.pw = "Нууц үг оруулна уу.";
    else if (v.pw.length < 6) fe.pw = "Нууц үг 6-аас доошгүй тэмдэгттэй байх ёстой.";
    if (!v.pw2) fe.pw2 = "Нууц үгээ давтаж оруулна уу.";
    else if (v.pw !== v.pw2) fe.pw2 = "Нууц үг таарахгүй байна.";
  }
  const name = v.name.trim();
  if (!name) fe.name = "Овог, нэрээ оруулна уу.";
  else if (name.length < 3) fe.name = "Овог, нэрээ бүтэн бичнэ үү. Ж.нь: Б.Болд";
  else if (/\d/.test(name)) fe.name = "Нэрэнд тоо байж болохгүй.";
  const yr = v.year.trim();
  if (!yr) fe.year = "Төгссөн оноо оруулна уу.";
  else if (!/^\d{4}$/.test(yr) || +yr < 1997 || +yr > currentYear) fe.year = `1997–${currentYear} оны хооронд 4 оронтой он бичнэ үү.`;
  if (!v.cat) fe.cat = "Салбараа сонгоно уу.";
  if (!v.job.trim()) fe.job = "Эрхэлдэг ажлаа бичнэ үү.";
  const ph = normalizePhone(v.phone);
  if (!ph) fe.phone = "Утасны дугаараа оруулна уу.";
  else if (!/^\d{8}$/.test(ph)) fe.phone = "Утасны дугаар 8 оронтой байх ёстой. Ж.нь: 9911 2233";
  return fe;
}

/** Maps Supabase auth errors to the Mongolian messages mgss1 showed. */
export function authErrorMessage(m: string): string {
  if (/Invalid login/i.test(m)) return "И-мэйл эсвэл нууц үг буруу байна.";
  if (/Email not confirmed/i.test(m)) return "И-мэйлээ баталгаажуулна уу. Танд ирсэн захидлын холбоосыг дарна уу.";
  if (/already registered/i.test(m)) return "Энэ и-мэйлээр бүртгэл үүссэн байна. Нэвтэрнэ үү.";
  if (/rate limit|too many/i.test(m)) return "Хэт олон оролдлого хийлээ. Хэдэн минутын дараа дахин оролдоно уу.";
  if (/Failed to fetch|NetworkError|fetch failed/i.test(m)) return "Сервертэй холбогдож чадсангүй. Интернэтээ шалгана уу.";
  return m;
}
