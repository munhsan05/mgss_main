// Tournament logic ported from mgss1 (standings + round-robin generator).
// No imports, so tests can run it directly.

export type SportKey = "basket" | "volley";

export type Match = {
  stage?: string;
  zone?: string;
  day?: string;
  time?: string;
  home: string;
  away: string;
  hs?: string | number | null;
  as?: string | number | null;
};

export type StandingRow = { team: string; p: number; w: number; l: number; d: number; pts: number; rank: number };

export type Zone = {
  zone: string;
  table: StandingRow[];
  matches: (Match & { score: [number, number] | null })[];
  played: number;
};

export const SPORT_LABEL: Record<SportKey, string> = { basket: "Сагсан бөмбөг", volley: "Гар бөмбөг" };

export const POINTS_RULE: Record<SportKey, string> = {
  basket: "Хожил 2, хожигдол 1 оноо.",
  volley: "2:0 хожил 3, 2:1 хожил 2, 1:2 хожигдол 1 оноо.",
};

export function score(m: Match): [number, number] | null {
  const ok = (v: unknown) => v !== "" && v != null && !isNaN(Number(v));
  return ok(m.hs) && ok(m.as) ? [Number(m.hs), Number(m.as)] : null;
}

/** Group-stage tables per zone. Ties (equal score) are ignored, like mgss1. */
export function buildZones(sport: SportKey, matches: Match[]): Zone[] {
  const ms = matches.filter((m) => (!m.stage || m.stage === "group") && m.home && m.away);
  const zoneNames = [...new Set(ms.map((m) => m.zone || "А"))].sort();
  return zoneNames.map((z) => {
    const list = ms
      .filter((m) => (m.zone || "А") === z)
      .sort((a, b) => ((a.day || "") + (a.time || "")).localeCompare((b.day || "") + (b.time || "")));
    const st: Record<string, Omit<StandingRow, "rank">> = {};
    const add = (n: string) => (st[n] = st[n] || { team: n, p: 0, w: 0, l: 0, d: 0, pts: 0 });
    for (const m of list) {
      const H = add(m.home), A = add(m.away), s = score(m);
      if (!s || s[0] === s[1]) continue;
      const [x, y] = s;
      H.p++; A.p++; H.d += x - y; A.d += y - x;
      const W = x > y ? H : A, L = x > y ? A : H;
      W.w++; L.l++;
      if (sport === "basket") { W.pts += 2; L.pts += 1; }
      else { const loserSets = Math.min(x, y); W.pts += loserSets ? 2 : 3; L.pts += loserSets ? 1 : 0; }
    }
    const table = Object.values(st)
      .sort((a, b) => b.pts - a.pts || b.d - a.d || b.w - a.w)
      .map((r, i) => ({ ...r, rank: i + 1 }));
    return { zone: z, table, matches: list.map((m) => ({ ...m, score: score(m) })), played: list.filter((m) => score(m)).length };
  });
}

/**
 * Round-robin schedule (circle method). Odd team counts get a bye.
 * Times start at `start` ("HH:MM") and advance `stepMin` minutes per match.
 */
export function roundRobin(teams: string[], opts: { zone: string; day: string; start: string; stepMin: number }): Match[] {
  const list: (string | null)[] = teams.length % 2 ? [...teams, null] : [...teams];
  const N = list.length;
  const pairs: [string, string][] = [];
  for (let rd = 0; rd < N - 1; rd++) {
    for (let i = 0; i < N / 2; i++) {
      const a = list[i], b = list[N - 1 - i];
      if (a && b) pairs.push([a, b]);
    }
    list.splice(1, 0, list.pop()!);
  }
  const [hh, mm] = opts.start.split(":").map(Number);
  const t0 = (hh || 0) * 60 + (mm || 0);
  return pairs.map(([home, away], i) => {
    const t = t0 + i * (opts.stepMin || 0);
    const time = String(Math.floor(t / 60) % 24).padStart(2, "0") + ":" + String(t % 60).padStart(2, "0");
    return { stage: "group", zone: opts.zone, day: opts.day, time, home, away, hs: "", as: "" };
  });
}
