// Photo upload → Cloudflare R2.
// The browser has already resized the photo (see src/lib/resize-image.ts);
// this route re-checks everything because the browser can't be trusted:
// signed-in user, allowed kind, admin for gallery/cohort, real WebP/JPEG bytes, size cap.
import { NextResponse } from "next/server";
import { createClient, supabaseConfigured } from "@/lib/supabase/server";
import { putObject, deleteObject, r2Configured } from "@/lib/r2";
import { isR2Path } from "@/lib/media";
import { revalidatePath } from "next/cache";

const MAX_BYTES = 1024 * 1024; // 1 MB — resized photos are ~30–400 KB
const KINDS = { avatar: "avatars", gallery: "gallery", cohort: "cohorts" } as const;
type Kind = keyof typeof KINDS;

function sniff(b: Uint8Array): "image/webp" | "image/jpeg" | null {
  if (b.length > 12 && b[0] === 0x52 && b[1] === 0x49 && b[2] === 0x46 && b[3] === 0x46 && b[8] === 0x57 && b[9] === 0x45 && b[10] === 0x42 && b[11] === 0x50) return "image/webp";
  if (b.length > 3 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return "image/jpeg";
  return null;
}

const fail = (error: string, status: number) => NextResponse.json({ error }, { status });

export async function POST(req: Request) {
  if (!supabaseConfigured()) return fail("Supabase тохируулаагүй байна.", 500);
  if (!r2Configured()) return fail("Зургийн сан (R2) тохируулаагүй байна.", 500);

  const sb = await createClient();
  const { data: auth } = await sb.auth.getUser();
  const user = auth.user;
  if (!user) return fail("Нэвтэрнэ үү.", 401);

  const form = await req.formData().catch(() => null);
  const file = form?.get("file");
  const kind = String(form?.get("kind") || "") as Kind;
  if (!(kind in KINDS)) return fail("Буруу төрөл.", 400);
  if (!(file instanceof File)) return fail("Зураг олдсонгүй.", 400);
  if (file.size > MAX_BYTES) return fail("Зураг хэт том байна (1 MB хүртэл).", 413);

  if (kind !== "avatar") {
    const { data: admin } = await sb.rpc("is_admin");
    if (!admin) return fail("Админ эрх шаардлагатай.", 403);
  }

  const bytes = new Uint8Array(await file.arrayBuffer());
  const type = sniff(bytes);
  if (!type) return fail("Зөвхөн WebP эсвэл JPEG зураг.", 415);

  const ext = type === "image/webp" ? "webp" : "jpg";
  const id = Date.now() + "-" + crypto.randomUUID().slice(0, 8);
  const key = kind === "avatar" ? `${KINDS.avatar}/${user.id}/${id}.${ext}` : `${KINDS[kind]}/${id}.${ext}`;

  try {
    await putObject(key, bytes, type);
  } catch (e) {
    console.error("R2 upload failed", e);
    return fail("Зураг хадгалагдсангүй. Дахин оролдоно уу.", 502);
  }

  if (kind === "avatar") {
    // Save on the profile, then remove the previous photo so storage doesn't pile up.
    const { data: prof } = await sb.from("profiles").select("id,photo").eq("user_id", user.id).maybeSingle();
    if (!prof) {
      await deleteObject(key).catch(() => {});
      return fail("Эхлээд профайлаа үүсгэнэ үү.", 409);
    }
    const { error } = await sb.from("profiles").update({ photo: key }).eq("id", prof.id);
    if (error) {
      await deleteObject(key).catch(() => {});
      return fail(error.message, 400);
    }
    const old = prof.photo as string | null;
    if (isR2Path(old) && old!.startsWith(`${KINDS.avatar}/${user.id}/`)) await deleteObject(old!).catch(() => {});
    revalidatePath("/", "layout");
  }

  return NextResponse.json({ path: key });
}

/** Remove own profile photo. */
export async function DELETE() {
  if (!supabaseConfigured()) return fail("Supabase тохируулаагүй байна.", 500);
  const sb = await createClient();
  const { data: auth } = await sb.auth.getUser();
  const user = auth.user;
  if (!user) return fail("Нэвтэрнэ үү.", 401);
  const { data: prof } = await sb.from("profiles").select("id,photo").eq("user_id", user.id).maybeSingle();
  if (!prof) return NextResponse.json({ ok: true });
  const { error } = await sb.from("profiles").update({ photo: "" }).eq("id", prof.id);
  if (error) return fail(error.message, 400);
  const old = prof.photo as string | null;
  if (r2Configured() && isR2Path(old) && old!.startsWith(`${KINDS.avatar}/${user.id}/`)) await deleteObject(old!).catch(() => {});
  revalidatePath("/", "layout");
  return NextResponse.json({ ok: true });
}
