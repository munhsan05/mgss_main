import { getContent } from "@/lib/data";
import { EeshEditor, SiteForm, TeachersEditor } from "@/components/admin/editors";
import { TabHeader } from "@/components/admin/server-ui";

export default async function AdminContent() {
  const c = await getContent();
  return (
    <>
      <TabHeader eyebrow="Агуулга" title="Нүүр, сургууль, багш нар" />
      <SiteForm site={c.site} />
      <EeshEditor initial={c.eesh} />
      <TeachersEditor initial={c.teachers} />
    </>
  );
}
