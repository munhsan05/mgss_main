import { getContent } from "@/lib/data";
import { SportEditor } from "@/components/admin/editors";
import { TabHeader } from "@/components/admin/server-ui";

export default async function AdminSports() {
  const c = await getContent();
  return (
    <>
      <TabHeader eyebrow="Тэмцээн" title="Сагсан ба гар бөмбөг" />
      <SportEditor sportKey="basket" initial={c.sports.basket} />
      <SportEditor sportKey="volley" initial={c.sports.volley} />
    </>
  );
}
