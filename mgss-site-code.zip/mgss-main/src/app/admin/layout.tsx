import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { getEvents, getPeople, getViewer, getVoices } from "@/lib/data";
import { signOut } from "@/app/actions/auth";
import { AdminLogin, AdminTabs } from "@/components/admin/editors";

export const metadata: Metadata = { title: "Админ", robots: { index: false } };

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const viewer = await getViewer();

  if (!viewer.user)
    return (
      <div className="grid min-h-screen place-items-center bg-navy p-6">
        <AdminLogin />
      </div>
    );

  if (!viewer.isAdmin)
    return (
      <div className="grid min-h-screen place-items-center bg-navy p-6">
        <div className="flex max-w-md flex-col gap-4 rounded-[28px] bg-white p-9 text-navy">
          <h1 className="font-serif text-3xl">Админ эрхгүй</h1>
          <p className="text-muted">{viewer.user.email} бүртгэлд админ эрх олгогдоогүй байна.</p>
          <div className="flex gap-2">
            <Link href="/" className="a-ghost">Сайт руу буцах</Link>
            <form action={signOut}><button className="a-danger">Гарах</button></form>
          </div>
        </div>
      </div>
    );

  const [people, events, voices] = await Promise.all([getPeople(), getEvents(), getVoices()]);
  const tabs = [
    { href: "/admin", label: "Тойм" },
    { href: "/admin/content", label: "Агуулга" },
    { href: "/admin/school", label: "Сургууль" },
    { href: "/admin/people", label: "Гишүүд", badge: people.filter((p) => p.status === "pending").length },
    { href: "/admin/events", label: "Арга хэмжээ", badge: events.filter((e) => e.proposed).length },
    { href: "/admin/voices", label: "Санал хүсэлт", badge: voices.filter((v) => v.status === "Шинэ").length },
    { href: "/admin/ny", label: "Шинэ жил" },
    { href: "/admin/albums", label: "Зургийн цомог" },
    { href: "/admin/sports", label: "Тэмцээн" },
    { href: "/admin/news", label: "Мэдээ" },
    { href: "/admin/jobs", label: "Ажлын зар" },
    { href: "/admin/fund", label: "Сан" },
    { href: "/admin/cohorts", label: "Төгсөлтүүд" },
  ];

  return (
    <div className="grid min-h-screen bg-paper text-navy md:grid-cols-[250px_minmax(0,1fr)]">
      <aside className="flex flex-col gap-4 bg-navy p-3 md:sticky md:top-0 md:h-screen md:p-4">
        <Link href="/" className="flex items-center gap-3 px-2 pt-1 text-white">
          <Image src="/img/logo-alumni.png" alt="" width={38} height={38} className="rounded-full bg-white" />
          <span className="flex flex-col leading-tight"><span className="font-extrabold uppercase">Хархорин МГСС</span><span className="text-xs font-bold uppercase">Төгсөгчдийн холбоо</span><span className="text-xs text-white/60">Админ</span></span>
        </Link>
        <AdminTabs tabs={tabs} />
        <div className="mt-auto hidden flex-col gap-2 md:flex">
          <Link href="/" target="_blank" className="rounded-full border border-white/30 px-4 py-2 text-center text-sm font-semibold text-white hover:bg-white/10">Сайтыг харах ↗</Link>
          <form action={signOut}><button className="w-full cursor-pointer rounded-full px-4 py-2 text-sm text-white/70 hover:text-white">Гарах</button></form>
        </div>
      </aside>
      <main className="flex min-w-0 flex-col gap-6 p-4 sm:p-8">{children}</main>
    </div>
  );
}
