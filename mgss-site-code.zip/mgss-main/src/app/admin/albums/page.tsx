import { getContent } from "@/lib/data";
import { AlbumsEditor } from "@/components/admin/editors";
import { TabHeader } from "@/components/admin/server-ui";

export default async function AdminAlbums() {
  const c = await getContent();
  return (
    <>
      <TabHeader eyebrow="Зургийн цомог" title="Цомгууд" />
      <p className="text-sm text-muted">
        Шинэ жилийн зургууд «Шинэ жил» хэсгээс, ангийн зургууд «Төгсөлтүүд» хэсгээс, багш нарын зургууд сургуулийн мэдээллээс цомогт автоматаар орно. Энд нэмэлт цомог үүсгэнэ.
      </p>
      <AlbumsEditor initial={c.albums} />
    </>
  );
}
