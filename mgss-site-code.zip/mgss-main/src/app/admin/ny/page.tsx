import { getBookings, getContent } from "@/lib/data";
import { deleteBooking, setBookingStatus } from "@/app/actions/admin";
import { ActionButton, ConfirmButton } from "@/components/client";
import { NyEditor } from "@/components/admin/editors";
import { AEmpty, Badge, TabHeader } from "@/components/admin/server-ui";

const ST = { paid: ["Төлсөн", "green"], cancelled: ["Цуцалсан", "grey"], pending: ["Хүлээгдэж буй", "amber"] } as const;

export default async function AdminNy() {
  const [c, bookings] = await Promise.all([getContent(), getBookings()]);
  const seats = bookings.filter((b) => b.status !== "cancelled").reduce((s, b) => s + b.seats, 0);
  return (
    <>
      <TabHeader eyebrow="Шинэ жил" title="Шинэ жилийн үдэшлэг" />
      <NyEditor initial={c.ny} />
      <section className="a-card flex flex-col">
        <div className="mb-2 flex flex-wrap items-baseline justify-between gap-2">
          <h2 className="font-serif text-2xl">Захиалга</h2>
          <span className="text-sm text-muted">{bookings.length} захиалга · {seats} суудал{c.ny.seats ? ` / ${c.ny.seats}` : ""}</span>
        </div>
        {bookings.length === 0 && <AEmpty>Захиалга алга.</AEmpty>}
        {bookings.map((b) => {
          const [label, tone] = ST[b.status as keyof typeof ST] || ST.pending;
          return (
            <div key={b.id} className="flex flex-wrap items-center gap-3 border-t border-[#EFEBE4] py-3">
              <div className="flex min-w-48 flex-1 flex-col">
                <span className="font-semibold">{b.name} · {b.seats} суудал</span>
                <span className="text-[13.5px] text-muted">{b.phone}{b.year ? ` · ${b.year} он` : ""} · {b.createdAt.slice(0, 10)}{b.note ? ` · ${b.note}` : ""}</span>
              </div>
              <Badge tone={tone}>{label}</Badge>
              {b.status !== "paid" && <ActionButton action={setBookingStatus.bind(null, b.id, "paid")} className="a-primary">Төлсөн</ActionButton>}
              {b.status !== "pending" && <ActionButton action={setBookingStatus.bind(null, b.id, "pending")} className="a-ghost">Хүлээгдэж буй</ActionButton>}
              {b.status !== "cancelled" && <ActionButton action={setBookingStatus.bind(null, b.id, "cancelled")} className="a-ghost">Цуцлах</ActionButton>}
              <ConfirmButton action={deleteBooking.bind(null, b.id)} message="Энэ захиалгыг устгах уу?" className="a-danger">Устгах</ConfirmButton>
            </div>
          );
        })}
      </section>
    </>
  );
}
