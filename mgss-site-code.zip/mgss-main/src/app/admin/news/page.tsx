import { getContent } from "@/lib/data";
import { deleteNews } from "@/app/actions/admin";
import { fmtAgo } from "@/lib/format";
import { ConfirmButton } from "@/components/client";
import { NewsForm } from "@/components/admin/editors";
import { AEmpty, TabHeader } from "@/components/admin/server-ui";

export default async function AdminNews() {
  const { news } = await getContent();
  return (
    <>
      <TabHeader eyebrow="Мэдээ" title="Мэдэгдэл ба мэдээ" />
      <NewsForm />
      <section className="a-card flex flex-col">
        {news.length === 0 && <AEmpty>Мэдээ алга.</AEmpty>}
        {news.map((n) => (
          <div key={n.id} className="flex flex-wrap items-start gap-3 border-t border-[#EFEBE4] py-3 first:border-0">
            <div className="flex flex-1 flex-col"><span className="font-semibold">{n.title}</span><span className="text-[13.5px] text-muted">{fmtAgo(n.date)}</span>{n.body && <p className="mt-1 text-sm whitespace-pre-line">{n.body}</p>}</div>
            <ConfirmButton action={deleteNews.bind(null, n.id)} message="Энэ мэдээг устгах уу?" className="a-danger">Устгах</ConfirmButton>
          </div>
        ))}
      </section>
    </>
  );
}
