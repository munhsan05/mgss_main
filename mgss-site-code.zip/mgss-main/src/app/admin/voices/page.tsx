import { getVoices } from "@/lib/data";
import { deleteVoice, setVoiceStatus } from "@/app/actions/admin";
import { VOICE_STATUSES, fmtAgo } from "@/lib/format";
import { ActionButton, ConfirmButton } from "@/components/client";
import { ReplyForm } from "@/components/admin/editors";
import { AEmpty, TabHeader } from "@/components/admin/server-ui";

export default async function AdminVoices() {
  const voices = await getVoices();
  return (
    <>
      <TabHeader eyebrow="Санал хүсэлт" title="Нээлттэй самбар" />
      <section className="flex flex-col gap-4">
        {voices.length === 0 && <div className="a-card"><AEmpty>Санал хүсэлт алга.</AEmpty></div>}
        {voices.map((v) => (
          <article key={v.id} className="a-card flex flex-col gap-3">
            <div className="flex flex-wrap items-center gap-2 text-sm text-muted">
              <span className="a-badge bg-[#EEF3FC] text-brand">{v.type}</span>
              <span>▲ {v.votes}</span><span>·</span><span>{v.by || "Нэргүй"}</span><span>·</span><span>{fmtAgo(v.createdAt)}</span>
            </div>
            <p className="whitespace-pre-line">{v.text}</p>
            <div className="flex flex-wrap items-center gap-2">
              {VOICE_STATUSES.map((st) => (
                <ActionButton key={st} action={setVoiceStatus.bind(null, v.id, st)}
                  className={`a-btn border ${v.status === st ? "border-navy bg-navy text-white" : "border-sand bg-white text-navy"}`}>{st}</ActionButton>
              ))}
              <ConfirmButton action={deleteVoice.bind(null, v.id)} message="Энэ саналыг устгах уу?" className="a-danger ml-auto">Устгах</ConfirmButton>
            </div>
            <ReplyForm id={v.id} reply={v.reply} />
          </article>
        ))}
      </section>
    </>
  );
}
