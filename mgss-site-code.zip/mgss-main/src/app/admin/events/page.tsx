import { getEvents } from "@/lib/data";
import { deleteEvent, publishEvent } from "@/app/actions/admin";
import { dayMonth, eventTone } from "@/lib/format";
import { ActionButton, ConfirmButton } from "@/components/client";
import { EventForm } from "@/components/admin/editors";
import { AEmpty, Badge, TabHeader } from "@/components/admin/server-ui";

export default async function AdminEvents() {
  const events = [...(await getEvents())].sort((a, b) => b.date.localeCompare(a.date));
  return (
    <>
      <TabHeader eyebrow="Арга хэмжээ" title="Арга хэмжээ удирдах" />
      <section className="a-card flex flex-col gap-3">
        <h2 className="font-serif text-2xl">Шинэ арга хэмжээ</h2>
        <EventForm />
      </section>
      <section className="a-card flex flex-col">
        {events.length === 0 && <AEmpty>Арга хэмжээ алга.</AEmpty>}
        {events.map((e, i) => {
          const dm = dayMonth(e.date);
          return (
            <details key={e.id} className={`group py-3 ${i ? "border-t border-[#EFEBE4]" : ""}`}>
              <summary className="flex cursor-pointer list-none flex-wrap items-center gap-3">
                <span className="flex w-14 flex-col items-center rounded-xl py-1 text-white" style={{ background: eventTone(e.type) }}>
                  <b className="font-serif">{dm.d}</b><span className="text-[10px]">{dm.m}</span>
                </span>
                <div className="flex min-w-40 flex-1 flex-col">
                  <span className="font-semibold">{e.title}</span>
                  <span className="text-[13.5px] text-muted">{e.type} · {e.place || "—"} · {e.going} оролцогч</span>
                </div>
                {e.proposed ? <Badge tone="amber">Санал болгосон</Badge> : <Badge tone="green">Нийтлэгдсэн</Badge>}
                {e.proposed && <ActionButton action={publishEvent.bind(null, e.id)} className="a-primary">Нийтлэх</ActionButton>}
                <span className="a-ghost">Засах</span>
                <ConfirmButton action={deleteEvent.bind(null, e.id)} message="Энэ арга хэмжээг устгах уу?" className="a-danger">Устгах</ConfirmButton>
              </summary>
              <div className="pt-3"><EventForm e={e} /></div>
            </details>
          );
        })}
      </section>
    </>
  );
}
