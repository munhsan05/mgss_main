import { getContent } from "@/lib/data";
import { SchoolEditor } from "@/components/admin/school-editor";
import { TabHeader } from "@/components/admin/server-ui";

export default async function AdminSchool() {
  const c = await getContent();
  return (
    <>
      <TabHeader eyebrow="Сургууль" title="Сургуулийн танилцуулга, түүх, хамт олон" />
      <SchoolEditor initial={c.school} />
    </>
  );
}
