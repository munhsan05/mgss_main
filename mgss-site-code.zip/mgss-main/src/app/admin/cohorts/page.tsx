import { getContent } from "@/lib/data";
import { FIRST_YEAR } from "@/lib/format";
import { CohortEditor } from "@/components/admin/editors";
import { TabHeader } from "@/components/admin/server-ui";

export default async function AdminCohorts({ searchParams }: { searchParams: Promise<{ year?: string }> }) {
  const sp = await searchParams;
  const last = new Date().getFullYear();
  const year = Math.min(Math.max(parseInt(sp.year || "", 10) || last, FIRST_YEAR), last);
  const c = await getContent();
  const cohort = c.cohorts[String(year)] || { photo: "", teacher: "", leader: "", memories: [] };
  const filled = Object.keys(c.cohorts).filter((y) => c.cohorts[y]?.photo || c.cohorts[y]?.teacher || c.cohorts[y]?.memories?.length).sort().reverse();
  return (
    <>
      <TabHeader eyebrow="Төгсөлтүүд" title="Ангийн зураг, дурсамж">
        <form className="flex items-center gap-2">
          <label className="a-label">Он
            <input name="year" type="number" min={FIRST_YEAR} max={last} defaultValue={year} className="a-input w-32" />
          </label>
          <button className="a-ghost self-end">Сонгох</button>
        </form>
      </TabHeader>
      {filled.length > 0 && (
        <p className="text-sm text-muted">Мэдээлэлтэй онууд: {filled.map((y, i) => <span key={y}>{i ? ", " : ""}<a href={`/admin/cohorts?year=${y}`} className="text-brand hover:underline">{y}</a></span>)}</p>
      )}
      <CohortEditor key={year} year={year} initial={cohort} />
    </>
  );
}
