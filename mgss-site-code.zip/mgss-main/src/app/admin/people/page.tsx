import Link from "next/link";
import { getAllProfilesForAdmin } from "@/lib/data";
import { deleteProfile, setProfileStatus } from "@/app/actions/admin";
import { ActionButton, ConfirmButton } from "@/components/client";
import { Avatar } from "@/components/ui";
import { ProfileEditForm } from "@/components/admin/editors";
import { AEmpty, Badge, TabHeader } from "@/components/admin/server-ui";

const FILTERS = [["all", "Бүгд"], ["pending", "Хүлээгдэж буй"], ["approved", "Баталгаажсан"]] as const;

export default async function AdminPeople({ searchParams }: { searchParams: Promise<{ q?: string; f?: string }> }) {
  const sp = await searchParams;
  const q = (sp.q || "").trim().toLowerCase();
  const f = FILTERS.some(([k]) => k === sp.f) ? sp.f! : "all";
  const all = await getAllProfilesForAdmin();
  const list = all
    .filter((p) => f === "all" || p.status === f)
    .filter((p) => !q || [p.name, p.job, p.org, p.loc, String(p.year)].join(" ").toLowerCase().includes(q));

  return (
    <>
      <TabHeader eyebrow="Гишүүд" title="Төгсөгчдийн сүлжээ" />
      <div className="flex flex-wrap items-center gap-3">
        <form className="flex-1">
          {f !== "all" && <input type="hidden" name="f" value={f} />}
          <input name="q" defaultValue={sp.q} placeholder="Нэр, ажил, оноор хайх" className="a-input max-w-md" />
        </form>
        <nav className="flex gap-1 rounded-full bg-[#EDE9E1] p-1">
          {FILTERS.map(([k, label]) => (
            <Link key={k} href={`/admin/people?${new URLSearchParams({ ...(k !== "all" ? { f: k } : {}), ...(sp.q ? { q: sp.q } : {}) })}`}
              className={`rounded-full px-4 py-2 text-sm font-semibold ${k === f ? "bg-white shadow-sm" : "text-muted"}`}>{label}</Link>
          ))}
        </nav>
      </div>
      <section className="a-card flex flex-col">
        {list.length === 0 && <AEmpty>Гишүүн олдсонгүй.</AEmpty>}
        {list.map((p, i) => (
          <details key={p.id} className={`group py-3 ${i ? "border-t border-[#EFEBE4]" : ""}`}>
            <summary className="flex cursor-pointer list-none flex-wrap items-center gap-3">
              <Avatar name={p.name} photo={p.photo} size={42} />
              <div className="flex min-w-40 flex-1 flex-col">
                <span className="font-semibold">{p.name}</span>
                <span className="text-[13.5px] text-muted">{p.year} он · {p.job} · {p.phone || "утасгүй"}{p.hide ? " (нууцалсан)" : ""}</span>
              </div>
              {p.status === "pending" ? <Badge tone="red">Хүлээгдэж буй</Badge> : <Badge tone="green">Баталгаажсан</Badge>}
              {p.status === "pending" && <ActionButton action={setProfileStatus.bind(null, p.id, "approved")} className="a-primary">Батлах</ActionButton>}
              <span className="a-ghost group-open:bg-paper">Засах</span>
              <ConfirmButton action={deleteProfile.bind(null, p.id)} message={`${p.name}-г устгах уу?`} className="a-danger">Устгах</ConfirmButton>
            </summary>
            <ProfileEditForm p={p} />
          </details>
        ))}
      </section>
    </>
  );
}
