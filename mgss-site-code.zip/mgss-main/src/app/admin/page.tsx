import Link from "next/link";
import { getAllProfilesForAdmin, getEvents, getVoices } from "@/lib/data";
import { setProfileStatus, publishEvent, deleteEvent } from "@/app/actions/admin";
import { ActionButton, ConfirmButton } from "@/components/client";
import { Avatar } from "@/components/ui";
import { AEmpty, TabHeader } from "@/components/admin/server-ui";

export default async function AdminOverview() {
  const [people, events, voices] = await Promise.all([getAllProfilesForAdmin(), getEvents(), getVoices()]);
  const pending = people.filter((p) => p.status === "pending");
  const proposed = events.filter((e) => e.proposed);
  const newVoices = voices.filter((v) => v.status === "Шинэ").length;
  const stats = [
    { v: people.length - pending.length, l: "Баталгаажсан гишүүн", c: "#0D47A8", href: "/admin/people" },
    { v: pending.length, l: "Баталгаажуулах хүсэлт", c: "#C42B3B", href: "/admin/people?f=pending" },
    { v: events.length, l: "Арга хэмжээ", c: "#0B1A33", href: "/admin/events" },
    { v: newVoices, l: "Шинэ санал хүсэлт", c: "#8A5A12", href: "/admin/voices" },
  ];

  return (
    <>
      <TabHeader eyebrow="Тойм" title="Хянах самбар" />
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {stats.map((s) => (
          <Link key={s.l} href={s.href} className="a-card flex flex-col gap-1 hover:border-brand">
            <span className="font-serif text-4xl" style={{ color: s.c }}>{s.v}</span>
            <span className="text-sm text-muted">{s.l}</span>
          </Link>
        ))}
      </div>
      <div className="grid gap-6 xl:grid-cols-2">
        <section className="a-card flex flex-col gap-1">
          <h2 className="mb-2 font-serif text-2xl">Баталгаажуулах гишүүд</h2>
          {pending.length === 0 && <AEmpty>Хүлээгдэж буй хүсэлт алга.</AEmpty>}
          {pending.map((p) => (
            <div key={p.id} className="flex items-center gap-3 border-t border-[#EFEBE4] py-3">
              <Avatar name={p.name} photo={p.photo} size={40} />
              <div className="flex flex-1 flex-col"><span className="font-semibold">{p.name}</span><span className="text-[13.5px] text-muted">{p.year} он · {p.job}</span></div>
              <ActionButton action={setProfileStatus.bind(null, p.id, "approved")} className="a-primary">Батлах</ActionButton>
            </div>
          ))}
        </section>
        <section className="a-card flex flex-col gap-1">
          <h2 className="mb-2 font-serif text-2xl">Санал болгосон арга хэмжээ</h2>
          {proposed.length === 0 && <AEmpty>Санал болгосон арга хэмжээ алга.</AEmpty>}
          {proposed.map((e) => (
            <div key={e.id} className="flex flex-wrap items-center gap-3 border-t border-[#EFEBE4] py-3">
              <div className="flex flex-1 flex-col"><span className="font-semibold">{e.title}</span><span className="text-[13.5px] text-muted">{e.date} · {e.type} · {e.place}</span></div>
              <ActionButton action={publishEvent.bind(null, e.id)} className="a-primary">Нийтлэх</ActionButton>
              <ConfirmButton action={deleteEvent.bind(null, e.id)} message="Энэ арга хэмжээг устгах уу?" className="a-danger">Устгах</ConfirmButton>
            </div>
          ))}
        </section>
      </div>
    </>
  );
}
