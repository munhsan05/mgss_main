import { getContent } from "@/lib/data";
import { FundForm } from "@/components/admin/editors";
import { TabHeader } from "@/components/admin/server-ui";

export default async function AdminFund() {
  const c = await getContent();
  return (
    <>
      <TabHeader eyebrow="Сан" title="Хандив ба тэтгэлэг" />
      <FundForm fund={c.fund} />
    </>
  );
}
