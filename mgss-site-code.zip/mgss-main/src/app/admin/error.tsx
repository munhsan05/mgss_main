"use client";

export default function AdminError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <div className="a-card flex max-w-xl flex-col items-start gap-3">
      <h1 className="font-serif text-3xl">Алдаа гарлаа</h1>
      <p className="text-muted">{error.message || "Түр зуурын алдаа. Дахин оролдоно уу."}</p>
      <button onClick={reset} className="a-primary">Дахин оролдох</button>
    </div>
  );
}
