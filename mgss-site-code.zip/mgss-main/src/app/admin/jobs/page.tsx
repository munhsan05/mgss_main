import { getJobs } from "@/lib/data";
import { deleteJobAdmin } from "@/app/actions/admin";
import { fmtAgo } from "@/lib/format";
import { ConfirmButton } from "@/components/client";
import { AEmpty, TabHeader } from "@/components/admin/server-ui";

export default async function AdminJobs() {
  const jobs = await getJobs();
  return (
    <>
      <TabHeader eyebrow="Ажлын зар" title="Ажлын зар, дадлага" />
      <section className="a-card flex flex-col">
        {jobs.length === 0 && <AEmpty>Зар алга.</AEmpty>}
        {jobs.map((j) => (
          <div key={j.id} className="flex flex-wrap items-start gap-3 border-t border-[#EFEBE4] py-3 first:border-0">
            <div className="flex flex-1 flex-col">
              <span className="font-semibold">{j.title}</span>
              <span className="text-[13.5px] text-muted">{[j.type, j.org, j.contact, fmtAgo(j.createdAt)].filter(Boolean).join(" · ")}</span>
              {j.descr && <p className="mt-1 text-sm whitespace-pre-line">{j.descr}</p>}
            </div>
            <ConfirmButton action={deleteJobAdmin.bind(null, j.id)} message="Энэ зарыг устгах уу?" className="a-danger">Устгах</ConfirmButton>
          </div>
        ))}
      </section>
    </>
  );
}
