import type { Metadata, Viewport } from "next";
import { Nunito } from "next/font/google";
import "./globals.css";

const nunito = Nunito({ variable: "--font-nunito", subsets: ["latin", "cyrillic"], weight: ["400", "600", "700", "800", "900"] });

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000"),
  title: { default: "Хархорин МГСС Төгсөгчдийн холбоо", template: "%s · Хархорин МГСС Төгсөгчдийн холбоо" },
  description: "Үе үеийн төгсөгчид хэн, хаана, ямар ажил эрхэлж байгааг мэдэж, бие биедээ туслах нээлттэй орчин.",
  openGraph: {
    title: "Хархорин МГСС Төгсөгчдийн холбоо",
    description: "Бие биеэ олж, бие биедээ тусалцгаая.",
    images: ["/og.jpg"],
    locale: "mn_MN",
    type: "website",
  },
};

export const viewport: Viewport = { themeColor: "#004b90" };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="mn" className={nunito.variable}>
      <body className="min-h-screen font-sans">{children}</body>
    </html>
  );
}
