import type { MetadataRoute } from "next";

const base = (process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000").replace(/\/+$/, "");
const PAGES = ["", "/school", "/school/staff", "/school/history", "/gallery", "/cohorts", "/network", "/jobs", "/events", "/voice", "/join"];

export default function sitemap(): MetadataRoute.Sitemap {
  const lastModified = new Date();
  return PAGES.map((p) => ({ url: base + p, lastModified, changeFrequency: p === "" ? "daily" : "weekly", priority: p === "" ? 1 : 0.7 }));
}
