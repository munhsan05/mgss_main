"use server";

// Admin actions: one action per change (no bulk "save everything" like mgss1).
// Each re-checks admin rights on the server; RLS enforces it again in Postgres.
import { revalidatePath } from "next/cache";
import { redirect, unstable_rethrow } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { getContent } from "@/lib/data";
import { deleteObject, r2Configured } from "@/lib/r2";
import { isR2Path } from "@/lib/media";
import { CATS, ETYPES, JOB_TYPES, VOICE_STATUSES, normalizePhone, splitTags } from "@/lib/format";
import type { Album, Cohort, Content, ContentKey, EeshRow, Fund, GalleryItem, NewsItem, Ny, Site, Sport, Teacher } from "@/lib/content";
import type { Match, SportKey } from "@/lib/sports";
import { SCHOOL_KEYS, type SchoolKey } from "@/lib/school-content";
import type { FormState } from "./auth";

async function guard(fn: () => Promise<FormState>): Promise<FormState> {
  try {
    return await fn();
  } catch (e) {
    unstable_rethrow(e); // let redirect() through
    return { error: (e as Error).message };
  }
}

async function requireAdmin() {
  const sb = await createClient();
  const { data } = await sb.auth.getUser();
  if (!data.user) redirect("/admin");
  const { data: ok } = await sb.rpc("is_admin");
  if (!ok) throw new Error("Админ эрх шаардлагатай.");
  return sb;
}

const refresh = () => revalidatePath("/", "layout");
const str = (v: unknown, max = 2000) => String(v ?? "").trim().slice(0, max);
const num = (v: unknown) => parseInt(String(v ?? "").replace(/[^0-9-]/g, ""), 10) || 0;
const arr = <T,>(v: unknown): T[] => (Array.isArray(v) ? (v as T[]) : []);
const fstr = (fd: FormData, k: string, max = 2000) => str(fd.get(k), max);

async function writeContent<K extends ContentKey>(key: K, data: Content[K]) {
  const sb = await requireAdmin();
  const { error } = await sb.from("site_content").upsert({ key, data, updated_at: new Date().toISOString() });
  if (error) throw new Error(error.message);
  refresh();
}

/** Deletes R2 objects that a save no longer references (gallery/cohort photos). */
async function dropUnused(before: string[], after: string[]) {
  if (!r2Configured()) return;
  const keep = new Set(after);
  await Promise.all(before.filter((p) => isR2Path(p) && !keep.has(p)).map((p) => deleteObject(p).catch(() => {})));
}

// ---------------- content ----------------

async function saveSiteImpl(fd: FormData): Promise<FormState> {
  const site: Site = {
    heroTitle: fstr(fd, "heroTitle", 200), heroLead: fstr(fd, "heroLead", 600), schoolIntro: fstr(fd, "schoolIntro", 4000),
    contactEmail: fstr(fd, "contactEmail", 200), contactPhone: fstr(fd, "contactPhone", 60),
  };
  await writeContent("site", site);
  return { ok: true, notice: "✓ Хадгалагдлаа" };
}

async function saveEeshImpl(rows: EeshRow[]): Promise<FormState> {
  const clean = arr<EeshRow>(rows).map((r) => ({
    label: str(r.label, 80), v: str(r.v, 40), pct: Math.min(100, Math.max(0, num(r.pct))), c: /^#[0-9a-f]{6}$/i.test(r.c) ? r.c : "#0D47A8", note: str(r.note, 300),
  }));
  await writeContent("eesh", clean);
  return { ok: true, notice: "✓ Хадгалагдлаа" };
}

async function saveTeachersImpl(rows: Teacher[]): Promise<FormState> {
  const clean = arr<Teacher>(rows).filter((t) => str(t.n)).map((t, i) => ({
    id: str(t.id, 60) || `teacher-${Date.now()}-${i}`, n: str(t.n, 120), s: str(t.s, 120), photo: str(t.photo, 500), degree: str(t.degree, 60), years: Math.max(0, num(t.years)),
  }));
  await writeContent("teachers", clean);
  return { ok: true, notice: "✓ Хадгалагдлаа" };
}

async function saveNyImpl(ny: Ny): Promise<FormState> {
  const before = (await getContent()).ny;
  const clean: Ny = {
    on: !!ny.on, title: str(ny.title, 200), year: str(ny.year, 10), date: str(ny.date, 20), place: str(ny.place, 200), address: str(ny.address, 300),
    organizer: str(ny.organizer, 200), price: str(ny.price, 100), priceNote: str(ny.priceNote, 300), bankName: str(ny.bankName, 100),
    bankAccount: str(ny.bankAccount, 60), bankHolder: str(ny.bankHolder, 120), payNote: str(ny.payNote, 300), seats: Math.max(0, num(ny.seats)),
    program: arr<Ny["program"][number]>(ny.program).map((p) => ({ t: str(p.t, 40), l: str(p.l, 300) })).filter((p) => p.t || p.l),
    gallery: arr<Ny["gallery"][number]>(ny.gallery).map((g) => ({ src: str(g.src, 500), cap: str(g.cap, 200) })).filter((g) => g.src),
    sponsors: arr<{ n: string }>(ny.sponsors).map((x) => ({ n: str(x.n, 120) })).filter((x) => x.n),
  };
  await writeContent("ny", clean);
  await dropUnused(before.gallery.map((g) => g.src), clean.gallery.map((g) => g.src));
  return { ok: true, notice: "✓ Хадгалагдлаа" };
}

/** Recursively trims strings and drops anything that is not plain data. */
function cleanDeep(v: unknown, depth = 0): unknown {
  if (depth > 6) return undefined;
  if (typeof v === "string") return v.trim().slice(0, 6000);
  if (typeof v === "number") return Number.isFinite(v) ? v : 0;
  if (typeof v === "boolean") return v;
  if (Array.isArray(v)) return v.slice(0, 600).map((x) => cleanDeep(x, depth + 1)).filter((x) => x !== undefined);
  if (v && typeof v === "object") {
    const o: Record<string, unknown> = {};
    for (const [k, val] of Object.entries(v as Record<string, unknown>).slice(0, 40)) {
      if (!/^[A-Za-z]\w{0,30}$/.test(k)) continue;
      const c = cleanDeep(val, depth + 1);
      if (c !== undefined) o[k] = c;
    }
    return o;
  }
  return undefined;
}

/** Every photo path inside a content tree (keys "src" / "photo"). */
function photoPaths(v: unknown, out: string[] = []): string[] {
  if (Array.isArray(v)) v.forEach((x) => photoPaths(x, out));
  else if (v && typeof v === "object") {
    for (const [k, val] of Object.entries(v as Record<string, unknown>)) {
      if ((k === "src" || k === "photo") && typeof val === "string") out.push(val);
      else photoPaths(val, out);
    }
  }
  return out;
}

async function saveSchoolSectionImpl(key: SchoolKey, value: unknown): Promise<FormState> {
  if (!SCHOOL_KEYS.includes(key)) throw new Error("Буруу хэсэг.");
  const current = (await getContent()).school;
  const clean = cleanDeep(value);
  if (clean === undefined) throw new Error("Хоосон өгөгдөл.");
  const next = { ...current, [key]: clean };
  await writeContent("school", next);
  await dropUnused(photoPaths(current[key]), photoPaths(clean));
  return { ok: true, notice: "✓ Хадгалагдлаа" };
}

async function saveAlbumsImpl(albums: Album[]): Promise<FormState> {
  const before = (await getContent()).albums;
  const clean: Album[] = arr<Album>(albums)
    .map((a, i) => ({
      id: str(a.id, 60) || `album-${Date.now()}-${i}`, title: str(a.title, 200), date: str(a.date, 20), cover: str(a.cover, 500),
      photos: arr<GalleryItem>(a.photos).map((g) => ({ src: str(g.src, 500), cap: str(g.cap, 200) })).filter((g) => g.src),
    }))
    .filter((a) => a.title);
  await writeContent("albums", clean);
  const paths = (list: Album[]) => list.flatMap((a) => [a.cover, ...a.photos.map((g) => g.src)]).filter(Boolean);
  await dropUnused(paths(before), paths(clean));
  return { ok: true, notice: "✓ Хадгалагдлаа" };
}

async function saveSportImpl(key: SportKey, sport: Sport): Promise<FormState> {
  if (key !== "basket" && key !== "volley") return { error: "Буруу спорт." };
  const current = (await getContent()).sports;
  const matches: Match[] = arr<Match>(sport.matches)
    .map((m) => ({ stage: "group", zone: str(m.zone, 10) || "А", day: str(m.day, 10), time: str(m.time, 5), home: str(m.home, 80), away: str(m.away, 80), hs: str(m.hs, 4), as: str(m.as, 4) }))
    .filter((m) => m.home && m.away);
  const clean: Sport = {
    title: str(sport.title, 200), season: str(sport.season, 20), status: str(sport.status, 60), dates: str(sport.dates, 120), place: str(sport.place, 200),
    address: str(sport.address, 300), organizer: str(sport.organizer, 200), intro: str(sport.intro, 2000),
    fees: arr<{ l: string; v: string }>(sport.fees).map((f) => ({ l: str(f.l, 200), v: str(f.v, 60) })).filter((f) => f.l || f.v),
    bankName: str(sport.bankName, 100), iban: str(sport.iban, 40), bankAccount: str(sport.bankAccount, 60), bankHolder: str(sport.bankHolder, 120),
    matches, updated: new Date().toISOString(),
  };
  await writeContent("sports", { ...current, [key]: clean });
  return { ok: true, notice: "✓ Хадгалагдлаа" };
}

async function saveFundImpl(fd: FormData): Promise<FormState> {
  const fund: Fund = {
    on: fd.get("on") === "on", title: fstr(fd, "title", 200), desc: fstr(fd, "desc", 1000), goal: num(fd.get("goal")), raised: num(fd.get("raised")),
    donors: num(fd.get("donors")), bankName: fstr(fd, "bankName", 100), bankAccount: fstr(fd, "bankAccount", 60), bankHolder: fstr(fd, "bankHolder", 120),
    updates: fstr(fd, "updates", 4000).split("\n").map((x) => x.trim()).filter(Boolean),
  };
  await writeContent("fund", fund);
  return { ok: true, notice: "✓ Хадгалагдлаа" };
}

async function saveCohortImpl(year: number, cohort: Cohort): Promise<FormState> {
  if (!Number.isInteger(year) || year < 1940 || year > 2100) return { error: "Он буруу байна." };
  const all = (await getContent()).cohorts;
  const before = all[String(year)]?.photo || "";
  const clean: Cohort = {
    photo: str(cohort.photo, 500), teacher: str(cohort.teacher, 120), leader: str(cohort.leader, 120),
    memories: arr<{ t: string; by: string }>(cohort.memories).map((m) => ({ t: str(m.t, 1000), by: str(m.by, 120) })).filter((m) => m.t),
  };
  await writeContent("cohorts", { ...all, [String(year)]: clean });
  await dropUnused([before], [clean.photo]);
  return { ok: true, notice: "✓ Хадгалагдлаа" };
}

async function addNewsImpl(fd: FormData): Promise<FormState> {
  const title = fstr(fd, "title", 200);
  if (!title) return { error: "Гарчиг оруулна уу." };
  const news = (await getContent()).news;
  const item: NewsItem = { id: "n" + Date.now(), date: new Date().toISOString(), title, body: fstr(fd, "body", 4000) };
  await writeContent("news", [item, ...news]);
  return { ok: true, notice: "Нийтлэгдлээ." };
}

export async function deleteNews(id: string) {
  const news = (await getContent()).news;
  await writeContent("news", news.filter((n) => n.id !== id));
}

// ---------------- members ----------------

export async function setProfileStatus(id: string, status: "approved" | "pending") {
  const sb = await requireAdmin();
  const { error } = await sb.from("profiles").update({ status }).eq("id", id);
  if (error) throw new Error(error.message);
  refresh();
}

async function updateProfileImpl(fd: FormData): Promise<FormState> {
  const sb = await requireAdmin();
  const id = fstr(fd, "id", 60);
  const name = fstr(fd, "name", 120);
  if (!id || !name) return { error: "Нэр оруулна уу." };
  const cat = fstr(fd, "cat", 50);
  const { error } = await sb.from("profiles").update({
    name, year: num(fd.get("year")) || null, cat: CATS.includes(cat) ? cat : null, job: fstr(fd, "job", 200), org: fstr(fd, "org", 200),
    loc: fstr(fd, "loc", 200), phone: normalizePhone(fstr(fd, "phone", 30)), tags: splitTags(fstr(fd, "tags", 500)),
    fb: fstr(fd, "fb", 300), ig: fstr(fd, "ig", 100), hide: fd.get("hide") === "on",
    status: fd.get("status") === "approved" ? "approved" : "pending",
  }).eq("id", id);
  if (error) return { error: error.message };
  refresh();
  return { ok: true, notice: "✓ Хадгалагдлаа" };
}

export async function deleteProfile(id: string) {
  const sb = await requireAdmin();
  const { data: prof } = await sb.from("profiles").select("photo").eq("id", id).maybeSingle();
  const { error } = await sb.from("profiles").delete().eq("id", id);
  if (error) throw new Error(error.message);
  if (prof?.photo && isR2Path(prof.photo) && r2Configured()) await deleteObject(prof.photo).catch(() => {});
  refresh();
}

// ---------------- events ----------------

function eventRow(fd: FormData) {
  const type = fstr(fd, "type", 50);
  return {
    title: fstr(fd, "title", 200), date: fstr(fd, "date", 10), type: ETYPES.includes(type) ? type : "Уулзалт",
    place: fstr(fd, "place", 200), descr: fstr(fd, "desc", 2000), proposed: fd.get("proposed") === "on",
  };
}

async function createEventImpl(fd: FormData): Promise<FormState> {
  const sb = await requireAdmin();
  const row = eventRow(fd);
  if (!row.title || !row.date) return { error: "Нэр болон огноо оруулна уу." };
  const { data } = await sb.auth.getUser();
  const { error } = await sb.from("events").insert({ ...row, created_by: data.user!.id });
  if (error) return { error: error.message };
  refresh();
  return { ok: true, notice: "Нэмэгдлээ." };
}

async function updateEventImpl(fd: FormData): Promise<FormState> {
  const sb = await requireAdmin();
  const row = eventRow(fd);
  if (!row.title || !row.date) return { error: "Нэр болон огноо оруулна уу." };
  const { error } = await sb.from("events").update(row).eq("id", fstr(fd, "id", 60));
  if (error) return { error: error.message };
  refresh();
  return { ok: true, notice: "✓ Хадгалагдлаа" };
}

export async function publishEvent(id: string) {
  const sb = await requireAdmin();
  const { error } = await sb.from("events").update({ proposed: false }).eq("id", id);
  if (error) throw new Error(error.message);
  refresh();
}

export async function deleteEvent(id: string) {
  const sb = await requireAdmin();
  const { error } = await sb.from("events").delete().eq("id", id);
  if (error) throw new Error(error.message);
  refresh();
}

// ---------------- voices ----------------

export async function setVoiceStatus(id: string, status: string) {
  if (!VOICE_STATUSES.includes(status)) throw new Error("Буруу төлөв.");
  const sb = await requireAdmin();
  const { error } = await sb.from("voices").update({ status }).eq("id", id);
  if (error) throw new Error(error.message);
  refresh();
}

async function replyVoiceImpl(fd: FormData): Promise<FormState> {
  const sb = await requireAdmin();
  const { error } = await sb.from("voices").update({ reply: fstr(fd, "reply", 3000) }).eq("id", fstr(fd, "id", 60));
  if (error) return { error: error.message };
  refresh();
  return { ok: true, notice: "✓ Хариу нийтлэгдлээ" };
}

export async function deleteVoice(id: string) {
  const sb = await requireAdmin();
  const { error } = await sb.from("voices").delete().eq("id", id);
  if (error) throw new Error(error.message);
  refresh();
}

// ---------------- jobs ----------------

export async function deleteJobAdmin(id: string) {
  const sb = await requireAdmin();
  const { error } = await sb.from("jobs").delete().eq("id", id);
  if (error) throw new Error(error.message);
  refresh();
}

export async function setJobType(id: string, type: string) {
  if (!JOB_TYPES.includes(type)) throw new Error("Буруу төрөл.");
  const sb = await requireAdmin();
  const { error } = await sb.from("jobs").update({ type }).eq("id", id);
  if (error) throw new Error(error.message);
  refresh();
}

// ---------------- New Year bookings ----------------

export async function setBookingStatus(id: string, status: "pending" | "paid" | "cancelled") {
  if (!["pending", "paid", "cancelled"].includes(status)) throw new Error("Буруу төлөв.");
  const sb = await requireAdmin();
  const { error } = await sb.from("ny_bookings").update({ status }).eq("id", id);
  if (error) throw new Error(error.message);
  refresh();
}

export async function deleteBooking(id: string) {
  const sb = await requireAdmin();
  const { error } = await sb.from("ny_bookings").delete().eq("id", id);
  if (error) throw new Error(error.message);
  refresh();
}

// ---------------- exported form actions (errors come back as messages) ----------------

export async function saveSite(_: FormState, fd: FormData): Promise<FormState> {
  return guard(() => saveSiteImpl(fd));
}

export async function saveFund(_: FormState, fd: FormData): Promise<FormState> {
  return guard(() => saveFundImpl(fd));
}

export async function addNews(_: FormState, fd: FormData): Promise<FormState> {
  return guard(() => addNewsImpl(fd));
}

export async function updateProfile(_: FormState, fd: FormData): Promise<FormState> {
  return guard(() => updateProfileImpl(fd));
}

export async function createEvent(_: FormState, fd: FormData): Promise<FormState> {
  return guard(() => createEventImpl(fd));
}

export async function updateEvent(_: FormState, fd: FormData): Promise<FormState> {
  return guard(() => updateEventImpl(fd));
}

export async function replyVoice(_: FormState, fd: FormData): Promise<FormState> {
  return guard(() => replyVoiceImpl(fd));
}

export async function saveEesh(rows: EeshRow[]): Promise<FormState> {
  return guard(() => saveEeshImpl(rows));
}

export async function saveTeachers(rows: Teacher[]): Promise<FormState> {
  return guard(() => saveTeachersImpl(rows));
}

export async function saveNy(ny: Ny): Promise<FormState> {
  return guard(() => saveNyImpl(ny));
}

export async function saveSchoolSection(key: SchoolKey, value: unknown): Promise<FormState> {
  return guard(() => saveSchoolSectionImpl(key, value));
}
export async function saveAlbums(albums: Album[]): Promise<FormState> {
  return guard(() => saveAlbumsImpl(albums));
}
export async function saveSport(key: SportKey, sport: Sport): Promise<FormState> {
  return guard(() => saveSportImpl(key, sport));
}

export async function saveCohort(year: number, cohort: Cohort): Promise<FormState> {
  return guard(() => saveCohortImpl(year, cohort));
}
