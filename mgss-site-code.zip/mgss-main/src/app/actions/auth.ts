"use server";

import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { ensureProfile, siteOrigin, safeNext, type PendingProfile } from "@/lib/auth-helpers";
import { authErrorMessage, EMAIL_RE, normalizePhone, splitTags, validateJoin } from "@/lib/format";

export type FormState = { error?: string; notice?: string; fe?: Record<string, string>; ok?: boolean };

const str = (fd: FormData, k: string) => String(fd.get(k) ?? "");

export async function signIn(_: FormState, fd: FormData): Promise<FormState> {
  const email = str(fd, "email").trim().toLowerCase(), pw = str(fd, "pw");
  if (!email) return { error: "И-мэйл хаягаа оруулна уу." };
  if (!pw) return { error: "Нууц үгээ оруулна уу." };
  if (!EMAIL_RE.test(email)) return { error: "И-мэйл хаяг буруу байна." };
  const sb = await createClient();
  const { data, error } = await sb.auth.signInWithPassword({ email, password: pw });
  if (error) return { error: authErrorMessage(error.message) };
  await ensureProfile(sb, data.user);
  revalidatePath("/", "layout");
  redirect(safeNext(str(fd, "next")));
}

export async function forgotPassword(_: FormState, fd: FormData): Promise<FormState> {
  const email = str(fd, "email").trim().toLowerCase();
  if (!email) return { error: "Эхлээд и-мэйлээ бичнэ үү." };
  const sb = await createClient();
  const { error } = await sb.auth.resetPasswordForEmail(email, {
    redirectTo: `${await siteOrigin()}/auth/confirm?next=/reset-password`,
  });
  if (error) return { error: authErrorMessage(error.message) };
  return { notice: `${email} хаяг руу нууц үг сэргээх холбоос илгээлээ. Спам хавтсаа ч шалгаарай.` };
}

export async function updatePassword(_: FormState, fd: FormData): Promise<FormState> {
  const a = str(fd, "npw"), b = str(fd, "npw2");
  if (a.length < 6) return { error: "Нууц үг 6-аас доошгүй тэмдэгттэй байх ёстой." };
  if (a !== b) return { error: "Нууц үг таарахгүй байна." };
  const sb = await createClient();
  const { error } = await sb.auth.updateUser({ password: a });
  if (error) return { error: authErrorMessage(error.message) };
  redirect("/dashboard");
}

export async function signOut() {
  const sb = await createClient();
  await sb.auth.signOut();
  revalidatePath("/", "layout");
  redirect("/");
}

export async function join(_: FormState, fd: FormData): Promise<FormState> {
  const sb = await createClient();
  const { data: auth } = await sb.auth.getUser();
  const user = auth.user;

  const input = {
    email: str(fd, "email"), pw: str(fd, "pw"), pw2: str(fd, "pw2"),
    name: str(fd, "name"), year: str(fd, "year"), cat: str(fd, "cat"), job: str(fd, "job"), phone: str(fd, "phone"),
  };
  const fe = validateJoin(input, !user);
  if (Object.keys(fe).length) return { fe, error: "Улаанаар тэмдэглэсэн талбаруудыг засна уу." };

  const profile: PendingProfile = {
    name: input.name.trim(), year: parseInt(input.year, 10), cat: input.cat, job: input.job.trim(),
    org: str(fd, "org").trim() || "—", loc: str(fd, "loc").trim() || "—", phone: normalizePhone(input.phone),
    tags: splitTags(str(fd, "tags")),
  };

  if (!user) {
    const email = input.email.trim().toLowerCase();
    const { data, error } = await sb.auth.signUp({
      email, password: input.pw,
      options: { emailRedirectTo: `${await siteOrigin()}/auth/confirm?next=/dashboard`, data: { profile } },
    });
    if (error) return { error: authErrorMessage(error.message) };
    if (data.session && data.user) {
      await ensureProfile(sb, data.user);
      revalidatePath("/", "layout");
      return { ok: true, notice: "Бүртгэл үүслээ. Админ баталгаажуулсны дараа профайл тань сүлжээнд харагдана." };
    }
    return {
      ok: true,
      notice: `${email} хаяг руу баталгаажуулах захидал илгээлээ. Холбоосыг дарсны дараа нэвтэрч орно уу. Админ баталгаажуулсны дараа профайл тань сүлжээнд харагдана.`,
    };
  }

  const { data: existing } = await sb.from("profiles").select("id").eq("user_id", user.id).maybeSingle();
  if (existing) redirect("/dashboard");
  const { error } = await sb.from("profiles").insert({ user_id: user.id, ...profile, hide: false });
  if (error) return { error: error.message };
  revalidatePath("/", "layout");
  return { ok: true, notice: "Профайл үүслээ. Админ баталгаажуулсны дараа сүлжээнд харагдана." };
}
