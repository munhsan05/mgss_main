"use server";

import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { CATS, ETYPES, JOB_TYPES, VOICE_TYPES, normalizePhone, splitTags } from "@/lib/format";
import type { FormState } from "./auth";

const str = (fd: FormData, k: string, max = 2000) => String(fd.get(k) ?? "").trim().slice(0, max);

async function requireUser(next = "/") {
  const sb = await createClient();
  const { data } = await sb.auth.getUser();
  if (!data.user) redirect(`/login?next=${encodeURIComponent(next)}&notice=1`);
  return { sb, user: data.user };
}

const done = () => revalidatePath("/", "layout");

export async function setGoing(eventId: string, on: boolean) {
  const { sb, user } = await requireUser("/events");
  const { error } = on
    ? await sb.from("rsvps").upsert({ event_id: eventId, user_id: user.id })
    : await sb.from("rsvps").delete().eq("event_id", eventId).eq("user_id", user.id);
  if (error) throw new Error(error.message);
  done();
}

export async function setVote(voiceId: string, on: boolean) {
  const { sb, user } = await requireUser("/voice");
  const { error } = on
    ? await sb.from("voice_votes").upsert({ voice_id: voiceId, user_id: user.id })
    : await sb.from("voice_votes").delete().eq("voice_id", voiceId).eq("user_id", user.id);
  if (error) throw new Error(error.message);
  done();
}

export async function proposeEvent(_: FormState, fd: FormData): Promise<FormState> {
  const { sb, user } = await requireUser("/events");
  const title = str(fd, "title", 200), date = str(fd, "date", 10), type = str(fd, "type", 50);
  if (!title || !date) return { error: "Нэр болон огноогоо оруулна уу." };
  if (!ETYPES.includes(type)) return { error: "Төрлөө сонгоно уу." };
  const { error } = await sb.from("events").insert({
    date, type, title, place: str(fd, "place", 200), descr: str(fd, "desc") || "Төгсөгчийн санаачилсан арга хэмжээ.",
    proposed: true, created_by: user.id,
  });
  if (error) return { error: error.message };
  done();
  return { ok: true, notice: "Арга хэмжээ нэмэгдлээ." };
}

export async function addVoice(_: FormState, fd: FormData): Promise<FormState> {
  const sb = await createClient();
  const { data } = await sb.auth.getUser();
  const text = str(fd, "text", 3000), type = str(fd, "type", 50);
  if (!text) return { error: "Саналаа бичнэ үү." };
  if (!VOICE_TYPES.includes(type)) return { error: "Төрлөө сонгоно уу." };
  let by = str(fd, "by", 120);
  if (!by && data.user) {
    const { data: me } = await sb.from("profiles").select("name,year").eq("user_id", data.user.id).maybeSingle();
    if (me) by = `${me.name}, ${me.year} оны төгсөгч`;
  }
  const { error } = await sb.from("voices").insert({ type, text, by_name: by || "Нэргүй", user_id: data.user?.id ?? null });
  if (error) return { error: error.message };
  done();
  return { ok: true, notice: "Илгээлээ. Баярлалаа!" };
}

export async function addJob(_: FormState, fd: FormData): Promise<FormState> {
  const { sb, user } = await requireUser("/jobs");
  const title = str(fd, "title", 200), type = str(fd, "type", 50);
  if (!title) return { error: "Зарын гарчиг оруулна уу." };
  const { error } = await sb.from("jobs").insert({
    type: JOB_TYPES.includes(type) ? type : "Ажил", title, org: str(fd, "org", 200), loc: str(fd, "loc", 200),
    contact: str(fd, "contact", 200), descr: str(fd, "desc"), deadline: str(fd, "deadline", 10) || null, created_by: user.id,
  });
  if (error) return { error: error.message };
  done();
  return { ok: true, notice: "Зар нийтлэгдлээ." };
}

export async function removeJob(id: string) {
  const { sb } = await requireUser("/jobs");
  const { error } = await sb.from("jobs").delete().eq("id", id);
  if (error) throw new Error(error.message);
  done();
}

export async function bookNY(_: FormState, fd: FormData): Promise<FormState> {
  const sb = await createClient();
  const { data } = await sb.auth.getUser();
  const name = str(fd, "name", 120), phone = normalizePhone(str(fd, "phone", 30));
  const seats = Math.min(20, Math.max(1, parseInt(str(fd, "seats"), 10) || 1));
  if (!name) return { error: "Нэрээ оруулна уу." };
  if (!/^\d{8}$/.test(phone)) return { error: "Утасны дугаар 8 оронтой байх ёстой. Ж.нь: 9911 2233" };
  if (str(fd, "website")) return { ok: true }; // honeypot: bots fill hidden fields
  const { error } = await sb.from("ny_bookings").insert({
    name, phone, year: parseInt(str(fd, "year"), 10) || null, seats, note: str(fd, "note", 500), user_id: data.user?.id ?? null,
  });
  if (error) return { error: error.message };
  done();
  return { ok: true, notice: "Захиалга хүлээн авлаа. Төлбөрөө шилжүүлсний дараа баталгаажна." };
}

export async function saveProfile(_: FormState, fd: FormData): Promise<FormState> {
  const { sb, user } = await requireUser("/dashboard");
  const phone = normalizePhone(str(fd, "phone", 30));
  if (phone && !/^\d{8}$/.test(phone)) return { error: "Утасны дугаар 8 оронтой байх ёстой. Ж.нь: 9911 2233" };
  const cat = str(fd, "cat", 50);
  const { error } = await sb
    .from("profiles")
    .update({
      job: str(fd, "job", 200), org: str(fd, "org", 200), loc: str(fd, "loc", 200), phone,
      cat: CATS.includes(cat) ? cat : null, tags: splitTags(str(fd, "tags", 500)),
      fb: str(fd, "fb", 300), ig: str(fd, "ig", 100), hide: fd.get("hide") === "on",
    })
    .eq("user_id", user.id);
  if (error) return { error: error.message };
  done();
  return { ok: true, notice: "✓ Хадгалагдлаа" };
}
