import type { Metadata } from "next";
import Link from "next/link";
import { getApprovedPeople, getContent, getViewer } from "@/lib/data";
import { FIRST_YEAR, cohortNo, decadeLabel } from "@/lib/format";
import { mediaUrl } from "@/lib/media";
import { Avatar, Container, Empty, PageBanner } from "@/components/ui";

export const metadata: Metadata = { title: "Төгсөгчид" };

export default async function CohortsPage({ searchParams }: { searchParams: Promise<{ year?: string; decade?: string }> }) {
  const sp = await searchParams;
  const [c, people, viewer] = await Promise.all([getContent(), getApprovedPeople(), getViewer()]);
  const last = new Date().getFullYear();
  const clamp = (y: number) => Math.min(Math.max(y, FIRST_YEAR), last);
  const year = clamp(parseInt(sp.year || "", 10) || viewer.me?.year || last);
  const decade = parseInt(sp.decade || "", 10) || Math.floor(year / 10) * 10;
  const decades: number[] = [];
  for (let d = Math.floor(FIRST_YEAR / 10) * 10; d <= last; d += 10) decades.push(d);
  const years: number[] = [];
  for (let y = Math.max(decade, FIRST_YEAR); y <= Math.min(decade + 9, last); y++) years.push(y);
  const C = c.cohorts[String(year)] || { photo: "", teacher: "", leader: "", memories: [] };
  const memories = (C.memories || []).filter((m) => m && m.t);
  const members = people.filter((p) => p.year === year);
  const photo = mediaUrl(C.photo);

  return (
    <>
      <PageBanner eyebrow="Үе үеийн төгсөгчид" title="Үе бүр өөрийн түүхтэй" lead="Төгссөн оноо сонгоод тухайн үеийн танилцуулга болон бүртгэлтэй гишүүдтэй танилцаарай." />
      <Container className="flex flex-col gap-6 py-12">
        <nav className="flex flex-wrap gap-2" aria-label="Арван жил">
          {decades.map((d) => (
            <Link key={d} href={`/cohorts?decade=${d}&year=${clamp(d)}`} className={d === decade ? "chip-on" : "chip-off"}>{decadeLabel(d)}</Link>
          ))}
        </nav>
        <nav className="grid grid-cols-2 gap-2 sm:grid-cols-5" aria-label="Он">
          {years.map((y) => (
            <Link key={y} href={`/cohorts?decade=${decade}&year=${y}`} className={`flex flex-col rounded-2xl border px-4 py-3 transition ${y === year ? "border-brand bg-brand text-white" : "border-line bg-white hover:border-sky"}`}>
              <span className="font-serif text-2xl">{y}</span>
              <span className={`text-xs ${y === year ? "text-white/80" : "text-muted"}`}>{cohortNo(y)}-р төгсөлт · {people.filter((p) => p.year === y).length} бүртгэлтэй</span>
            </Link>
          ))}
        </nav>

        <div className="grid gap-6 lg:grid-cols-[1fr_1.2fr]">
          <div className="card flex flex-col gap-4">
            <span className="eyebrow">{cohortNo(year)}-р төгсөлт · {last - year === 0 ? "Энэ жилийн төгсөгчид" : `${last - year} жилийн өмнө`}</span>
            <h2 className="h-serif text-4xl">{year} оны төгсөгчид</h2>
            <div className="relative aspect-[4/3] overflow-hidden rounded-2xl bg-slate-50">
              {photo ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={photo} alt={`${year} оны ангийн зураг`} className="h-full w-full object-cover" />
              ) : (
                <span className="grid h-full place-items-center text-sm text-mist">Ангийн зураг оруулаагүй</span>
              )}
            </div>
            <dl className="grid grid-cols-2 gap-3 text-sm">
              <div><dt className="text-mist">Анги удирдсан багш</dt><dd>{C.teacher || "Мэдээлэл оруулаагүй"}</dd></div>
              <div><dt className="text-mist">Ангийн дарга</dt><dd>{C.leader || "Мэдээлэл оруулаагүй"}</dd></div>
            </dl>
            {memories.length > 0 && (
              <ul className="flex flex-col gap-3">
                {memories.map((m, i) => (
                  <li key={i} className="rounded-2xl border-l-2 border-sky bg-slate-50 px-4 py-3">
                    <p className="font-serif italic">“{m.t}”</p>
                    {m.by && <p className="mt-1 text-xs text-muted">— {m.by}</p>}
                  </li>
                ))}
              </ul>
            )}
            <Link href={viewer.me ? "/dashboard" : "/join"} className="btn-primary self-start">Үеийнхээ танилцуулгыг илгээх</Link>
          </div>
          <div className="card flex flex-col gap-4">
            <span className="font-semibold">Бүртгэлтэй гишүүд · {members.length}</span>
            {members.length === 0 ? (
              <Empty>Энэ оны төгсөгчдөөс бүртгүүлсэн хүн алга. Анхных нь болоорой!</Empty>
            ) : (
              <ul className="grid gap-3 sm:grid-cols-2">
                {members.map((p) => (
                  <li key={p.id} className="flex items-center gap-3">
                    <Avatar name={p.name} photo={p.photo} size={46} />
                    <span className="flex flex-col"><span className="font-medium">{p.name}</span><span className="text-sm text-muted">{p.job}</span></span>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </Container>
    </>
  );
}
