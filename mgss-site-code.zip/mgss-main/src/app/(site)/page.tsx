import Image from "next/image";
import Link from "next/link";
import { getApprovedPeople, getContent, getEvents, getNySeatsBooked, getViewer } from "@/lib/data";
import { FIRST_YEAR, dayMonth, eventTone, fmtAgo, initial, longDateTime, money, tone } from "@/lib/format";
import { mediaUrl } from "@/lib/media";
import { buildAlbums } from "@/lib/gallery";
import { FOUNDED, STAFF } from "@/lib/school-data";
import { Avatar, Container, Empty, SectionTitle } from "@/components/ui";
import { Countdown, CopyButton, Snow } from "@/components/client";
import { NyBookingForm } from "@/components/forms";
import { SportsSection } from "@/components/sports-section";

const PILLARS = [
  { n: "01", t: "Үе үеийн танилцуулга", d: "Төгссөн оноор нь төгсөгчдийн түүх, гишүүдийн мэдээлэл.", cta: "Үеэ олох", href: "/cohorts" },
  { n: "02", t: "Хэн юу хийдэг вэ", d: "Машин, эмч, хуульч хэрэгтэй юу? Өөрийн сургуулийн төгсөгчдөөс олоорой.", cta: "Сүлжээ үзэх", href: "/network" },
  { n: "03", t: "Нээлттэй арга хэмжээ", d: "Уулзалт, хурал, уулын аяллыг хэн ч санаачилж, нэгдэж болно.", cta: "Арга хэмжээ үзэх", href: "/events" },
  { n: "04", t: "Санал хүсэлт", d: "Хурал зөвлөгөөнд санал оруулж, бусдын саналыг дэмжээрэй.", cta: "Санал өгөх", href: "/voice" },
];

export default async function Home() {
  const [c, people, events, viewer, seatsBooked] = await Promise.all([getContent(), getApprovedPeople(), getEvents(), getViewer(), getNySeatsBooked()]);
  const { me } = viewer;
  const thisYear = new Date().getFullYear();
  const published = events; // mgss1 listed proposals too
  const upcoming = published.filter((e) => e.date >= new Date().toISOString().slice(0, 10)).slice(0, 4);
  const recent = people.slice(-4).reverse();
  const albums = buildAlbums(c).slice(0, 5);
  const NY = c.ny, F = c.fund;
  const nyOn = NY.on !== false;
  const fundOn = F.on !== false && !!F.title;
  const goal = +F.goal || 0, raised = +F.raised || 0, pct = goal ? Math.min(100, Math.round((raised / goal) * 100)) : 0;
  const seatsLeft = NY.seats ? Math.max(0, NY.seats - seatsBooked) : null;
  const joinHref = me ? "/dashboard" : "/join";
  const joinCta = me ? "Миний самбар" : viewer.user ? "Профайлаа бөглөх" : "Бүртгүүлэх";
  const news = c.news.slice(0, 5);

  return (
    <>
      {/* ---------- hero: full-width school photo ---------- */}
      <section className="relative h-[72vh] max-h-[780px] min-h-[520px] overflow-hidden">
        <Image src="/img/school.jpg" alt="МГСС Гүнзгий сургуулийн байр" fill priority className="object-cover" sizes="100vw" />
        <div className="absolute inset-0 bg-gradient-to-b from-navy/60 via-navy/25 to-navy/85" />
        <Container className="relative flex h-full flex-col items-center justify-center gap-6 pb-16 text-center text-white">
          <span className="eyebrow">Хархорин · МГСС · {FOUNDED}–{thisYear}</span>
          <h1 className="h-serif max-w-4xl text-[2.1rem] break-words drop-shadow-[0_6px_24px_rgba(0,0,0,.45)] sm:text-6xl lg:text-7xl">{c.site.heroTitle}</h1>
          <p className="max-w-2xl text-base text-white/85 sm:text-lg">Өвөрхангай аймгийн Хархорин сумын Ерөнхий боловсролын гүнзгий сургуулийн үе үеийн төгсөгчид</p>
          <div className="flex flex-wrap justify-center gap-3 pt-2">
            <Link href="/school" className="btn-light">Сургуулийн танилцуулга</Link>
            <Link href="/network" className="btn-primary">Төгсөгчдийн сүлжээ →</Link>
          </div>
        </Container>
      </section>

      {/* ---------- stats strip ---------- */}
      <Container className="relative z-10 -mt-14">
        <dl className="grid grid-cols-2 gap-px overflow-hidden rounded-3xl border border-line bg-line shadow-[0_20px_50px_rgba(0,45,92,.15)] md:grid-cols-4">
          {[
            [thisYear - FIRST_YEAR + 1, "үеийн төгсөгчид"],
            [people.length, "бүртгэлтэй гишүүн"],
            [STAFF.length, "багш, ажилтан"],
            [c.eesh[0]?.v || "—", c.eesh[0]?.label ? `ЭЕШ ${c.eesh[0].label}` : "ЭЕШ"],
          ].map(([v, l]) => (
            <div key={String(l)} className="flex flex-col items-center gap-1 bg-white px-4 py-6 text-center sm:py-7">
              <dt className="sr-only">{l}</dt>
              <dd className="text-3xl font-black text-brand sm:text-4xl">{v}</dd>
              <span className="text-sm text-muted">{l}</span>
            </div>
          ))}
        </dl>
      </Container>

      {/* ---------- news + events ---------- */}
      <section id="news" className="scroll-mt-32 py-12">
        <Container className="flex flex-col gap-8">
          <SectionTitle eyebrow="Мэдээ мэдээлэл" title="Холбооны эргэн тойронд" right={<Link href="/events" className="btn-primary">Бусад мэдээлэл</Link>} />
          <div className="grid gap-6 lg:grid-cols-[1.25fr_1fr]">
            <div className="flex flex-col gap-4">
              {news.length === 0 ? (
                <div className="card flex flex-col gap-3">
                  <span className="text-xs font-bold text-mist">Мэдээ</span>
                  <h3 className="text-2xl font-extrabold">Шинэ мэдээ удахгүй</h3>
                  <p className="text-slate-600">Холбооны мэдээ, зарлал энд гарна. Одоогоор арга хэмжээ, тэмцээний мэдээллийг доорх хэсгүүдээс үзнэ үү.</p>
                </div>
              ) : (
                news.map((n, i) => (
                  <article key={n.id} className={`card flex flex-col gap-2 ${i === 0 ? "border-brand/20 bg-gradient-to-br from-white to-sky/[.07]" : ""}`}>
                    <span className="text-xs font-bold text-mist">📅 {fmtAgo(n.date)}</span>
                    <h3 className={`font-extrabold ${i === 0 ? "text-2xl uppercase" : "text-lg"}`}>{n.title}</h3>
                    {n.body && <p className={`whitespace-pre-line text-slate-600 ${i === 0 ? "" : "line-clamp-3"}`}>{n.body}</p>}
                  </article>
                ))
              )}
            </div>
            <div className="flex flex-col gap-4">
              <div className="card flex flex-col gap-4">
                <div className="flex items-center justify-between"><span className="font-extrabold uppercase">Ойрын арга хэмжээ</span><Link href="/events" className="text-sm font-bold text-sky">Бүгд →</Link></div>
                {upcoming.length === 0 ? <Empty>Одоогоор товлосон арга хэмжээ алга.</Empty> : upcoming.map((e) => {
                  const dm = dayMonth(e.date);
                  return (
                    <Link key={e.id} href="/events" className="flex items-center gap-4 rounded-2xl p-2 hover:bg-paper">
                      <span className="flex w-14 shrink-0 flex-col items-center rounded-xl py-1.5 text-white" style={{ background: eventTone(e.type) }}>
                        <span className="text-xl font-black">{dm.d}</span><span className="text-[11px]">{dm.m}</span>
                      </span>
                      <span className="flex flex-col"><span className="font-bold">{e.title}</span><span className="text-sm text-muted">{[e.type, e.place].filter(Boolean).join(" · ")}</span></span>
                    </Link>
                  );
                })}
              </div>
              <div className="card flex flex-col gap-4">
                <div className="flex items-center justify-between"><span className="font-extrabold uppercase">Шинэ гишүүд</span><Link href="/network" className="text-sm font-bold text-sky">Бүгд →</Link></div>
                {recent.length === 0 ? <Empty>Бүртгэлтэй гишүүдийн мэдээлэл энд харагдана.</Empty> : recent.map((p) => (
                  <div key={p.id} className="flex items-center gap-3">
                    <Avatar name={p.name} photo={p.photo} size={46} />
                    <div className="flex flex-col"><span className="font-bold">{p.name}</span><span className="text-sm text-muted">{p.year} он · {p.job}</span></div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </Container>
      </section>

      {/* ---------- about the school ---------- */}
      <section id="about" className="scroll-mt-32 py-12">
        <Container className="grid gap-8 lg:grid-cols-[1fr_1.1fr] lg:items-center">
          <div className="relative aspect-[4/3] overflow-hidden rounded-[28px] shadow-[0_24px_60px_rgba(0,45,92,.2)]">
            <Image src="/img/school.jpg" alt="МГСС Гүнзгий сургуулийн байр" fill className="object-cover" sizes="(min-width:1024px) 45vw, 100vw" />
            <span className="absolute top-4 left-4 rounded-full bg-white/90 px-3 py-1 text-xs font-extrabold text-brand">{FOUNDED} оноос</span>
          </div>
          <div className="flex flex-col gap-5">
            <SectionTitle eyebrow="Бидний тухай" title="МГСС Гүнзгий сургууль" />
            <p className="text-lg text-slate-600">{c.site.schoolIntro}</p>
            <div className="grid gap-3 sm:grid-cols-3">
              {[
                ["/school", "Танилцуулга", "Түүх, лого, сүлд дуу"],
                ["/school#staff", "Багш нар", `${STAFF.length} багш, ажилтан`],
                ["/school/history", "Түүхэн замнал", "Үе үеийн хамт олон"],
              ].map(([href, t, d]) => (
                <Link key={href} href={href} className="card group flex flex-col gap-1 p-4 transition hover:border-sky sm:p-4">
                  <span className="font-extrabold group-hover:text-brand">{t} →</span>
                  <span className="text-sm text-muted">{d}</span>
                </Link>
              ))}
            </div>
          </div>
        </Container>
      </section>

      {/* ---------- EESH ---------- */}
      {c.eesh.length > 0 && (
        <section className="py-6">
          <Container className="card grid gap-8 lg:grid-cols-[1fr_1.4fr]">
            <SectionTitle eyebrow="Тоон үзүүлэлт" title="ЭЕШ-ийн он жилүүдийн амжилт" lead="Сурагчид нь ЭЕШ-д улсын хэмжээнд тогтмол тэргүүлэгчдийн тоонд ордог." />
            <ul className="flex flex-col gap-5">
              {c.eesh.map((r, i) => {
                const col = r.c === "#9CA3AF" ? "#8A94A6" : r.c || "#004b90";
                return (
                  <li key={i} className="flex flex-col gap-2">
                    <div className="flex items-baseline justify-between gap-4">
                      <span className="font-bold">{r.label}</span>
                      <span className="text-2xl font-black" style={{ color: col }}>{r.v}</span>
                    </div>
                    <div className="h-2.5 overflow-hidden rounded-full bg-paper">
                      <div className="h-full rounded-full" style={{ width: `${r.pct || 0}%`, background: col }} />
                    </div>
                    {r.note && <span className="text-sm text-muted">{r.note}</span>}
                  </li>
                );
              })}
            </ul>
          </Container>
        </section>
      )}

      {/* ---------- pillars ---------- */}
      <section className="py-12">
        <Container className="flex flex-col gap-8">
          <SectionTitle eyebrow="Төгсөгчдийн холбоо" title="Бие биеэ олж, бие биедээ тусалцгаая" />
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {PILLARS.map((p) => (
              <Link key={p.n} href={p.href} className="card group flex flex-col gap-3 transition hover:-translate-y-1 hover:border-sky hover:shadow-[0_18px_40px_rgba(0,75,144,.15)] lg:min-h-64">
                <span className="grid h-11 w-11 place-items-center rounded-2xl bg-brand text-sm font-black text-white">{p.n}</span>
                <span className="text-xl font-extrabold">{p.t}</span>
                <span className="flex-1 text-slate-600">{p.d}</span>
                <span className="font-bold text-sky group-hover:underline">{p.cta} →</span>
              </Link>
            ))}
          </div>
        </Container>
      </section>

      {/* ---------- gallery banner ---------- */}
      <section className="py-12">
        <Container>
          <div className="relative overflow-hidden rounded-[32px] text-white shadow-[0_24px_60px_rgba(0,45,92,.25)]">
            <Image src="/img/bg.jpg" alt="" fill className="object-cover" sizes="(min-width:1024px) 1100px, 100vw" />
            <div className="absolute inset-0 bg-gradient-to-r from-navy/90 via-navy/60 to-navy/30" />
            <div className="relative flex flex-col gap-8 p-7 sm:p-12 lg:flex-row lg:items-end lg:justify-between">
              <div className="flex max-w-lg flex-col gap-4">
                <span className="eyebrow">Зургийн цомог</span>
                <h2 className="h-serif text-3xl sm:text-5xl">Дурсамж дүүрэн мөчүүд</h2>
                <p className="text-white/85">Шинэ жилийн үдэшлэг, ангийн зургууд, багш нар, сургуулийн өдөр тутмын амьдрал нэг дор.</p>
                <Link href="/gallery" className="btn-light w-fit">Бүх цомгийг үзэх</Link>
              </div>
              {albums.length > 0 && <ul className="grid grid-cols-3 gap-3 sm:grid-cols-5 lg:w-[46%]">
                {albums.map((a) => (
                  <li key={a.id}>
                    <Link href={`/gallery/${a.id}`} className="group flex flex-col gap-2">
                      <span className="relative block aspect-square overflow-hidden rounded-2xl border border-white/20 bg-white/10">
                        {a.cover && (
                          // eslint-disable-next-line @next/next/no-img-element
                          <img src={mediaUrl(a.cover)} alt="" loading="lazy" className="absolute inset-0 h-full w-full object-cover grayscale transition duration-500 group-hover:scale-105 group-hover:grayscale-0" />
                        )}
                      </span>
                      <span className="line-clamp-2 text-xs font-bold leading-tight">{a.title}</span>
                    </Link>
                  </li>
                ))}
              </ul>}
            </div>
          </div>
        </Container>
      </section>

      {/* ---------- New Year party ---------- */}
      {nyOn && (
        <section id="ny" className="scroll-mt-32 py-12">
          <Container>
            <div className="relative overflow-hidden rounded-[32px] bg-gradient-to-br from-[#0a63c4] via-brand to-[#002d5c] p-6 text-white shadow-[0_24px_60px_rgba(0,45,92,.3)] sm:p-10">
              <Snow />
              <div className="relative flex flex-col gap-8">
                <div className="flex flex-wrap items-end justify-between gap-6">
                  <div className="flex flex-col gap-3">
                    <span className="eyebrow">Шинэ жил</span>
                    <h2 className="h-serif text-3xl sm:text-5xl">{NY.title || "Шинэ жилийн үдэшлэг"} {NY.year}</h2>
                  </div>
                  {NY.date && <Countdown target={NY.date} />}
                </div>
                <div className="grid gap-6 lg:grid-cols-[1.2fr_1fr]">
                  <div className="flex flex-col gap-5 rounded-3xl border border-white/15 bg-white/10 p-5 backdrop-blur sm:p-6">
                    <dl className="grid gap-4 sm:grid-cols-2">
                      {[
                        ["Огноо", NY.date ? longDateTime(NY.date) : "Тун удахгүй"],
                        ["Байршил", NY.place || "Тун удахгүй"],
                        ["Зохион байгуулагч", NY.organizer || "Төгсөгчдийн холбоо"],
                        ["Тасалбар", NY.price || "Тун удахгүй"],
                      ].map(([k, v]) => (
                        <div key={k}><dt className="text-sm text-white/60">{k}</dt><dd className="font-bold">{v}</dd></div>
                      ))}
                    </dl>
                    {NY.priceNote && <p className="text-sm text-white/80">{NY.priceNote}</p>}
                    {seatsLeft !== null && <p className="text-sm font-bold text-[#FFD57A]">{seatsLeft} суудал үлдсэн ({seatsBooked}/{NY.seats})</p>}
                    <div id="ny-more" className="flex flex-col gap-2">
                      <span className="font-extrabold uppercase">Хөтөлбөр</span>
                      {NY.program.filter((p) => p && (p.t || p.l)).length === 0 ? (
                        <span className="text-sm text-white/70">Хөтөлбөр удахгүй гарна.</span>
                      ) : (
                        <ul className="flex flex-col gap-1.5">
                          {NY.program.filter((p) => p && (p.t || p.l)).map((p, i) => (
                            <li key={i} className="flex gap-4 text-sm"><span className="w-16 shrink-0 font-bold text-[#FFD57A]">{p.t}</span><span>{p.l}</span></li>
                          ))}
                        </ul>
                      )}
                    </div>
                    <div className="rounded-2xl bg-navy/30 p-4 text-sm">
                      <span className="text-white/70">Төлбөр шилжүүлэх</span>
                      <p className="mt-1 font-bold">{NY.bankName || "—"}</p>
                      <p><CopyButton value={NY.bankAccount} className="text-white" /></p>
                      <p className="text-white/80">{NY.bankHolder || "—"}</p>
                      {NY.payNote && <p className="mt-2 text-white/70">{NY.payNote}</p>}
                    </div>
                  </div>
                  <div id="ny-book" className="card flex flex-col gap-4 text-ink">
                    <h3 className="text-2xl font-extrabold">Суудал захиалах</h3>
                    <NyBookingForm defaults={{ name: me?.name || "", phone: me?.phone || "", year: me ? String(me.year) : "" }} />
                  </div>
                </div>
                {NY.gallery.some((g) => g && g.src) && (
                  <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
                    {NY.gallery.filter((g) => g && g.src).slice(0, 4).map((g, i) => (
                      <Link key={i} href="/gallery/ny" className="relative block aspect-[4/3] overflow-hidden rounded-2xl">
                        {/* eslint-disable-next-line @next/next/no-img-element */}
                        <img src={mediaUrl(g.src)} alt={g.cap} loading="lazy" className="h-full w-full object-cover" />
                        {g.cap && <span className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/70 p-2 text-xs">{g.cap}</span>}
                      </Link>
                    ))}
                  </div>
                )}
                {NY.sponsors.some((x) => x && x.n) && (
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-sm text-white/70">Ивээн тэтгэгчид:</span>
                    {NY.sponsors.filter((x) => x && x.n).map((x, i) => <span key={i} className="rounded-full border border-white/30 bg-white/10 px-3 py-1 text-sm font-semibold">{x.n}</span>)}
                  </div>
                )}
              </div>
            </div>
          </Container>
        </section>
      )}

      {/* ---------- sports ---------- */}
      <section id="sports" className="scroll-mt-32 py-12">
        <Container className="flex flex-col gap-6">
          <SectionTitle eyebrow="Спорт" title="Төгсөгчдийн аварга шалгаруулах тэмцээн" />
          <SportsSection sports={c.sports} />
        </Container>
      </section>

      {/* ---------- fund ---------- */}
      {fundOn && (
        <section id="fund" className="scroll-mt-32 py-12">
          <Container className="grid gap-8 lg:grid-cols-[1.2fr_1fr]">
            <div className="flex flex-col gap-4">
              <SectionTitle eyebrow="Сан" title={F.title} />
              {F.desc && <p className="text-lg text-slate-600">{F.desc}</p>}
              {F.updates.filter(Boolean).length > 0 && (
                <ul className="flex flex-col gap-2 text-slate-700">
                  {F.updates.filter(Boolean).map((u, i) => <li key={i} className="flex gap-2"><span className="text-sky">•</span>{u}</li>)}
                </ul>
              )}
            </div>
            <div className="card flex flex-col gap-4">
              <span className="text-4xl font-black text-brand">{money(raised)}</span>
              <span className="text-sm text-muted">{goal ? `Зорилт ${money(goal)}` : "Зорилт удахгүй тодорхой болно"}</span>
              <div className="h-2.5 overflow-hidden rounded-full bg-paper"><div className="h-full rounded-full bg-sky" style={{ width: `${pct}%` }} /></div>
              <div className="flex justify-between text-sm text-muted">
                <span>{goal ? `${pct}% биелсэн` : ""}</span>
                <span>{+F.donors ? `${F.donors} хандивлагч` : ""}</span>
              </div>
              <div className="rounded-2xl bg-paper p-4 text-sm">
                <span className="text-muted">Хандив өгөх</span>
                <p className="mt-1 font-bold">{F.bankName || "—"}</p>
                <p><CopyButton value={F.bankAccount} /></p>
                <p className="text-slate-600">{F.bankHolder || "—"}</p>
              </div>
            </div>
          </Container>
        </section>
      )}

      {/* ---------- CTA ---------- */}
      {!me && (
        <section className="py-12">
          <Container>
            <div className="relative overflow-hidden rounded-[32px] bg-gradient-to-br from-brand via-[#0a63c4] to-sky p-8 text-white shadow-[0_24px_60px_rgba(0,45,92,.3)] sm:p-12">
              <span aria-hidden className="absolute -top-16 -right-10 h-56 w-56 rounded-full border-[22px] border-white/10" />
              <div className="relative flex flex-col items-start gap-5">
                <h2 className="h-serif text-3xl sm:text-5xl">Төгсөгчдийн холбоонд бүртгүүлээрэй</h2>
                <div className="flex items-center gap-3">
                  <div className="flex -space-x-2">
                    {people.slice(0, 5).map((p) => (
                      <span key={p.id} className="grid h-9 w-9 place-items-center rounded-full border-2 border-white font-serif text-sm" style={{ background: tone(p.name) }}>{initial(p.name)}</span>
                    ))}
                  </div>
                  <span className="text-white/85">{people.length ? `${people.length} төгсөгч бүртгүүлсэн байна` : "Бүртгүүлж, үеийнхэнтэйгээ холбогдоорой"}</span>
                </div>
                <Link href={joinHref} className="btn-light">{joinCta} →</Link>
              </div>
            </div>
          </Container>
        </section>
      )}
    </>
  );
}
