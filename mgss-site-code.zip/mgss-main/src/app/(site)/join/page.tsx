import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { getViewer } from "@/lib/data";
import { JoinForm } from "@/components/forms";
import { Container, PageBanner } from "@/components/ui";

export const metadata: Metadata = { title: "Бүртгүүлэх" };

export default async function JoinPage() {
  const viewer = await getViewer();
  if (viewer.me) redirect("/dashboard");
  return (
    <>
      <PageBanner eyebrow="Гишүүнчлэл · үнэ төлбөргүй" title="Төгсөгчдийн бүртгэл" lead="Ажил, үйлчилгээгээ бүртгүүлснээр бусад төгсөгчид тантай холбогдох боломжтой болно." />
      <Container className="max-w-3xl py-12">
        {viewer.user && <p className="notice mb-4">{viewer.user.email} бүртгэлээр нэвтэрсэн байна. Профайлаа бөглөнө үү.</p>}
        <JoinForm needAccount={!viewer.user} currentYear={new Date().getFullYear()} />
        {!viewer.user && (
          <p className="mt-4 text-sm text-muted">
            Бүртгэлтэй юу? <a href="/login" className="text-sky hover:underline">Нэвтрэх</a>
          </p>
        )}
      </Container>
    </>
  );
}
