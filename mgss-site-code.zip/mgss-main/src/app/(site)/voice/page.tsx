import type { Metadata } from "next";
import Link from "next/link";
import { getViewer, getVoices } from "@/lib/data";
import { fmtAgo } from "@/lib/format";
import { setVote } from "@/app/actions/member";
import { ActionButton } from "@/components/client";
import { VoiceForm } from "@/components/forms";
import { Container, Empty, PageBanner } from "@/components/ui";

export const metadata: Metadata = { title: "Санал хүсэлт" };

export default async function VoicePage() {
  const [voices, viewer] = await Promise.all([getVoices(), getViewer()]);
  const list = [...voices].sort((a, b) => b.votes - a.votes);
  const me = viewer.me;

  return (
    <>
      <PageBanner eyebrow="Санал хүсэлт" title="Таны дуу хоолой чухал" lead="Холбоо, сургууль болон хурал зөвлөгөөнд хандсан саналаа нээлттэй илгээж, бусдын саналыг дэмжээрэй." />
      <Container className="grid gap-8 py-12 lg:grid-cols-[1fr_1.4fr]">
        <aside className="flex flex-col gap-3 lg:sticky lg:top-32 lg:self-start">
          <h2 className="h-serif text-2xl">Нээлттэй самбар</h2>
          <VoiceForm defaultBy={me ? `${me.name}, ${me.year} оны төгсөгч` : ""} />
        </aside>
        <div className="flex flex-col gap-4">
          <p className="text-muted">{list.length} санал</p>
          {list.length === 0 && <Empty>Одоогоор санал алга. Эхний саналаа илгээгээрэй!</Empty>}
          {list.map((v) => {
            const meet = v.type === "Хурлын санал";
            return (
              <article key={v.id} className="card flex gap-4">
                {viewer.user ? (
                  <ActionButton action={setVote.bind(null, v.id, !v.myVote)} className={`flex h-fit min-w-14 cursor-pointer flex-col items-center rounded-2xl border px-3 py-2 ${v.myVote ? "border-brand bg-brand text-white" : "border-line bg-white"}`}>
                    <span>▲</span><span className="font-bold">{v.votes}</span>
                  </ActionButton>
                ) : (
                  <Link href="/login?notice=1&next=/voice" className="flex h-fit min-w-14 flex-col items-center rounded-2xl border border-line bg-slate-50 px-3 py-2">
                    <span>▲</span><span className="font-bold">{v.votes}</span>
                  </Link>
                )}
                <div className="flex flex-1 flex-col gap-2">
                  <div className="flex flex-wrap items-center gap-2 text-xs">
                    <span className="rounded-full px-2.5 py-1" style={{ background: meet ? "#FDE2E4" : "#E3ECFF", color: meet ? "#B91C1C" : "#1D4ED8" }}>{v.type}</span>
                    <span className="text-mist">{v.status}</span>
                    <span className="text-mist">{fmtAgo(v.createdAt)}</span>
                  </div>
                  <p className="whitespace-pre-line">{v.text}</p>
                  <p className="text-sm text-mist">— {v.by || "Нэргүй"}</p>
                  {v.reply && (
                    <div className="rounded-2xl border-l-2 border-mint bg-mint/10 px-4 py-3 text-sm">
                      <span className="font-semibold text-mint">Холбооны хариу</span>
                      <p className="mt-1 whitespace-pre-line text-slate-700">{v.reply}</p>
                    </div>
                  )}
                </div>
              </article>
            );
          })}
        </div>
      </Container>
    </>
  );
}
