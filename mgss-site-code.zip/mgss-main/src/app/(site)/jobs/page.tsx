import type { Metadata } from "next";
import Link from "next/link";
import { getJobs, getViewer } from "@/lib/data";
import { JOB_TYPES, dayLabel, fmtAgo } from "@/lib/format";
import { removeJob } from "@/app/actions/member";
import { ConfirmButton } from "@/components/client";
import { JobForm } from "@/components/forms";
import { Container, Empty, PageBanner } from "@/components/ui";

export const metadata: Metadata = { title: "Ажлын зар" };

const TYPE_COLOR: Record<string, string> = { "Ажил": "#DCE8FF", "Дадлага": "#D5F5EC", "Түр ажил": "#FBF0D0" };

export default async function JobsPage({ searchParams }: { searchParams: Promise<{ type?: string }> }) {
  const sp = await searchParams;
  const type = JOB_TYPES.includes(sp.type || "") ? sp.type! : "Бүгд";
  const [jobs, viewer] = await Promise.all([getJobs(), getViewer()]);
  const list = jobs.filter((j) => type === "Бүгд" || j.type === type);

  return (
    <>
      <PageBanner eyebrow="Ажлын зар" title="Төгсөгч төгсөгчдөө ажлын байр санал болгоно" lead="Ажил, дадлага, түр ажлын зараа нийтэлж, сургуулийнхаа төгсөгчдөөс ажилтан олоорой." />
      <Container className="grid gap-8 py-12 lg:grid-cols-[1.4fr_1fr]">
        <div className="flex flex-col gap-4">
          <nav className="flex flex-wrap gap-2">
            {["Бүгд", ...JOB_TYPES].map((t) => (
              <Link key={t} href={t === "Бүгд" ? "/jobs" : `/jobs?type=${encodeURIComponent(t)}`} className={t === type ? "chip-on" : "chip-off"}>{t}</Link>
            ))}
          </nav>
          {list.length === 0 && <Empty>Одоогоор зар алга.</Empty>}
          {list.map((j) => (
            <article key={j.id} className="card flex flex-col gap-2">
              <div className="flex flex-wrap items-center gap-2 text-xs">
                <span className="rounded-full px-2.5 py-1 font-semibold text-navy" style={{ background: TYPE_COLOR[j.type] || "#DCE8FF" }}>{j.type}</span>
                {j.createdAt && <span className="text-mist">{fmtAgo(j.createdAt)}</span>}
                {j.deadline && <span className="text-gold">Эцсийн хугацаа: {dayLabel(j.deadline)}</span>}
              </div>
              <h3 className="text-xl font-semibold">{j.title}</h3>
              <p className="text-sm text-muted">{[j.org, j.loc].filter(Boolean).join(" · ") || "—"}</p>
              {j.descr && <p className="whitespace-pre-line text-slate-600">{j.descr}</p>}
              <div className="flex flex-wrap items-center gap-3 pt-1">
                {j.contact !== null ? (
                  <span className="font-semibold text-sky">☏ {j.contact || "—"}</span>
                ) : (
                  <Link href="/login?notice=1&next=/jobs" className="text-sm text-sky hover:underline">Холбоо барих мэдээллийг харахын тулд нэвтэрнэ үү</Link>
                )}
                {j.isMine && (
                  <ConfirmButton action={removeJob.bind(null, j.id)} message="Энэ зарыг устгах уу?" className="btn-danger ml-auto min-h-9 px-4 py-1.5 text-sm">
                    Устгах
                  </ConfirmButton>
                )}
              </div>
            </article>
          ))}
        </div>
        <aside className="lg:sticky lg:top-32 lg:self-start">
          {viewer.user ? (
            <JobForm />
          ) : (
            <div className="card flex flex-col gap-3">
              <h3 className="h-serif text-2xl">Зар нийтлэх</h3>
              <p className="text-slate-600">Зар нийтлэхийн тулд нэвтэрнэ үү.</p>
              <Link href="/login?notice=1&next=/jobs" className="btn-primary self-start">Нэвтрэх</Link>
            </div>
          )}
        </aside>
      </Container>
    </>
  );
}
