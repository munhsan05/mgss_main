import type { Metadata } from "next";
import Link from "next/link";
import { getContent } from "@/lib/data";
import { buildAlbums } from "@/lib/gallery";
import { mediaUrl } from "@/lib/media";
import { Container, Empty, PageBanner } from "@/components/ui";

export const metadata: Metadata = { title: "Зургийн цомог" };

export default async function GalleryPage() {
  const c = await getContent();
  const albums = buildAlbums(c);
  return (
    <>
      <PageBanner eyebrow="Зургийн цомог" title="Дурсамж дүүрэн зургууд" lead="Шинэ жилийн үдэшлэг, ангийн зургууд, багш нар, сургуулийн өдөр тутмын мөчүүд." />
      <Container className="flex flex-col gap-8 py-12">
        {albums.length === 0 ? (
          <Empty>Одоогоор цомог алга.</Empty>
        ) : (
          <ul className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {albums.map((a) => (
              <li key={a.id}>
                <Link href={`/gallery/${a.id}`} className="card group flex h-full flex-col gap-3 p-3 transition hover:-translate-y-1 hover:shadow-[0_18px_40px_rgba(0,75,144,.15)] sm:p-3">
                  <span className="relative block aspect-[4/3] overflow-hidden rounded-2xl bg-paper">
                    {a.cover ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={mediaUrl(a.cover)} alt={a.title} loading="lazy" className="absolute inset-0 h-full w-full object-cover transition duration-500 group-hover:scale-105" />
                    ) : (
                      <span className="absolute inset-0 grid place-items-center text-muted">Зураггүй</span>
                    )}
                    <span className="absolute top-3 left-3 rounded-full bg-white/90 px-2.5 py-1 text-xs font-extrabold text-brand">{a.photos.length} зураг</span>
                  </span>
                  <span className="flex flex-col gap-0.5 px-2 pb-1">
                    <span className="text-lg font-extrabold leading-tight group-hover:text-brand">{a.title}</span>
                    {a.date && <span className="text-sm text-muted">{a.date}</span>}
                  </span>
                </Link>
              </li>
            ))}
          </ul>
        )}
      </Container>
    </>
  );
}
