import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { getContent } from "@/lib/data";
import { findAlbum } from "@/lib/gallery";
import { mediaUrl } from "@/lib/media";
import { Container, PageBanner } from "@/components/ui";
import { Lightbox } from "@/components/lightbox";

type Props = { params: Promise<{ id: string }> };

export const metadata: Metadata = { title: "Зургийн цомог" };

export default async function AlbumPage({ params }: Props) {
  const { id } = await params;
  const album = findAlbum(await getContent(), id);
  if (!album) notFound();
  const photos = album.photos.map((p) => ({ src: mediaUrl(p.src), cap: p.cap || "" })).filter((p) => p.src);
  return (
    <>
      <PageBanner eyebrow="Зургийн цомог" title={album.title} lead={[album.date, `${photos.length} зураг`].filter(Boolean).join(" · ")}>
        <Link href="/gallery" className="w-fit rounded-full border border-white/40 px-4 py-2 text-sm font-bold text-white hover:bg-white/15">← Бүх цомог</Link>
      </PageBanner>
      <Container className="py-12">
        <Lightbox photos={photos} />
      </Container>
    </>
  );
}
