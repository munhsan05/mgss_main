"use client";

import Link from "next/link";

export default function SiteError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <div className="mx-auto flex max-w-xl flex-col items-start gap-4 px-5 pt-20 pb-24">
      <span className="eyebrow">Алдаа</span>
      <h1 className="h-serif text-4xl">Уучлаарай, алдаа гарлаа</h1>
      <p className="text-slate-600">Түр зуурын алдаа байж магадгүй. Дахин оролдоно уу.</p>
      {error.digest && <p className="text-xs text-mist">Код: {error.digest}</p>}
      <div className="flex gap-3">
        <button onClick={reset} className="btn-primary">Дахин оролдох</button>
        <Link href="/" className="btn-ghost">Нүүр хуудас</Link>
      </div>
    </div>
  );
}
