import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { getViewer } from "@/lib/data";
import { NewPasswordForm } from "@/components/forms";
import { Container, PageBanner } from "@/components/ui";

export const metadata: Metadata = { title: "Шинэ нууц үг" };

export default async function ResetPasswordPage() {
  const viewer = await getViewer();
  // The e-mail link signs the user in first (see /auth/confirm).
  if (!viewer.user) redirect("/login?error=" + encodeURIComponent("Нууц үг сэргээх холбоосоо дахин нээнэ үү."));
  return (
    <>
      <PageBanner eyebrow="Гишүүний хэсэг" title="Шинэ нууц үг" lead={`${viewer.user.email} бүртгэлийн шинэ нууц үгээ оруулна уу.`} />
      <Container className="max-w-xl py-12">
        <NewPasswordForm />
      </Container>
    </>
  );
}
