import type { Metadata } from "next";
import Link from "next/link";
import { getApprovedPeople, getViewer } from "@/lib/data";
import { CATS, socialLinks } from "@/lib/format";
import { Avatar, Container, Empty, PageBanner } from "@/components/ui";
import { PhoneReveal } from "@/components/client";

export const metadata: Metadata = { title: "Сүлжээ" };

export default async function NetworkPage({ searchParams }: { searchParams: Promise<{ q?: string; cat?: string }> }) {
  const sp = await searchParams;
  const q = (sp.q || "").trim();
  const cat = CATS.includes(sp.cat || "") ? sp.cat! : "Бүгд";
  const [people, viewer] = await Promise.all([getApprovedPeople(), getViewer()]);
  const ql = q.toLowerCase();
  const list = people.filter(
    (p) => (cat === "Бүгд" || p.cat === cat) && (!ql || [p.name, p.job, p.org, p.loc, p.cat, ...p.tags].join(" ").toLowerCase().includes(ql)),
  );
  const href = (c: string) => `/network?${new URLSearchParams({ ...(q ? { q } : {}), ...(c !== "Бүгд" ? { cat: c } : {}) })}`;

  return (
    <>
      <PageBanner eyebrow="Хэн юу хийдэг вэ" title="Төгсөгчдийн сүлжээ" lead="Машин, эмч, хуульч, барилгачин хэрэгтэй юу? Хэрэгтэй үйлчилгээгээ өөрийн сургуулийн төгсөгчдөөс олоорой.">
        <form action="/network" className="flex max-w-xl gap-2 rounded-full border border-line bg-slate-50 p-1.5 backdrop-blur">
          {cat !== "Бүгд" && <input type="hidden" name="cat" value={cat} />}
          <input name="q" defaultValue={q} aria-label="Хайх" className="min-w-0 flex-1 bg-transparent px-4 text-white placeholder:text-mist focus:outline-none" placeholder="Машин, эмч, хуульч…" />
          <button className="btn-light">Хайх</button>
        </form>
      </PageBanner>
      <Container className="flex flex-col gap-6 py-12">
        <nav className="flex flex-wrap gap-2" aria-label="Салбар">
          {["Бүгд", ...CATS].map((c) => (
            <Link key={c} href={href(c)} className={c === cat ? "chip-on" : "chip-off"}>{c}</Link>
          ))}
        </nav>
        <p className="text-muted">{list.length} төгсөгч олдлоо</p>
        {list.length === 0 ? (
          <Empty>Хайлтад тохирох төгсөгч олдсонгүй.</Empty>
        ) : (
          <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {list.map((p) => (
              <li key={p.id} className="card flex flex-col gap-4">
                <div className="flex items-center gap-3">
                  <Avatar name={p.name} photo={p.photo} size={52} />
                  <div className="flex min-w-0 flex-col">
                    <span className="truncate font-semibold">{p.name}</span>
                    <span className="text-sm text-muted">{p.year} оны төгсөгч</span>
                  </div>
                </div>
                <div className="flex flex-col gap-1">
                  <span className="text-lg font-medium">{p.job}</span>
                  <span className="text-sm text-muted">{[p.org, p.loc].filter((x) => x && x !== "—").join(" · ")}</span>
                </div>
                {(p.cat || p.tags.length > 0) && (
                  <div className="flex flex-wrap gap-1.5">
                    {p.cat && <span className="rounded-full bg-sky/10 px-2.5 py-1 text-xs text-brand">{p.cat}</span>}
                    {p.tags.map((t) => <span key={t} className="rounded-full bg-slate-50 px-2.5 py-1 text-xs text-slate-600">{t}</span>)}
                  </div>
                )}
                <div className="mt-auto flex flex-col gap-2">
                  {socialLinks(p.fb, p.ig).length > 0 && (
                    <div className="flex gap-2">
                      {socialLinks(p.fb, p.ig).map((s) => (
                        <a key={s.label} href={s.href} target="_blank" rel="noopener noreferrer" className="rounded-full px-3 py-1.5 text-xs font-semibold" style={{ background: s.color }}>{s.label}</a>
                      ))}
                    </div>
                  )}
                  <PhoneReveal phone={p.phone} hidden={p.hide && !p.isMine} loggedIn={!!viewer.user} />
                </div>
              </li>
            ))}
          </ul>
        )}
      </Container>
    </>
  );
}
