import type { Metadata } from "next";
import Link from "next/link";
import { getEvents, getViewer } from "@/lib/data";
import { dayMonth, eventTone } from "@/lib/format";
import { setGoing } from "@/app/actions/member";
import { ActionButton } from "@/components/client";
import { ProposeEventForm } from "@/components/forms";
import { Container, Empty, PageBanner } from "@/components/ui";

export const metadata: Metadata = { title: "Арга хэмжээ" };

export default async function EventsPage() {
  const [events, viewer] = await Promise.all([getEvents(), getViewer()]);
  // Like mgss1: member proposals are public too, labelled "Санал болгосон".
  const list = events;

  return (
    <>
      <PageBanner eyebrow="Нээлттэй арга хэмжээ" title="Уулзалт, хурал, аялал" lead="Сонирхсон арга хэмжээндээ бүртгүүлэх, эсвэл шинэ арга хэмжээ өөрөө санаачлах боломжтой." />
      <Container className="grid gap-8 py-12 lg:grid-cols-[1.4fr_1fr]">
        <div className="flex flex-col gap-4">
          {list.length === 0 && <Empty>Одоогоор арга хэмжээ алга.</Empty>}
          {list.map((e) => {
            const dm = dayMonth(e.date);
            return (
              <article key={e.id} className="card flex gap-4">
                <span className="flex h-fit w-16 shrink-0 flex-col items-center rounded-2xl py-2" style={{ background: eventTone(e.type) }}>
                  <span className="font-serif text-2xl">{dm.d}</span>
                  <span className="text-[11px]">{dm.m}</span>
                </span>
                <div className="flex flex-1 flex-col gap-2">
                  <div className="flex flex-wrap items-center gap-2 text-xs">
                    <span className="rounded-full bg-slate-100 px-2.5 py-1">{e.type}</span>
                    <span className={e.proposed ? "text-gold" : "text-mint"}>{e.proposed ? "Санал болгосон" : "Нээлттэй"}</span>
                  </div>
                  <h3 className="text-xl font-semibold">{e.title}</h3>
                  {e.place && <p className="text-sm text-muted">{e.place}</p>}
                  {e.descr && <p className="text-slate-600">{e.descr}</p>}
                  <div className="flex flex-wrap items-center gap-3 pt-1">
                    {viewer.user ? (
                      <ActionButton action={setGoing.bind(null, e.id, !e.myGoing)} className={e.myGoing ? "btn-primary" : "btn-ghost"}>
                        {e.myGoing ? "✓ Оролцоно" : "Оролцох"}
                      </ActionButton>
                    ) : (
                      <Link href="/login?notice=1&next=/events" className="btn-ghost">Оролцох</Link>
                    )}
                    <span className="text-sm text-muted">{e.going} хүн оролцоно</span>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
        <aside className="lg:sticky lg:top-32 lg:self-start">
          {viewer.user ? (
            <ProposeEventForm />
          ) : (
            <div className="card flex flex-col gap-3">
              <h3 className="h-serif text-2xl">Арга хэмжээ санаачлах</h3>
              <p className="text-slate-600">Шинэ арга хэмжээ санал болгохын тулд нэвтэрнэ үү.</p>
              <Link href="/login?notice=1&next=/events" className="btn-primary self-start">Нэвтрэх</Link>
            </div>
          )}
        </aside>
      </Container>
    </>
  );
}
