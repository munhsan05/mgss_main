import { Header, Footer } from "@/components/site-chrome";
import { supabaseConfigured } from "@/lib/supabase/server";

export default function SiteLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="site site-bg relative flex min-h-screen flex-col overflow-x-clip">
      <Header />
      {!supabaseConfigured() && (
        <p className="bg-accent px-4 py-2 text-center text-sm font-semibold text-white">
          Supabase тохируулаагүй байна: .env.local файлд NEXT_PUBLIC_SUPABASE_URL болон NEXT_PUBLIC_SUPABASE_ANON_KEY оруулна уу.
        </p>
      )}
      <main className="flex-1">{children}</main>
      <Footer />
    </div>
  );
}
