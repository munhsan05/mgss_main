import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { getContent } from "@/lib/data";
import { mediaUrl } from "@/lib/media";
import { Container } from "@/components/ui";
import { PersonCard, Portrait, SchoolNav, StaffCard } from "@/components/school";
import { FOUNDED, FOUNDER, STAFF, STAFF_BY_NAME } from "@/lib/school-data";
import type { Block } from "@/lib/school-content";

export const metadata: Metadata = { title: "Сургуулийн танилцуулга" };

const STEP_COLORS = ["#f7931e", "#e91e63", "#9c27b0", "#1e88e5", "#00bcd4", "#43a047", "#f4511e"];

function Pill({ children }: { children: React.ReactNode }) {
  return <span className="eyebrow">{children}</span>;
}

function Heading({ pill, title, lead }: { pill?: string; title: string; lead?: string }) {
  return (
    <div className="flex flex-col items-center gap-3 text-center">
      {pill && <Pill>{pill}</Pill>}
      <h2 className="h-serif text-3xl sm:text-4xl">{title}</h2>
      {lead && <p className="max-w-2xl text-slate-600">{lead}</p>}
    </div>
  );
}

function Photo({ src, cap, className = "", dark = false }: { src: string; cap: string; className?: string; dark?: boolean }) {
  return (
    <figure className={`flex flex-col gap-2 ${className}`}>
      <span className={`relative block aspect-[4/3] overflow-hidden rounded-2xl ${dark ? "bg-white/10" : "bg-paper shadow-[0_10px_30px_rgba(15,23,42,.08)]"}`}>
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={mediaUrl(src)} alt={cap} loading="lazy" className="absolute inset-0 h-full w-full object-cover" />
      </span>
      {cap && <figcaption className={`text-xs ${dark ? "text-white/75" : "text-muted"}`}>{cap}</figcaption>}
    </figure>
  );
}

function BlockCard({ b }: { b: Block }) {
  return (
    <article className="card flex flex-col gap-4">
      {b.photos[0] && <Photo src={b.photos[0].src} cap={b.photos[0].cap} />}
      <h3 className="text-xl font-black">{b.title}</h3>
      {b.text.map((p, i) => <p key={i} className="text-[15px] text-slate-700">{p}</p>)}
      {b.photos.length > 1 && (
        <div className="grid grid-cols-2 gap-3">
          {b.photos.slice(1).map((p) => <Photo key={p.src} src={p.src} cap={p.cap} />)}
        </div>
      )}
    </article>
  );
}

export default async function SchoolPage() {
  const c = await getContent();
  const S = c.school;
  const thisYear = new Date().getFullYear();
  const founder = S.directors[0];
  // The admin-editable list decides who is shown; missing photo/degree/years fall back to the imported staff data.
  const listed = c.teachers.filter((t) => t.n.trim() && t.n !== "Багшийн нэр");
  const staff = listed.length
    ? listed.map((t) => {
        const d = STAFF_BY_NAME[t.n.trim()];
        return { id: t.id, name: t.n.trim(), role: t.s || d?.role || "", photo: mediaUrl(t.photo) || d?.photo, degree: t.degree || d?.degree, years: t.years || d?.years };
      })
    : STAFF.map((s) => ({ id: s.photo, name: s.name, role: s.role, photo: s.photo, degree: s.degree, years: s.years }));

  return (
    <>
      {/* ---------- 1. founding history on deep blue, curved bottom ---------- */}
      <section className="relative overflow-hidden bg-gradient-to-b from-[#0a5fbf] to-brand pb-24 text-white">
        <div aria-hidden className="pointer-events-none absolute inset-0 opacity-10">
          <span className="absolute -top-20 -left-10 h-72 w-72 rounded-full border-[26px] border-white" />
          <span className="absolute right-[8%] bottom-24 h-40 w-40 rotate-12 rounded-3xl border-[16px] border-white" />
        </div>
        <Container className="relative flex flex-col gap-8 pt-8 sm:pt-10">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <SchoolNav active="/school" />
            <span className="flex items-center gap-3 text-sm font-bold">
              <Image src="/img/logo-ebgs.png" alt="Хархорин ЕБГС-ийн лого" width={48} height={48} />
              Хархорин ЕБГС · {FOUNDED}
            </span>
          </div>
          <div className="grid gap-10 lg:grid-cols-[0.85fr_1.3fr] lg:items-start">
            {founder && (
              <figure className="flex flex-col gap-4">
                <span className="relative block aspect-[4/5] overflow-hidden rounded-2xl bg-white/10 shadow-[0_24px_60px_rgba(0,0,0,.35)]">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={founder.photo.startsWith("/img/history/") ? FOUNDER.photo : mediaUrl(founder.photo)} alt={founder.full} className="absolute inset-0 h-full w-full object-cover object-top" />
                </span>
                <figcaption className="flex flex-col gap-2">
                  <span className="text-2xl font-black uppercase">{founder.full}</span>
                  <span className="font-bold text-white/85">{founder.title} · үүсгэн байгуулагч, анхны захирал ({founder.years})</span>
                  <p className="text-[14px] leading-relaxed text-white/85">{founder.intro}</p>
                  <ul className="flex flex-col gap-1 text-[14px] text-white/85">
                    {founder.career.map((r) => <li key={r} className="flex gap-2"><span>•</span>{r}</li>)}
                  </ul>
                  {founder.awards && (
                    <details className="text-[14px] text-white/85">
                      <summary className="cursor-pointer font-bold text-white">Гавьяа шагнал →</summary>
                      <p className="pt-1">{founder.awards}</p>
                    </details>
                  )}
                </figcaption>
              </figure>
            )}
            <div id="history" className="flex scroll-mt-32 flex-col gap-4">
              <Pill>Бидний түүх</Pill>
              <h1 className="h-serif text-3xl sm:text-5xl">Үүсэл хөгжил</h1>
              {S.history.map((p, i) => <p key={i} className={`text-[14.5px] leading-relaxed ${i === 0 ? "font-bold text-white" : "text-white/90"}`}>{p}</p>)}
              {S.historyPhotos.length > 0 && (
                <div className="grid gap-4 pt-2 sm:grid-cols-2">
                  {S.historyPhotos.map((p) => <Photo key={p.src} src={p.src} cap={p.cap} dark />)}
                </div>
              )}
            </div>
          </div>
        </Container>
        <div aria-hidden className="absolute -bottom-16 left-1/2 h-32 w-[140%] -translate-x-1/2 rounded-[50%] bg-paper" />
      </section>

      {/* ---------- 2. growth: milestones, key figures, name changes ---------- */}
      <section id="timeline" className="scroll-mt-32 py-14">
        <Container className="flex flex-col gap-12">
          <h2 className="h-serif text-center text-3xl sm:text-4xl">Өргөжин хөгжсөн нь</h2>
          <ol className="relative grid grid-cols-2 gap-x-4 gap-y-8 sm:grid-cols-4 lg:grid-cols-7">
            <span aria-hidden className="absolute top-9 right-[7%] left-[7%] hidden h-1 rounded-full bg-gradient-to-r from-[#f7931e] via-[#9c27b0] to-[#43a047] lg:block" />
            {S.milestones.map((m, i) => (
              <li key={i} className="relative flex flex-col items-center gap-2 text-center">
                <span className="grid h-[72px] w-[72px] place-items-center rounded-full text-xl font-black text-white shadow-[0_10px_24px_rgba(0,0,0,.18)]" style={{ background: STEP_COLORS[i % STEP_COLORS.length] }}>{m.year}</span>
                <span className="font-black text-brand">{m.t}</span>
                <span className="text-xs text-slate-600">{m.d}</span>
              </li>
            ))}
          </ol>
          {S.keyFigures.length > 0 && (
            <dl className="grid grid-cols-2 gap-3 md:grid-cols-4">
              {S.keyFigures.map((f, i) => (
                <div key={i} className="card flex flex-col items-center gap-1 py-5 text-center">
                  <dt className="sr-only">{f.l}</dt>
                  <dd className="text-3xl font-black text-brand">{f.v}</dd>
                  <span className="text-sm text-muted">{f.l}</span>
                </div>
              ))}
            </dl>
          )}
          {S.nameChanges.length > 0 && (
            <div className="card border-t-4 border-t-sky">
              <h3 className="mb-3 text-lg font-black">Байгууллагын нэрийн өөрчлөлт</h3>
              <ol className="flex flex-col divide-y divide-line text-[15px]">
                {S.nameChanges.map((n, i) => (
                  <li key={i} className="grid gap-1 py-2.5 sm:grid-cols-[90px_1fr_1.6fr] sm:gap-4">
                    <span className="font-black text-brand">{i + 1}. {n.years}</span>
                    <span className="text-muted">{n.decision}</span>
                    <span className="font-semibold">{n.name}</span>
                  </li>
                ))}
              </ol>
            </div>
          )}
          {S.closing && (
            <blockquote className="mx-auto max-w-4xl rounded-3xl border-l-4 border-brand bg-white px-6 py-6 text-center text-lg text-slate-700 shadow-[0_10px_30px_rgba(15,23,42,.06)] sm:px-10">
              {S.closing}
            </blockquote>
          )}
        </Container>
      </section>

      {/* ---------- 3. directors ---------- */}
      {S.directors.length > 0 && (
        <section id="directors" className="scroll-mt-32 py-10">
          <Container className="flex flex-col gap-8">
            <Heading pill="Удирдлага" title="Үе үеийн захирлууд" lead="Сургуулийг үүсгэн байгуулсан цагаас өнөөг хүртэл удирдсан захирлуудын намтар, гавьяа шагнал." />
            <ul className="grid gap-5 md:grid-cols-2">
              {S.directors.map((d, i) => (
                <li key={i} className="card flex gap-4 sm:gap-5">
                  <Portrait src={mediaUrl(d.photo)} name={d.name || d.full} className="w-24 shrink-0 sm:w-32" />
                  <div className="flex min-w-0 flex-1 flex-col gap-2">
                    <span className="w-fit rounded-full bg-brand/[.08] px-2.5 py-1 text-xs font-black text-brand">{d.years}</span>
                    <h3 className="text-xl font-black leading-tight">{d.full}</h3>
                    <span className="text-sm font-bold text-slate-600">{d.title}</span>
                    <p className="text-sm text-slate-700">{d.intro}</p>
                    {(d.career.length > 0 || d.awards) && (
                      <details className="text-sm">
                        <summary className="cursor-pointer font-bold text-sky">Ажлын намтар, шагнал →</summary>
                        <ul className="flex flex-col gap-1 pt-2 text-slate-700">
                          {d.career.map((r) => <li key={r} className="flex gap-2"><span className="text-sky">•</span>{r}</li>)}
                        </ul>
                        {d.awards && <p className="pt-2 text-slate-600"><b>Гавьяа шагнал:</b> {d.awards}</p>}
                      </details>
                    )}
                  </div>
                </li>
              ))}
            </ul>
          </Container>
        </section>
      )}

      {/* ---------- 4. buildings, naming ---------- */}
      {S.buildings.length > 0 && (
        <section id="buildings" className="scroll-mt-32 py-10">
          <Container className="flex flex-col gap-8">
            <Heading pill="Хичээлийн байр" title="Хичээлийн байртай болсон түүх" />
            <div className="grid gap-5 lg:grid-cols-2">
              {S.buildings.map((b, i) => <BlockCard key={i} b={b} />)}
            </div>
          </Container>
        </section>
      )}

      {/* ---------- 5. olympiad + alumni association ---------- */}
      <section id="olympiad" className="scroll-mt-32 py-10">
        <Container className="flex flex-col gap-5">
          {S.olympiad.title && (
            <article className="relative overflow-hidden rounded-[32px] bg-gradient-to-br from-[#0a63c4] via-brand to-[#002d5c] p-6 text-white shadow-[0_24px_60px_rgba(0,45,92,.3)] sm:p-10">
              <div className="grid gap-8 lg:grid-cols-[1fr_1.3fr] lg:items-center">
                {S.olympiad.photos[0] && <Photo src={S.olympiad.photos[0].src} cap={S.olympiad.photos[0].cap} dark />}
                <div className="flex flex-col gap-4">
                  {S.olympiad.pill && <Pill>{S.olympiad.pill}</Pill>}
                  <h2 className="h-serif text-3xl sm:text-4xl">{S.olympiad.title}</h2>
                  {S.olympiad.text.map((p, i) => <p key={i} className="text-[14.5px] leading-relaxed text-white/90">{p}</p>)}
                </div>
              </div>
            </article>
          )}
          {S.alumni.title && (
            <article id="alumni" className="card grid scroll-mt-32 gap-8 lg:grid-cols-[1.3fr_1fr] lg:items-center">
              <div className="flex flex-col gap-4">
                {S.alumni.pill && <Pill>{S.alumni.pill}</Pill>}
                <h2 className="h-serif text-3xl sm:text-4xl">{S.alumni.title}</h2>
                {S.alumni.text.map((p, i) => <p key={i} className="text-[15px] text-slate-700">{p}</p>)}
                <Link href="/cohorts" className="btn-primary w-fit">Үе үеийн төгсөгчид →</Link>
              </div>
              {S.alumni.photos[0] && <Photo src={S.alumni.photos[0].src} cap={S.alumni.photos[0].cap} />}
            </article>
          )}
        </Container>
      </section>

      {/* ---------- 6. achievements ---------- */}
      {S.achievements.length > 0 && (
        <section id="achievements" className="scroll-mt-32 py-10">
          <Container className="flex flex-col gap-8">
            <Heading pill="Амжилт" title="Хийж хэрэгжүүлсэн ажлын үр дүн" lead="Сургалтын чанарын гол үзүүлэлт болох элсэлтийн шалгалт, төрөлжсөн олимпиад, байгууллагын үнэлгээний амжилтууд." />
            <div className={`grid gap-5 ${S.achievements.length >= 3 ? "lg:grid-cols-3" : "lg:grid-cols-2"}`}>
              {S.achievements.map((col, i) => (
                <div key={i} className="card border-t-4 border-t-sky">
                  <h3 className="mb-3 text-lg font-black">{col.title}</h3>
                  <ul className="flex flex-col gap-2 text-[14.5px] text-slate-700">
                    {col.rows.map((r) => <li key={r} className="flex gap-2"><span className="text-sky">•</span>{r}</li>)}
                  </ul>
                </div>
              ))}
            </div>
          </Container>
        </section>
      )}

      {/* ---------- 7. learning environment ---------- */}
      {S.environment.title && (
        <section id="environment" className="scroll-mt-32 py-10">
          <Container className="flex flex-col gap-6">
            <Heading pill={S.environment.pill || undefined} title={S.environment.title} lead={S.environment.text.join(" ")} />
            <ul className="grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-6">
              {S.environment.photos.map((p) => <li key={p.src}><Photo src={p.src} cap={p.cap} /></li>)}
            </ul>
            <Link href="/gallery/history" className="btn-light self-center">Түүхэн зургийн цомог →</Link>
          </Container>
        </section>
      )}

      {/* ---------- 8. logo symbolism on a blue card ---------- */}
      <section id="symbols" className="scroll-mt-32 py-10">
        <Container>
          <div className="relative overflow-hidden rounded-[32px] bg-gradient-to-br from-[#0a63c4] via-brand to-[#002d5c] px-6 py-12 text-white shadow-[0_24px_60px_rgba(0,45,92,.3)] sm:px-12">
            <div className="relative flex flex-col items-center gap-4 text-center">
              <Pill>Лого</Pill>
              <h2 className="h-serif text-3xl sm:text-4xl">Логоны утга, бэлгэдэл</h2>
              <Image src="/img/logo-ebgs.png" alt="Хархорин ЕБГС-ийн лого" width={150} height={150} className="my-2 drop-shadow-[0_18px_40px_rgba(0,0,0,.4)]" />
            </div>
            <ol className="relative mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {S.logoMeaning.map((m, i) => (
                <li key={i} className="flex flex-col items-center gap-2 text-center">
                  <span className="grid h-12 w-12 place-items-center rounded-full bg-white/15 text-lg font-black">{i + 1}</span>
                  <span className="font-black uppercase">{m.t}</span>
                  <span className="text-sm text-white/85">{m.d}</span>
                </li>
              ))}
            </ol>
          </div>
        </Container>
      </section>

      {/* ---------- 9. about + wide photo ---------- */}
      <section id="about" className="scroll-mt-32 py-14">
        <Container className="flex flex-col items-center gap-6 text-center">
          <Pill>Бидний тухай</Pill>
          <h2 className="h-serif max-w-4xl text-3xl sm:text-5xl">«Эртний нийслэлийн эрдмийн өргөө»</h2>
          <p className="max-w-3xl text-slate-600">{c.site.schoolIntro}</p>
          <div className="relative mt-4 aspect-[21/9] w-full overflow-hidden rounded-3xl shadow-[0_24px_60px_rgba(0,45,92,.2)]">
            <Image src="/img/school.jpg" alt="МГСС Гүнзгий сургуулийн байр" fill className="object-cover" sizes="(min-width:1024px) 1100px, 100vw" />
          </div>
          <p className="text-sm text-muted">Өвөрхангай аймгийн Хархорин сум дахь хичээлийн шинэ байр, 2019 оноос</p>
        </Container>
      </section>

      {/* ---------- 10. leaders, light-blue curved band ---------- */}
      {S.leaders.length > 0 && (
        <section id="leaders" className="scroll-mt-32 rounded-t-[50%_64px] bg-[#e9f1fb] py-16">
          <Container className="flex flex-col gap-10">
            <Heading title="Үе үеийн удирдлагууд" lead={`${FOUNDED} оноос хойш сургуулийг удирдан ажилласан захирал, сургалтын менежер, нийгмийн ажилтнууд.`} />
            {S.leaders.map((g, gi) => (
              <div key={gi} className="flex flex-col gap-4">
                <h3 className="text-xl font-black">{g.title}</h3>
                <ul className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
                  {g.people.map((p, i) => <PersonCard key={i} p={{ ...p, photo: mediaUrl(p.photo) }} />)}
                </ul>
              </div>
            ))}
            <Link href="/school/history" className="btn-primary self-center">Үе үеийн багш, ажилтнуудын бүрэн жагсаалт →</Link>
          </Container>
        </section>
      )}

      {/* ---------- 11. anthem ---------- */}
      {S.anthem.stanzas.length > 0 && (
        <section id="anthem" className="scroll-mt-32 py-16">
          <Container className="flex flex-col items-center gap-6 text-center">
            <h2 className="h-serif text-3xl sm:text-4xl">Сургуулийн сүлд дуу</h2>
            <p className="text-lg font-bold text-brand">«{S.anthem.title}»</p>
            <div className="flex flex-col gap-5 text-[15px] italic leading-relaxed text-slate-700">
              {S.anthem.stanzas.map((stanza, i) => (
                <p key={i}>{stanza.map((line, j) => <span key={j} className="block">{line}</span>)}</p>
              ))}
            </div>
            <p className="text-sm text-muted">{S.anthem.author}</p>
          </Container>
        </section>
      )}

      {/* ---------- 12. current staff ---------- */}
      <section id="staff" className="scroll-mt-32 pb-20">
        <Container className="flex flex-col gap-8">
          <Heading pill="Хамт олон" title={`${thisYear}–${thisYear + 1} оны хичээлийн жилийн багш нар`} />
          <ul className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
            {staff.map((t) => <StaffCard key={t.id} name={t.name} role={t.role} photo={t.photo} degree={t.degree} years={t.years} />)}
          </ul>
          <Link href="/school/staff" className="btn-primary self-center">Багш нарын дэлгэрэнгүй танилцуулга →</Link>
        </Container>
      </section>
    </>
  );
}
