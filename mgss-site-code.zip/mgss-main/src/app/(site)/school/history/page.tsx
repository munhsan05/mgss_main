import type { Metadata } from "next";
import Link from "next/link";
import { Container, PageBanner } from "@/components/ui";
import { HistoryTable, SchoolNav } from "@/components/school";
import { FOUNDED } from "@/lib/school-data";
import { getContent } from "@/lib/data";
import { groupStaffHistory } from "@/lib/school-content";

export const metadata: Metadata = { title: "Түүхэн замнал" };

export default async function SchoolHistoryPage() {
  const S = (await getContent()).school;
  const sections = groupStaffHistory(S.staffHistory);
  return (
    <>
      <PageBanner eyebrow="Түүхэн замнал" title="Үе үеийн багш, ажиллагсад" lead={`${FOUNDED} оноос хойш сургуульд ажилласан удирдлага, багш, ажилчдын жагсаалт, ажилласан он.`}>
        <SchoolNav active="/school/history" />
      </PageBanner>

      <Container className="flex flex-col gap-6 py-16">
        <span className="eyebrow">Он дарааллын товчоон</span>
        <ol className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {S.nameChanges.map((t, i) => (
            <li key={i} className="card flex flex-col gap-1">
              <span className="h-serif text-2xl text-sky">{t.years}</span>
              <span className="font-medium">{t.name}</span>
              <span className="text-sm text-muted">{t.decision}</span>
            </li>
          ))}
        </ol>
        <p className="text-sm text-muted">
          Сургуулийн үүсэл, түүхийг <Link href="/school#history" className="font-semibold text-sky hover:underline">танилцуулга</Link> хуудаснаас уншина уу.
        </p>
      </Container>

      {sections.map((sec) => (
        <Container key={sec.section} className="flex flex-col gap-6 pb-16">
          <h2 className="h-serif text-4xl">{sec.section}</h2>
          <div className={`grid gap-4 md:grid-cols-2 ${sec.groups.length > 4 ? "xl:grid-cols-3" : ""}`}>
            {sec.groups.map((g) => <HistoryTable key={g.title} group={g} />)}
          </div>
        </Container>
      ))}
    </>
  );
}
