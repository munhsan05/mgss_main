import type { Metadata } from "next";
import Link from "next/link";
import { Container, PageBanner } from "@/components/ui";
import { Portrait, SchoolNav } from "@/components/school";
import { getContent } from "@/lib/data";
import { mediaUrl } from "@/lib/media";

export const metadata: Metadata = { title: "Хамт олон" };

export default async function SchoolStaffPage() {
  const { profiles } = (await getContent()).school;
  return (
    <>
      <PageBanner eyebrow="Сургуулийн хамт олон" title="Багш, ажилтнуудын танилцуулга" lead="Сургуулийн үе үеийн багш, ажилтнуудын намтар, мэргэжил, зэрэг цол, шагнал урамшуулал.">
        <SchoolNav active="/school/staff" />
      </PageBanner>
      <Container className="flex flex-col gap-8 py-16">
        <p className="text-muted">
          Энэ хичээлийн жилд ажиллаж буй багш нарын жагсаалтыг <Link href="/school#staff" className="font-semibold text-sky hover:underline">сургуулийн танилцуулга</Link> хуудаснаас үзнэ үү.
        </p>
        <ul className="grid gap-5 md:grid-cols-2">
          {profiles.map((p) => {
            const chips = [
              p.years ? `Боловсролын салбарт ${p.years} жил` : "",
              p.rank,
              p.degree,
            ].filter(Boolean);
            return (
              <li key={p.name + p.photo} className="card flex gap-4 sm:gap-5">
                <Portrait src={mediaUrl(p.photo)} name={p.name} className="w-24 shrink-0 sm:w-32" />
                <div className="flex min-w-0 flex-1 flex-col gap-3">
                  <div className="flex flex-col gap-0.5">
                    <h2 className="font-serif text-2xl leading-tight">{p.surname} {p.given}</h2>
                    <span className="text-slate-600">{p.profession}</span>
                  </div>
                  {chips.length > 0 && (
                    <div className="flex flex-wrap gap-1.5">
                      {chips.map((ch) => <span key={ch} className="rounded-full bg-slate-50 px-2.5 py-1 text-xs text-slate-700">{ch}</span>)}
                    </div>
                  )}
                  <dl className="grid gap-x-4 gap-y-1 text-sm sm:grid-cols-[auto_1fr]">
                    {p.clan && <><dt className="text-mist">Ургийн овог</dt><dd>{p.clan}</dd></>}
                    {p.born && <><dt className="text-mist">Төрсөн</dt><dd>{p.born}</dd></>}
                    {p.school && <><dt className="text-mist">Төгссөн сургууль</dt><dd>{p.school}</dd></>}
                  </dl>
                  {p.awards && (
                    <details className="group text-sm">
                      <summary className="cursor-pointer list-none font-semibold text-sky">
                        <span className="group-open:hidden">Шагнал, урамшуулал →</span>
                        <span className="hidden group-open:inline">Шагнал, урамшуулал</span>
                      </summary>
                      <p className="pt-2 text-slate-600">{p.awards}</p>
                    </details>
                  )}
                </div>
              </li>
            );
          })}
        </ul>
      </Container>
    </>
  );
}
