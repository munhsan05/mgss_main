import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { getViewer } from "@/lib/data";
import { safeNext } from "@/lib/auth-helpers";
import { LoginForm } from "@/components/forms";
import { Container, PageBanner } from "@/components/ui";

export const metadata: Metadata = { title: "Нэвтрэх" };

export default async function LoginPage({ searchParams }: { searchParams: Promise<{ next?: string; notice?: string; error?: string }> }) {
  const sp = await searchParams;
  const viewer = await getViewer();
  if (viewer.user) redirect(viewer.me ? safeNext(sp.next) : "/join");
  return (
    <>
      <PageBanner eyebrow="Гишүүний хэсэг" title="Тавтай морил" lead="Нэвтэрч орсноор профайл, арга хэмжээ, саналаа нэг дороос удирдана." />
      <Container className="max-w-xl py-12">
        <LoginForm next={safeNext(sp.next)} notice={sp.notice ? "Энэ үйлдлийг хийхийн тулд нэвтэрнэ үү." : undefined} error={sp.error} />
      </Container>
    </>
  );
}
