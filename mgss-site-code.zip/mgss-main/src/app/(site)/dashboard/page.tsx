import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { getApprovedPeople, getEvents, getViewer, getVoices } from "@/lib/data";
import { mediaUrl } from "@/lib/media";
import { dayMonth } from "@/lib/format";
import { ProfileForm } from "@/components/forms";
import { AvatarUpload } from "@/components/photo-upload";
import { Avatar, Container, Empty, PageBanner } from "@/components/ui";

export const metadata: Metadata = { title: "Миний самбар" };

export default async function DashboardPage() {
  const viewer = await getViewer();
  if (!viewer.user) redirect("/login?next=/dashboard");
  const me = viewer.me;
  if (!me) redirect("/join");
  const [events, voices, people] = await Promise.all([getEvents(), getVoices(), getApprovedPeople()]);
  const myEvents = events.filter((e) => e.myGoing || e.isMine);
  const myVoices = voices.filter((v) => v.isMine || v.myVote);
  const mates = people.filter((p) => p.year === me.year && p.id !== me.id);

  return (
    <>
      <PageBanner eyebrow="Гишүүний самбар" title={`Сайн байна уу, ${me.name.split(".").pop()}`} lead="Профайлаа шинэчилж, оролцох арга хэмжээ болон саналаа хянаарай." />
      <Container className="grid gap-8 py-12 lg:grid-cols-[1.4fr_1fr]">
        <div className="flex flex-col gap-4">
          {me.status === "pending" && <p className="notice">Таны профайлыг админ баталгаажуулахыг хүлээж байна. Баталгаажсаны дараа сүлжээнд харагдана.</p>}
          <div className="card flex flex-col gap-4">
            <h2 className="h-serif text-2xl">{me.name} · {me.year} оны төгсөгч</h2>
            <AvatarUpload name={me.name} src={mediaUrl(me.photo)} />
          </div>
          <ProfileForm me={me} />
        </div>
        <aside className="flex flex-col gap-4">
          <div className="card flex flex-col gap-3">
            <div className="flex items-center justify-between"><span className="font-semibold">Миний арга хэмжээ</span><Link href="/events" className="text-sm text-sky">Бүгд →</Link></div>
            {myEvents.length === 0 ? <p className="text-sm text-muted">Одоогоор бүртгүүлсэн арга хэмжээ алга.</p> : myEvents.map((e) => {
              const dm = dayMonth(e.date);
              return (
                <div key={e.id} className="flex items-center gap-3 text-sm">
                  <span className="w-14 shrink-0 text-center"><b className="font-serif text-lg">{dm.d}</b><br /><span className="text-xs text-muted">{dm.m}</span></span>
                  <span className="flex flex-col"><span className="font-medium">{e.title}</span><span className="text-xs text-muted">{e.isMine ? "Санаачлагч" : "Оролцогч"}</span></span>
                </div>
              );
            })}
          </div>
          <div className="card flex flex-col gap-3">
            <div className="flex items-center justify-between"><span className="font-semibold">Миний санал</span><Link href="/voice" className="text-sm text-sky">Бүгд →</Link></div>
            {myVoices.length === 0 ? <p className="text-sm text-muted">Одоогоор санал алга.</p> : myVoices.map((v) => (
              <div key={v.id} className="flex flex-col gap-0.5 text-sm">
                <span className="text-xs text-sky">{v.isMine ? "Миний санал" : "Дэмжсэн"} · {v.status} · ▲{v.votes}</span>
                <span className="line-clamp-2">{v.text}</span>
              </div>
            ))}
          </div>
          <div className="card flex flex-col gap-3">
            <div className="flex items-center justify-between"><span className="font-semibold">Ангийнхан · {mates.length}</span><Link href={`/cohorts?year=${me.year}`} className="text-sm text-sky">Үеэ харах →</Link></div>
            {mates.length === 0 ? <Empty>Танай оны төгсөгчдөөс өөр хүн бүртгүүлээгүй байна.</Empty> : mates.slice(0, 8).map((p) => (
              <div key={p.id} className="flex items-center gap-3">
                <Avatar name={p.name} photo={p.photo} size={40} />
                <span className="flex flex-col text-sm"><span className="font-medium">{p.name}</span><span className="text-muted">{p.job}</span></span>
              </div>
            ))}
          </div>
        </aside>
      </Container>
    </>
  );
}
