// Landing page for e-mail links (sign-up confirmation, password reset).
// Supports both link styles:
//   ?token_hash=…&type=…  (recommended e-mail template, works on any device)
//   ?code=…               (default PKCE link, works in the browser that signed up)
import { NextResponse, type NextRequest } from "next/server";
import type { EmailOtpType } from "@supabase/supabase-js";
import { createClient } from "@/lib/supabase/server";
import { ensureProfile, safeNext } from "@/lib/auth-helpers";

export async function GET(req: NextRequest) {
  const url = req.nextUrl;
  const next = safeNext(url.searchParams.get("next"));
  const tokenHash = url.searchParams.get("token_hash");
  const type = url.searchParams.get("type") as EmailOtpType | null;
  const code = url.searchParams.get("code");
  const sb = await createClient();

  let error: string | null = null;
  if (tokenHash && type) {
    const r = await sb.auth.verifyOtp({ token_hash: tokenHash, type });
    error = r.error?.message ?? null;
  } else if (code) {
    const r = await sb.auth.exchangeCodeForSession(code);
    error = r.error?.message ?? null;
  } else {
    error = "missing token";
  }

  if (error) {
    const to = new URL("/login", url.origin);
    to.searchParams.set("error", "Холбоосын хугацаа дууссан эсвэл буруу байна. Дахин оролдоно уу.");
    return NextResponse.redirect(to);
  }

  const { data } = await sb.auth.getUser();
  if (data.user) await ensureProfile(sb, data.user);
  const dest = type === "recovery" ? "/reset-password" : next;
  return NextResponse.redirect(new URL(dest, url.origin));
}
