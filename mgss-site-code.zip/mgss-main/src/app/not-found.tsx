import Link from "next/link";

export default function NotFound() {
  return (
    <div className="grid min-h-screen place-items-center bg-paper p-6 text-ink">
      <div className="flex max-w-md flex-col items-start gap-4">
        <span className="text-xs font-semibold tracking-[.2em] text-sky uppercase">404</span>
        <h1 className="font-serif text-4xl">Хуудас олдсонгүй</h1>
        <p className="text-muted">Таны хайсан хуудас байхгүй эсвэл зөөгдсөн байна.</p>
        <Link href="/" className="btn-primary">Нүүр хуудас</Link>
      </div>
    </div>
  );
}
