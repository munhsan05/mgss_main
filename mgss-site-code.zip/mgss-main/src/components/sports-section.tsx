"use client";

import { useState } from "react";
import { buildZones, POINTS_RULE, SPORT_LABEL, type SportKey } from "@/lib/sports";
import { dayLabel } from "@/lib/format";
import type { Sports } from "@/lib/content";
import { CopyButton } from "./client";

const THEME: Record<SportKey, { accent: string; deep: string }> = {
  basket: { accent: "#E07B1F", deep: "rgba(224,123,31,.14)" },
  volley: { accent: "#0E9F9B", deep: "rgba(14,159,155,.14)" },
};

export function SportsSection({ sports }: { sports: Sports }) {
  const [key, setKey] = useState<SportKey>("basket");
  const T = sports[key], th = THEME[key];
  const zones = buildZones(key, T.matches || []);
  const teams = new Set(zones.flatMap((z) => z.table.map((r) => r.team))).size;
  const fees = (T.fees || []).filter((f) => f && (f.l || f.v));

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-wrap gap-3">
        {(["basket", "volley"] as SportKey[]).map((k) => (
          <button
            key={k}
            type="button"
            onClick={() => setKey(k)}
            className="flex cursor-pointer flex-col items-start rounded-2xl border px-5 py-3 text-left transition"
            style={{ background: k === key ? THEME[k].deep : "#fff", borderColor: k === key ? THEME[k].accent : "#e3e8f0" }}
          >
            <span className="font-semibold">{SPORT_LABEL[k]}</span>
            <span className="text-xs text-slate-600">{sports[k].status || "Бүртгэл"}</span>
          </button>
        ))}
      </div>

      <div className="card flex flex-col gap-5" style={{ borderColor: th.accent + "66" }}>
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="flex max-w-2xl flex-col gap-2">
            <span className="text-xs font-semibold tracking-widest uppercase" style={{ color: th.accent }}>
              {T.status || "Бүртгэл"} · {teams ? `${teams} баг · ${zones.length} зон` : "Бүртгэл нээлттэй"}
            </span>
            <h3 className="h-serif text-3xl">{T.title || SPORT_LABEL[key] + "ийн тэмцээн"}</h3>
            {T.intro && <p className="text-slate-600">{T.intro}</p>}
          </div>
          <dl className="grid min-w-60 gap-2 text-sm">
            <div><dt className="text-mist">Огноо</dt><dd>{T.dates || "Тун удахгүй"}</dd></div>
            <div><dt className="text-mist">Байршил</dt><dd>{T.place || "МГСС-ийн спорт заал"}{T.address && <span className="block text-muted">{T.address}</span>}</dd></div>
            {T.organizer && <div><dt className="text-mist">Зохион байгуулагч</dt><dd>{T.organizer}</dd></div>}
          </dl>
        </div>

        {(fees.length > 0 || T.bankAccount) && (
          <div className="grid gap-4 md:grid-cols-2">
            {fees.length > 0 && (
              <div className="rounded-2xl bg-slate-50 p-4">
                <span className="text-sm text-muted">Бүртгэлийн хураамж</span>
                <ul className="mt-2 flex flex-col gap-2">
                  {fees.map((f, i) => (
                    <li key={i} className="flex justify-between gap-4"><span className="text-slate-700">{f.l}</span><b>{f.v}</b></li>
                  ))}
                </ul>
              </div>
            )}
            {T.bankAccount && (
              <div className="rounded-2xl bg-slate-50 p-4 text-sm">
                <span className="text-muted">Данс</span>
                <p className="mt-2">{T.bankName || "—"}{T.iban && <span className="text-muted"> · IBAN {T.iban}</span>}</p>
                <p><CopyButton value={T.bankAccount} /></p>
                <p className="text-slate-600">{T.bankHolder || "—"}</p>
              </div>
            )}
          </div>
        )}

        {zones.length === 0 ? (
          <p className="text-muted">Хуваарь удахгүй гарна.</p>
        ) : (
          <div className="grid gap-6 lg:grid-cols-2">
            {zones.map((z) => (
              <div key={z.zone} className="flex flex-col gap-3 rounded-2xl border border-line p-4">
                <div className="flex items-baseline justify-between">
                  <h4 className="h-serif text-xl">{z.zone} зон</h4>
                  <span className="text-xs text-muted">{z.played ? `${z.played}/${z.matches.length} тоглолт болсон` : `${z.matches.length} тоглолт`}</span>
                </div>
                <table className="w-full text-sm">
                  <thead className="text-mist">
                    <tr>
                      <th className="py-1 text-left font-medium">#</th><th className="text-left font-medium">Баг</th>
                      <th><abbr title="Тоглосон" className="no-underline">Т</abbr></th>
                      <th><abbr title="Хожсон" className="no-underline">Х</abbr></th>
                      <th><abbr title="Хожигдсон" className="no-underline">ХГ</abbr></th>
                      <th><abbr title="Онооны зөрүү" className="no-underline">+/-</abbr></th>
                      <th>Оноо</th>
                    </tr>
                  </thead>
                  <tbody>
                    {z.table.map((r, i) => (
                      <tr key={r.team} className="border-t border-line text-center">
                        <td className="py-1.5 text-left">
                          <span className="inline-grid h-6 w-6 place-items-center rounded-full text-xs font-bold" style={i < 2 && r.p ? { background: th.accent, color: "#fff" } : { background: "#eef2f8" }}>{r.rank}</span>
                        </td>
                        <td className="text-left font-medium">{r.team}</td>
                        <td>{r.p}</td><td>{r.w}</td><td>{r.l}</td><td>{(r.d > 0 ? "+" : "") + r.d}</td><td className="font-bold">{r.pts}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                <ul className="flex flex-col gap-2">
                  {z.matches.map((m, i) => {
                    const s = m.score, hw = s && s[0] > s[1], aw = s && s[1] > s[0];
                    return (
                      <li key={i} className="flex items-center justify-between gap-3 rounded-xl border px-3 py-2 text-sm" style={{ borderColor: s ? "#e3e8f0" : th.accent + "99", background: s ? "#f8fafc" : th.accent + "14" }}>
                        <span className="w-28 shrink-0 text-xs text-muted">{[m.day ? dayLabel(m.day) : "", m.time].filter(Boolean).join(" · ") || "Хуваарь удахгүй"}</span>
                        <span className="flex flex-1 items-center justify-center gap-2">
                          <span className={hw ? "font-bold" : !s ? "" : "text-mist"}>{m.home}</span>
                          <b className="tabular-nums">{s ? `${s[0]} : ${s[1]}` : "–"}</b>
                          <span className={aw ? "font-bold" : !s ? "" : "text-mist"}>{m.away}</span>
                        </span>
                        <span className="rounded-full px-2 py-0.5 text-[11px] font-semibold" style={s ? { background: "#eef2f8", color: "#60697b" } : { background: th.accent, color: "#fff" }}>
                          {s ? "Дууссан" : "Удахгүй"}
                        </span>
                      </li>
                    );
                  })}
                </ul>
              </div>
            ))}
          </div>
        )}
        <p className="text-xs text-mist">{POINTS_RULE[key]}</p>
      </div>
    </div>
  );
}
