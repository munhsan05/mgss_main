export function TabHeader({ eyebrow, title, children }: { eyebrow: string; title: string; children?: React.ReactNode }) {
  return (
    <header className="flex flex-wrap items-end justify-between gap-4">
      <div className="flex flex-col gap-1">
        <span className="text-xs font-semibold tracking-[.2em] text-brand uppercase">{eyebrow}</span>
        <h1 className="font-serif text-3xl sm:text-4xl">{title}</h1>
      </div>
      {children}
    </header>
  );
}

export function Badge({ tone, children }: { tone: "green" | "red" | "amber" | "grey"; children: React.ReactNode }) {
  const c = { green: "bg-[#E3F1E8] text-[#2F6B4F]", red: "bg-[#FBE9EB] text-accent", amber: "bg-[#FBF3E2] text-[#8A5A12]", grey: "bg-[#F0EDE7] text-muted" }[tone];
  return <span className={`a-badge ${c}`}>{children}</span>;
}

export function AEmpty({ children }: { children: React.ReactNode }) {
  return <p className="border-t border-[#EFEBE4] py-3 text-[14.5px] text-muted">{children}</p>;
}
