"use client";

// Admin editor for the whole "school" content object. Each section saves on its own.
import { useState, useTransition } from "react";
import type { FormState } from "@/app/actions/auth";
import { saveSchoolSection } from "@/app/actions/admin";
import type { Block, Director, HistGroup, LeaderGroup, ListCol, Pic, Profile, SchoolContent, SchoolKey } from "@/lib/school-content";
import { SCHOOL_SECTION_LABELS } from "@/lib/school-content";
import { mediaUrl } from "@/lib/media";
import { MediaUpload } from "@/components/photo-upload";
import { RowsEditor } from "./editors";

// ---------------- small shared bits ----------------

function Msg({ state }: { state: FormState }) {
  if (state.error) return <span className="text-sm font-medium text-accent" role="alert">{state.error}</span>;
  if (state.notice) return <span className="text-sm font-medium text-[#2F6B4F]" role="status">{state.notice}</span>;
  return null;
}

function Text({ label, value, onChange, area = false, rows = 3, className = "" }: { label: string; value: string | number; onChange: (v: string) => void; area?: boolean; rows?: number; className?: string }) {
  return (
    <label className={`a-label ${className}`}>
      {label}
      {area ? <textarea value={String(value ?? "")} onChange={(e) => onChange(e.target.value)} rows={rows} className="a-input" />
        : <input value={String(value ?? "")} onChange={(e) => onChange(e.target.value)} className="a-input" />}
    </label>
  );
}

/** One line per item (blank lines dropped). */
function Lines({ label, value, onChange, rows = 6 }: { label: string; value: string[]; onChange: (v: string[]) => void; rows?: number }) {
  const [text, setText] = useState(value.join("\n"));
  return (
    <label className="a-label">
      {label} <span className="font-normal text-slate-400">— мөр бүр тусдаа</span>
      <textarea value={text} rows={rows} className="a-input" onChange={(e) => { setText(e.target.value); onChange(e.target.value.split("\n").map((s) => s.trim()).filter(Boolean)); }} />
    </label>
  );
}

function PhotoField({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  const src = mediaUrl(value);
  return (
    <div className="flex items-end gap-3">
      {src ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={src} alt="" className="h-20 w-16 shrink-0 rounded-xl object-cover" />
      ) : <span className="grid h-20 w-16 shrink-0 place-items-center rounded-xl bg-paper text-xs text-muted">зураг</span>}
      <Text label={label} value={value} onChange={onChange} className="flex-1" />
      <MediaUpload kind="gallery" label="Байршуулах" onUploaded={onChange} />
    </div>
  );
}

function Pics({ label, value, onChange }: { label: string; value: Pic[]; onChange: (v: Pic[]) => void }) {
  return (
    <div className="flex flex-col gap-2">
      <span className="text-[13px] font-semibold text-slate-600">{label}</span>
      <RowsEditor rows={value} onChange={onChange} blank={() => ({ src: "", cap: "" })} addLabel="+ Зургийн холбоос нэмэх"
        cols={[{ key: "src", label: "Зураг (зам эсвэл холбоос)" }, { key: "cap", label: "Тайлбар" }]}
        extra={(r) => r.src ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={mediaUrl(r.src)} alt="" className="h-10 w-14 rounded-lg object-cover" />
        ) : null} />
      <MediaUpload kind="gallery" label="+ Зураг байршуулах" onUploaded={(src) => onChange([...value, { src, cap: "" }])} />
    </div>
  );
}

/** Generic card list: move / delete / add, with a render function for the card body. */
function Cards<T>({ items, onChange, blank, title, render }: { items: T[]; onChange: (v: T[]) => void; blank: () => T; title: (t: T, i: number) => string; render: (t: T, set: (patch: Partial<T>) => void) => React.ReactNode }) {
  const set = (i: number, patch: Partial<T>) => onChange(items.map((x, j) => (j === i ? { ...x, ...patch } : x)));
  const move = (i: number, d: number) => { const j = i + d; if (j < 0 || j >= items.length) return; const n = [...items]; [n[i], n[j]] = [n[j], n[i]]; onChange(n); };
  return (
    <div className="flex flex-col gap-3">
      {items.map((it, i) => (
        <details key={i} className="rounded-2xl border border-sand bg-[#fbfaf7]">
          <summary className="flex cursor-pointer flex-wrap items-center gap-2 px-4 py-3 font-semibold text-navy">
            <span className="flex-1">{i + 1}. {title(it, i) || "—"}</span>
            <span className="flex gap-1" onClick={(e) => e.preventDefault()}>
              <button type="button" aria-label="Дээш" onClick={() => move(i, -1)} className="a-ghost min-h-8 px-2.5">↑</button>
              <button type="button" aria-label="Доош" onClick={() => move(i, 1)} className="a-ghost min-h-8 px-2.5">↓</button>
              <button type="button" aria-label="Устгах" onClick={() => { if (confirm("Устгах уу?")) onChange(items.filter((_, j) => j !== i)); }} className="a-danger min-h-8 px-3">×</button>
            </span>
          </summary>
          <div className="flex flex-col gap-3 border-t border-sand p-4">{render(it, (p) => set(i, p))}</div>
        </details>
      ))}
      <button type="button" onClick={() => onChange([...items, blank()])} className="a-ghost self-start">+ Нэмэх</button>
    </div>
  );
}

function BlockFields({ b, set }: { b: Block; set: (p: Partial<Block>) => void }) {
  return (
    <>
      <div className="grid gap-3 md:grid-cols-[160px_1fr]">
        <Text label="Жижиг гарчиг (pill)" value={b.pill} onChange={(pill) => set({ pill })} />
        <Text label="Гарчиг" value={b.title} onChange={(title) => set({ title })} />
      </div>
      <Lines label="Текст (догол мөр бүр)" value={b.text} onChange={(text) => set({ text })} rows={8} />
      <Pics label="Зургууд" value={b.photos} onChange={(photos) => set({ photos })} />
    </>
  );
}

// ---------------- the editor ----------------

export function SchoolEditor({ initial }: { initial: SchoolContent }) {
  const [s, setS] = useState<SchoolContent>(initial);
  const [states, setStates] = useState<Partial<Record<SchoolKey, FormState>>>({});
  const [pending, start] = useTransition();
  const [saving, setSaving] = useState<SchoolKey | null>(null);
  const up = <K extends SchoolKey>(k: K, v: SchoolContent[K]) => setS((x) => ({ ...x, [k]: v }));
  const save = (k: SchoolKey) => {
    setSaving(k);
    start(async () => {
      try { setStates((st) => ({ ...st, [k]: {} })); const r = await saveSchoolSection(k, s[k]); setStates((st) => ({ ...st, [k]: r })); }
      catch (e) { setStates((st) => ({ ...st, [k]: { error: (e as Error).message } })); }
      finally { setSaving(null); }
    });
  };

  const Section = ({ k, children }: { k: SchoolKey; children: React.ReactNode }) => (
    <details className="a-card group flex flex-col gap-4" id={k}>
      <summary className="flex cursor-pointer flex-wrap items-center justify-between gap-3">
        <h2 className="font-serif text-xl text-navy">{SCHOOL_SECTION_LABELS[k]}</h2>
        <span className="flex items-center gap-3" onClick={(e) => e.preventDefault()}>
          <Msg state={states[k] || {}} />
          <button type="button" disabled={pending && saving === k} onClick={() => save(k)} className="a-primary">{pending && saving === k ? "Хадгалж байна…" : "Хадгалах"}</button>
        </span>
      </summary>
      <div className="flex flex-col gap-4 pt-4">{children}</div>
    </details>
  );

  const anthemText = s.anthem.stanzas.map((st) => st.join("\n")).join("\n\n");

  return (
    <div className="flex flex-col gap-4">
      <p className="text-sm text-muted">Хэсэг бүрийг нээж засаад тухайн хэсгийн «Хадгалах» товчийг дарна. Хадгалаагүй хэсэг docx-оос үүсгэсэн анхдагч утгаараа харагдана.</p>

      <Section k="history">
        <Lines label="Догол мөрүүд" value={s.history} onChange={(v) => up("history", v)} rows={14} />
      </Section>
      <Section k="historyPhotos">
        <Pics label="Түүхийн хэсгийн доорх зургууд" value={s.historyPhotos} onChange={(v) => up("historyPhotos", v)} />
      </Section>
      <Section k="closing">
        <Text label="Өгүүлбэр" value={s.closing} onChange={(v) => up("closing", v)} area />
      </Section>

      <Section k="milestones">
        <RowsEditor rows={s.milestones} onChange={(v) => up("milestones", v)} blank={() => ({ year: "", t: "", d: "" })}
          cols={[{ key: "year", label: "Он", className: "max-w-24" }, { key: "t", label: "Гарчиг", className: "max-w-56" }, { key: "d", label: "Тайлбар", className: "min-w-64" }]} />
      </Section>
      <Section k="keyFigures">
        <RowsEditor rows={s.keyFigures} onChange={(v) => up("keyFigures", v)} blank={() => ({ v: "", l: "" })}
          cols={[{ key: "v", label: "Тоо", className: "max-w-40" }, { key: "l", label: "Тайлбар" }]} />
      </Section>
      <Section k="nameChanges">
        <RowsEditor rows={s.nameChanges} onChange={(v) => up("nameChanges", v)} blank={() => ({ years: "", decision: "", name: "" })}
          cols={[{ key: "years", label: "Он", className: "max-w-32" }, { key: "decision", label: "Шийдвэр" }, { key: "name", label: "Нэр" }]} />
      </Section>

      <Section k="directors">
        <Cards<Director> items={s.directors} onChange={(v) => up("directors", v)} title={(d) => `${d.full} · ${d.years}`}
          blank={() => ({ name: "", full: "", years: "", title: "", photo: "", intro: "", career: [], awards: "" })}
          render={(d, set) => (
            <>
              <div className="grid gap-3 md:grid-cols-4">
                <Text label="Товч нэр (М.Сугар)" value={d.name} onChange={(name) => set({ name })} />
                <Text label="Бүтэн нэр" value={d.full} onChange={(full) => set({ full })} />
                <Text label="Ажилласан он" value={d.years} onChange={(years) => set({ years })} />
                <Text label="Зэрэг цол" value={d.title} onChange={(title) => set({ title })} />
              </div>
              <PhotoField label="Зураг" value={d.photo} onChange={(photo) => set({ photo })} />
              <Text label="Намтар" value={d.intro} onChange={(intro) => set({ intro })} area rows={4} />
              <Lines label="Ажлын замнал" value={d.career} onChange={(career) => set({ career })} />
              <Text label="Гавьяа шагнал" value={d.awards} onChange={(awards) => set({ awards })} area rows={4} />
            </>
          )} />
      </Section>

      <Section k="buildings">
        <Cards<Block> items={s.buildings} onChange={(v) => up("buildings", v)} title={(b) => b.title} blank={() => ({ pill: "", title: "", text: [], photos: [] })}
          render={(b, set) => <BlockFields b={b} set={set} />} />
      </Section>
      <Section k="olympiad">
        <BlockFields b={s.olympiad} set={(p) => up("olympiad", { ...s.olympiad, ...p })} />
      </Section>
      <Section k="alumni">
        <BlockFields b={s.alumni} set={(p) => up("alumni", { ...s.alumni, ...p })} />
      </Section>
      <Section k="achievements">
        <Cards<ListCol> items={s.achievements} onChange={(v) => up("achievements", v)} title={(a) => a.title} blank={() => ({ title: "", rows: [] })}
          render={(a, set) => (
            <>
              <Text label="Баганын гарчиг" value={a.title} onChange={(title) => set({ title })} />
              <Lines label="Мөрүүд" value={a.rows} onChange={(rows) => set({ rows })} rows={10} />
            </>
          )} />
      </Section>
      <Section k="environment">
        <BlockFields b={s.environment} set={(p) => up("environment", { ...s.environment, ...p })} />
      </Section>

      <Section k="logoMeaning">
        <RowsEditor rows={s.logoMeaning} onChange={(v) => up("logoMeaning", v)} blank={() => ({ t: "", d: "" })}
          cols={[{ key: "t", label: "Гарчиг", className: "max-w-64" }, { key: "d", label: "Тайлбар" }]} />
      </Section>
      <Section k="anthem">
        <div className="grid gap-3 md:grid-cols-2">
          <Text label="Дууны нэр" value={s.anthem.title} onChange={(title) => up("anthem", { ...s.anthem, title })} />
          <Text label="Үг, ая" value={s.anthem.author} onChange={(author) => up("anthem", { ...s.anthem, author })} />
        </div>
        <label className="a-label">
          Шүлэг <span className="font-normal text-slate-400">— бадаг бүрийг хоосон мөрөөр тусгаарлана</span>
          <textarea defaultValue={anthemText} rows={20} className="a-input"
            onChange={(e) => up("anthem", { ...s.anthem, stanzas: e.target.value.split(/\n\s*\n/).map((st) => st.split("\n").map((l) => l.trim()).filter(Boolean)).filter((st) => st.length) })} />
        </label>
      </Section>

      <Section k="leaders">
        <Cards<LeaderGroup> items={s.leaders} onChange={(v) => up("leaders", v)} title={(g) => g.title} blank={() => ({ title: "", people: [] })}
          render={(g, set) => (
            <>
              <Text label="Бүлгийн нэр" value={g.title} onChange={(title) => set({ title })} />
              <RowsEditor rows={g.people} onChange={(people) => set({ people })} blank={() => ({ name: "", photo: "", years: "" })} addLabel="+ Хүн нэмэх"
                cols={[{ key: "name", label: "Нэр", className: "max-w-48" }, { key: "years", label: "Он", className: "max-w-48" }, { key: "photo", label: "Зураг (зам)" }]}
                extra={(r, _i, setRow) => (
                  <span className="flex items-center gap-2">
                    {r.photo && (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={mediaUrl(r.photo)} alt="" className="h-12 w-9 rounded-lg object-cover" />
                    )}
                    <MediaUpload kind="gallery" label="Зураг" onUploaded={(photo) => setRow({ photo })} />
                  </span>
                )} />
            </>
          )} />
      </Section>

      <Section k="profiles">
        <Cards<Profile> items={s.profiles} onChange={(v) => up("profiles", v)} title={(p) => `${p.surname} ${p.given}`.trim()}
          blank={() => ({ name: "", surname: "", given: "", clan: "", photo: "", born: "", school: "", profession: "", years: 0, degree: "", rank: "", awards: "" })}
          render={(p, set) => (
            <>
              <div className="grid gap-3 md:grid-cols-4">
                <Text label="Овог" value={p.surname} onChange={(surname) => set({ surname, name: surname && p.given ? `${surname[0]}.${p.given}` : p.name })} />
                <Text label="Нэр" value={p.given} onChange={(given) => set({ given, name: p.surname && given ? `${p.surname[0]}.${given}` : p.name })} />
                <Text label="Ургийн овог" value={p.clan} onChange={(clan) => set({ clan })} />
                <Text label="Мэргэжил" value={p.profession} onChange={(profession) => set({ profession })} />
                <Text label="Төрсөн он, газар" value={p.born} onChange={(born) => set({ born })} className="md:col-span-2" />
                <Text label="Төгссөн сургууль" value={p.school} onChange={(school) => set({ school })} className="md:col-span-2" />
                <Text label="Боловсролд ажилласан жил" value={p.years} onChange={(v) => set({ years: Number(v) || 0 })} />
                <Text label="Зэрэг, цол" value={p.degree} onChange={(degree) => set({ degree })} />
                <Text label="Мэргэжлийн зэрэг" value={p.rank} onChange={(rank) => set({ rank })} className="md:col-span-2" />
              </div>
              <PhotoField label="Зураг" value={p.photo} onChange={(photo) => set({ photo })} />
              <Text label="Шагнал" value={p.awards} onChange={(awards) => set({ awards })} area rows={3} />
            </>
          )} />
      </Section>

      <Section k="staffHistory">
        <Cards<HistGroup> items={s.staffHistory} onChange={(v) => up("staffHistory", v)} title={(g) => `${g.section} · ${g.title}`} blank={() => ({ section: "Багш нар", title: "", rows: [] })}
          render={(g, set) => (
            <>
              <div className="grid gap-3 md:grid-cols-2">
                <Text label="Хэсэг (Удирдлагууд / Багш нар / Ажилчид)" value={g.section} onChange={(section) => set({ section })} />
                <Text label="Бүлгийн нэр (ж.нь: Математик)" value={g.title} onChange={(title) => set({ title })} />
              </div>
              <RowsEditor rows={g.rows} onChange={(rows) => set({ rows })} blank={() => ({ n: "", years: "" })} addLabel="+ Хүн нэмэх"
                cols={[{ key: "n", label: "Овог нэр" }, { key: "years", label: "Ажилласан он", className: "max-w-56" }]} />
            </>
          )} />
      </Section>

      <Section k="historyAlbum">
        <Pics label="Цомогт орох зургууд" value={s.historyAlbum} onChange={(v) => up("historyAlbum", v)} />
      </Section>
    </div>
  );
}
