"use client";

import { useActionState, useEffect, useRef, useState, useTransition } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import type { FormState } from "@/app/actions/auth";
import { signIn } from "@/app/actions/auth";
import {
  addNews, createEvent, replyVoice, saveAlbums, saveCohort, saveEesh, saveFund, saveNy, saveSite, saveSport, saveTeachers, updateEvent, updateProfile,
} from "@/app/actions/admin";
import type { Album, Cohort, EeshRow, Fund, Ny, Site, Sport, Teacher } from "@/lib/content";
import { roundRobin, SPORT_LABEL, type Match, type SportKey } from "@/lib/sports";
import { CATS, ETYPES } from "@/lib/format";
import { mediaUrl } from "@/lib/media";
import { MediaUpload } from "@/components/photo-upload";

const init: FormState = {};

// ---------------- shared bits ----------------

export function Msg({ state }: { state: FormState }) {
  if (state.error) return <span className="text-sm font-medium text-accent" role="alert">{state.error}</span>;
  if (state.notice) return <span className="text-sm font-medium text-[#2F6B4F]" role="status">{state.notice}</span>;
  return null;
}

function Submit({ children = "Хадгалах", pending }: { children?: React.ReactNode; pending?: boolean }) {
  return <button type="submit" disabled={pending} className="a-primary">{pending ? "Хадгалж байна…" : children}</button>;
}

/** For editors that keep their own state and save via a direct action call. */
function useSaver<T>(save: (v: T) => Promise<FormState>) {
  const [state, setState] = useState<FormState>({});
  const [pending, start] = useTransition();
  const run = (v: T) =>
    start(async () => {
      try { setState(await save(v)); } catch (e) { setState({ error: (e as Error).message }); }
    });
  return { state, pending, run };
}

function useResetOnOk(state: FormState) {
  const ref = useRef<HTMLFormElement>(null);
  useEffect(() => { if (state.ok) ref.current?.reset(); }, [state]);
  return ref;
}

type Col<T> = { key: keyof T & string; label: string; type?: "text" | "number" | "color" | "date" | "time"; placeholder?: string; className?: string };

/** Editable list of rows (add / edit / remove / reorder). Controlled. */
export function RowsEditor<T extends Record<string, unknown>>({ rows, onChange, cols, blank, addLabel = "+ Мөр нэмэх", extra }: {
  rows: T[]; onChange: (rows: T[]) => void; cols: Col<T>[]; blank: () => T; addLabel?: string;
  extra?: (row: T, i: number, set: (patch: Partial<T>) => void) => React.ReactNode;
}) {
  const set = (i: number, patch: Partial<T>) => onChange(rows.map((r, j) => (j === i ? { ...r, ...patch } : r)));
  const move = (i: number, d: number) => {
    const j = i + d;
    if (j < 0 || j >= rows.length) return;
    const next = [...rows];
    [next[i], next[j]] = [next[j], next[i]];
    onChange(next);
  };
  return (
    <div className="flex flex-col gap-2">
      {rows.map((r, i) => (
        <div key={i} className="flex flex-wrap items-end gap-2 rounded-2xl border border-sand bg-[#fbfaf7] p-2.5">
          {cols.map((c) => (
            <label key={c.key} className={`a-label min-w-24 flex-1 ${c.className || ""}`}>
              <span className="text-[11px] font-semibold text-slate-500">{c.label}</span>
              <input
                type={c.type || "text"}
                value={String(r[c.key] ?? "")}
                placeholder={c.placeholder}
                onChange={(e) => set(i, { [c.key]: c.type === "number" ? Number(e.target.value) : e.target.value } as Partial<T>)}
                className={c.type === "color" ? "h-10 w-full cursor-pointer rounded-xl border border-[#d6d1c7]" : "a-input py-2"}
              />
            </label>
          ))}
          {extra?.(r, i, (p) => set(i, p))}
          <div className="flex gap-1">
            <button type="button" aria-label="Дээш" onClick={() => move(i, -1)} className="a-ghost min-h-9 px-2.5">↑</button>
            <button type="button" aria-label="Доош" onClick={() => move(i, 1)} className="a-ghost min-h-9 px-2.5">↓</button>
            <button type="button" aria-label="Устгах" onClick={() => onChange(rows.filter((_, j) => j !== i))} className="a-danger min-h-9 px-3">×</button>
          </div>
        </div>
      ))}
      <button type="button" onClick={() => onChange([...rows, blank()])} className="a-ghost self-start">{addLabel}</button>
    </div>
  );
}

// ---------------- navigation + login ----------------

export function AdminTabs({ tabs }: { tabs: { href: string; label: string; badge?: number }[] }) {
  const path = usePathname();
  return (
    <nav className="flex gap-1 overflow-x-auto md:flex-col">
      {tabs.map((t) => {
        const on = t.href === "/admin" ? path === "/admin" : path.startsWith(t.href);
        return (
          <Link key={t.href} href={t.href} className={`flex shrink-0 items-center justify-between gap-3 rounded-full px-4 py-2.5 text-[14.5px] font-semibold whitespace-nowrap transition ${on ? "bg-white text-navy" : "text-white hover:bg-white/10"}`}>
            <span>{t.label}</span>
            {!!t.badge && <span className="rounded-full bg-accent px-2 py-0.5 text-xs text-white">{t.badge}</span>}
          </Link>
        );
      })}
    </nav>
  );
}

export function AdminLogin() {
  const [state, action, pending] = useActionState(signIn, init);
  return (
    <form action={action} className="flex w-full max-w-md flex-col gap-4 rounded-[28px] bg-white p-9">
      <input type="hidden" name="next" value="/admin" />
      <h1 className="font-serif text-3xl text-navy">Админ</h1>
      <p className="text-sm text-muted">Админ эрх олгогдсон бүртгэлээрээ нэвтэрнэ үү.</p>
      <label className="a-label">И-мэйл<input name="email" type="email" required className="a-input" autoComplete="email" /></label>
      <label className="a-label">Нууц үг<input name="pw" type="password" required className="a-input" autoComplete="current-password" /></label>
      <Msg state={state} />
      <Submit pending={pending}>Нэвтрэх</Submit>
    </form>
  );
}

// ---------------- content tab ----------------

export function SiteForm({ site }: { site: Site }) {
  const [state, action, pending] = useActionState(saveSite, init);
  return (
    <form action={action} className="a-card grid gap-4 md:grid-cols-2">
      <h2 className="font-serif text-2xl text-navy md:col-span-2">Нүүр хуудас</h2>
      <label className="a-label md:col-span-2">Гарчиг<input name="heroTitle" defaultValue={site.heroTitle} className="a-input" /></label>
      <label className="a-label md:col-span-2">Танилцуулга<textarea name="heroLead" defaultValue={site.heroLead} rows={2} className="a-input" /></label>
      <label className="a-label md:col-span-2">Сургуулийн танилцуулга<textarea name="schoolIntro" defaultValue={site.schoolIntro} rows={5} className="a-input" /></label>
      <label className="a-label">Холбоо барих и-мэйл<input name="contactEmail" defaultValue={site.contactEmail} className="a-input" /></label>
      <label className="a-label">Холбоо барих утас<input name="contactPhone" defaultValue={site.contactPhone} className="a-input" /></label>
      <div className="flex items-center gap-3 md:col-span-2"><Submit pending={pending} /><Msg state={state} /></div>
    </form>
  );
}

export function EeshEditor({ initial }: { initial: EeshRow[] }) {
  const [rows, setRows] = useState(initial);
  const { state, pending, run } = useSaver(saveEesh);
  return (
    <div className="a-card flex flex-col gap-4">
      <h2 className="font-serif text-2xl text-navy">ЭЕШ-ийн амжилт</h2>
      <RowsEditor rows={rows} onChange={setRows} blank={() => ({ label: "Шинэ он", v: "", pct: 50, c: "#0D47A8", note: "" })}
        cols={[
          { key: "label", label: "Он", className: "max-w-32" }, { key: "v", label: "Үзүүлэлт", className: "max-w-28" },
          { key: "pct", label: "Багана %", type: "number", className: "max-w-24" }, { key: "c", label: "Өнгө", type: "color", className: "max-w-16" },
          { key: "note", label: "Тайлбар", className: "min-w-56" },
        ]} />
      <div className="flex items-center gap-3"><button type="button" disabled={pending} onClick={() => run(rows)} className="a-primary">{pending ? "Хадгалж байна…" : "Хадгалах"}</button><Msg state={state} /></div>
    </div>
  );
}

export function TeachersEditor({ initial }: { initial: Teacher[] }) {
  const [rows, setRows] = useState(initial);
  const { state, pending, run } = useSaver(saveTeachers);
  return (
    <div className="a-card flex flex-col gap-4">
      <h2 className="font-serif text-2xl text-navy">Удирдлага, багш нар</h2>
      <p className="text-sm text-muted">Сургуулийн хуудасны «Багш нар» хэсэгт энэ жагсаалт зураг, зэрэг, ажилласан жилтэйгээ харагдана.</p>
      <RowsEditor rows={rows} onChange={setRows} addLabel="+ Багш нэмэх" blank={() => ({ id: "teacher-" + Date.now(), n: "Багшийн нэр", s: "Хичээл", photo: "", degree: "", years: 0 })}
        cols={[{ key: "n", label: "Нэр", className: "max-w-44" }, { key: "s", label: "Албан тушаал / хичээл" }, { key: "degree", label: "Зэрэг", className: "max-w-32" }, { key: "years", label: "Жил", type: "number", className: "max-w-20" }]}
        extra={(r, _i, set) => (
          <span className="flex items-center gap-2">
            {r.photo && (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={mediaUrl(r.photo)} alt="" className="h-12 w-9 rounded-lg object-cover" />
            )}
            <MediaUpload kind="gallery" label="Зураг" onUploaded={(photo) => set({ photo })} />
          </span>
        )} />
      <div className="flex items-center gap-3"><button type="button" disabled={pending} onClick={() => run(rows)} className="a-primary">{pending ? "Хадгалж байна…" : "Хадгалах"}</button><Msg state={state} /></div>
    </div>
  );
}

// ---------------- members / events / voices / news / fund ----------------

export function ProfileEditForm({ p }: { p: { id: string; name: string; year: number; cat: string; job: string; org: string; loc: string; phone: string | null; tags: string[]; fb: string; ig: string; hide: boolean; status: string } }) {
  const [state, action, pending] = useActionState(updateProfile, init);
  return (
    <form action={action} className="grid gap-3 pt-3 md:grid-cols-3">
      <input type="hidden" name="id" value={p.id} />
      <label className="a-label">Нэр<input name="name" defaultValue={p.name} className="a-input" /></label>
      <label className="a-label">Он<input name="year" defaultValue={p.year || ""} className="a-input" /></label>
      <label className="a-label">Салбар<select name="cat" defaultValue={p.cat} className="a-input"><option value="">—</option>{CATS.map((c) => <option key={c}>{c}</option>)}</select></label>
      <label className="a-label">Ажил<input name="job" defaultValue={p.job} className="a-input" /></label>
      <label className="a-label">Байгууллага<input name="org" defaultValue={p.org} className="a-input" /></label>
      <label className="a-label">Байршил<input name="loc" defaultValue={p.loc} className="a-input" /></label>
      <label className="a-label">Утас<input name="phone" defaultValue={p.phone || ""} className="a-input" /></label>
      <label className="a-label">Түлхүүр үгс<input name="tags" defaultValue={p.tags.join(", ")} className="a-input" /></label>
      <label className="a-label">Facebook<input name="fb" defaultValue={p.fb} className="a-input" /></label>
      <label className="a-label">Instagram<input name="ig" defaultValue={p.ig} className="a-input" /></label>
      <label className="a-label">Төлөв<select name="status" defaultValue={p.status} className="a-input"><option value="pending">Хүлээгдэж буй</option><option value="approved">Баталгаажсан</option></select></label>
      <label className="flex items-center gap-2 text-sm text-slate-600"><input type="checkbox" name="hide" defaultChecked={p.hide} /> Утсаа нууцалсан</label>
      <div className="flex items-center gap-3 md:col-span-3"><Submit pending={pending} /><Msg state={state} /></div>
    </form>
  );
}

export function EventForm({ e }: { e?: { id: string; title: string; date: string; type: string; place: string; descr: string; proposed: boolean } }) {
  const [state, action, pending] = useActionState(e ? updateEvent : createEvent, init);
  const ref = useResetOnOk(e ? {} : state);
  return (
    <form ref={ref} action={action} className="grid gap-3 md:grid-cols-2">
      {e && <input type="hidden" name="id" value={e.id} />}
      <label className="a-label md:col-span-2">Нэр<input name="title" required defaultValue={e?.title} className="a-input" /></label>
      <label className="a-label">Огноо<input name="date" type="date" required defaultValue={e?.date} className="a-input" /></label>
      <label className="a-label">Төрөл<select name="type" defaultValue={e?.type || ETYPES[0]} className="a-input">{ETYPES.map((t) => <option key={t}>{t}</option>)}</select></label>
      <label className="a-label md:col-span-2">Байршил<input name="place" defaultValue={e?.place} className="a-input" /></label>
      <label className="a-label md:col-span-2">Тайлбар<textarea name="desc" rows={3} defaultValue={e?.descr} className="a-input" /></label>
      {e && <label className="flex items-center gap-2 text-sm text-slate-600"><input type="checkbox" name="proposed" defaultChecked={e.proposed} /> Санал (нийтлээгүй)</label>}
      <div className="flex items-center gap-3 md:col-span-2"><Submit pending={pending}>{e ? "Хадгалах" : "+ Шинэ арга хэмжээ"}</Submit><Msg state={state} /></div>
    </form>
  );
}

export function ReplyForm({ id, reply }: { id: string; reply: string }) {
  const [state, action, pending] = useActionState(replyVoice, init);
  return (
    <form action={action} className="flex flex-col gap-2">
      <input type="hidden" name="id" value={id} />
      <textarea name="reply" defaultValue={reply} rows={2} className="a-input" placeholder="Холбооны хариу (сайт дээр нийтлэгдэнэ)" />
      <div className="flex items-center gap-3"><Submit pending={pending}>Нийтлэх</Submit><Msg state={state} /></div>
    </form>
  );
}

export function NewsForm() {
  const [state, action, pending] = useActionState(addNews, init);
  const ref = useResetOnOk(state);
  return (
    <form ref={ref} action={action} className="a-card flex flex-col gap-3">
      <h2 className="font-serif text-2xl text-navy">Мэдээ нийтлэх</h2>
      <label className="a-label">Гарчиг<input name="title" required className="a-input" /></label>
      <label className="a-label">Агуулга<textarea name="body" rows={4} className="a-input" /></label>
      <div className="flex items-center gap-3"><Submit pending={pending}>Нийтлэх</Submit><Msg state={state} /></div>
    </form>
  );
}

export function FundForm({ fund }: { fund: Fund }) {
  const [state, action, pending] = useActionState(saveFund, init);
  return (
    <form action={action} className="a-card grid gap-4 md:grid-cols-2">
      <label className="flex items-center gap-2 font-semibold text-navy md:col-span-2"><input type="checkbox" name="on" defaultChecked={fund.on !== false} /> Нүүр хуудсанд харуулах</label>
      <label className="a-label md:col-span-2">Гарчиг<input name="title" defaultValue={fund.title} className="a-input" /></label>
      <label className="a-label md:col-span-2">Тайлбар<textarea name="desc" defaultValue={fund.desc} rows={3} className="a-input" /></label>
      <label className="a-label">Зорилт (₮)<input name="goal" defaultValue={fund.goal || ""} inputMode="numeric" className="a-input" /></label>
      <label className="a-label">Цугласан (₮)<input name="raised" defaultValue={fund.raised || ""} inputMode="numeric" className="a-input" /></label>
      <label className="a-label">Хандивлагчид<input name="donors" defaultValue={fund.donors || ""} inputMode="numeric" className="a-input" /></label>
      <label className="a-label">Банк<input name="bankName" defaultValue={fund.bankName} className="a-input" /></label>
      <label className="a-label">Дансны дугаар<input name="bankAccount" defaultValue={fund.bankAccount} className="a-input" /></label>
      <label className="a-label">Данс эзэмшигч<input name="bankHolder" defaultValue={fund.bankHolder} className="a-input" /></label>
      <label className="a-label md:col-span-2">Мэдээ, тайлан (мөр бүр нэг)<textarea name="updates" defaultValue={fund.updates.join("\n")} rows={4} className="a-input" /></label>
      <div className="flex items-center gap-3 md:col-span-2"><Submit pending={pending} /><Msg state={state} /></div>
    </form>
  );
}

// ---------------- New Year ----------------

function Field({ label, value, onChange, type = "text", className = "", area = false }: { label: string; value: string | number; onChange: (v: string) => void; type?: string; className?: string; area?: boolean }) {
  return (
    <label className={`a-label ${className}`}>
      {label}
      {area ? <textarea value={String(value ?? "")} onChange={(e) => onChange(e.target.value)} rows={3} className="a-input" />
        : <input type={type} value={String(value ?? "")} onChange={(e) => onChange(e.target.value)} className="a-input" />}
    </label>
  );
}

export function NyEditor({ initial }: { initial: Ny }) {
  const [ny, setNy] = useState<Ny>(initial);
  const { state, pending, run } = useSaver(saveNy);
  const f = <K extends keyof Ny>(k: K) => (v: string) => setNy((n) => ({ ...n, [k]: v }));
  return (
    <div className="a-card flex flex-col gap-5">
      <label className="flex items-center gap-2 font-semibold text-navy"><input type="checkbox" checked={ny.on !== false} onChange={(e) => setNy({ ...ny, on: e.target.checked })} /> Нүүр хуудсанд харуулах</label>
      <div className="grid gap-4 md:grid-cols-3">
        <Field label="Гарчиг" value={ny.title} onChange={f("title")} className="md:col-span-2" />
        <Field label="Он" value={ny.year} onChange={f("year")} />
        <Field label="Огноо, цаг" type="datetime-local" value={ny.date} onChange={f("date")} />
        <Field label="Байршил" value={ny.place} onChange={f("place")} />
        <Field label="Хаяг" value={ny.address} onChange={f("address")} />
        <Field label="Зохион байгуулагч" value={ny.organizer} onChange={f("organizer")} />
        <Field label="Тасалбарын үнэ" value={ny.price} onChange={f("price")} />
        <Field label="Үнийн тайлбар" value={ny.priceNote} onChange={f("priceNote")} />
        <Field label="Нийт суудал (0 = хязгааргүй)" type="number" value={ny.seats} onChange={(v) => setNy({ ...ny, seats: Number(v) || 0 })} />
        <Field label="Банк" value={ny.bankName} onChange={f("bankName")} />
        <Field label="Дансны дугаар" value={ny.bankAccount} onChange={f("bankAccount")} />
        <Field label="Данс эзэмшигч" value={ny.bankHolder} onChange={f("bankHolder")} />
        <Field label="Гүйлгээний утга" value={ny.payNote} onChange={f("payNote")} className="md:col-span-3" />
      </div>
      <div className="flex flex-col gap-2">
        <span className="font-semibold text-navy">Хөтөлбөр</span>
        <RowsEditor rows={ny.program} onChange={(program) => setNy({ ...ny, program })} blank={() => ({ t: "", l: "" })}
          cols={[{ key: "t", label: "Цаг", placeholder: "18:00", className: "max-w-28" }, { key: "l", label: "Үйл ажиллагаа" }]} />
      </div>
      <div className="flex flex-col gap-2">
        <span className="font-semibold text-navy">Өмнөх жилүүдийн зураг</span>
        <RowsEditor rows={ny.gallery} onChange={(gallery) => setNy({ ...ny, gallery })} blank={() => ({ src: "", cap: "" })}
          cols={[{ key: "src", label: "Зураг (R2 зам эсвэл холбоос)", placeholder: "https://…/2016.jpg" }, { key: "cap", label: "Тайлбар" }]}
          extra={(r) => r.src ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={mediaUrl(r.src)} alt="" className="h-10 w-14 rounded-lg object-cover" />
          ) : null} />
        <MediaUpload kind="gallery" label="+ Зураг байршуулах" onUploaded={(src) => setNy((n) => ({ ...n, gallery: [...n.gallery, { src, cap: "" }] }))} />
      </div>
      <div className="flex flex-col gap-2">
        <span className="font-semibold text-navy">Ивээн тэтгэгчид</span>
        <RowsEditor rows={ny.sponsors} onChange={(sponsors) => setNy({ ...ny, sponsors })} blank={() => ({ n: "" })} cols={[{ key: "n", label: "Нэр" }]} />
      </div>
      <div className="sticky bottom-3 flex items-center gap-3 rounded-full bg-white/90 p-2 backdrop-blur">
        <button type="button" disabled={pending} onClick={() => run(ny)} className="a-primary">{pending ? "Хадгалж байна…" : "Хадгалах"}</button>
        <Msg state={state} />
      </div>
    </div>
  );
}

// ---------------- photo albums ----------------

export function AlbumsEditor({ initial }: { initial: Album[] }) {
  const [albums, setAlbums] = useState<Album[]>(initial);
  const { state, pending, run } = useSaver(saveAlbums);
  const set = (i: number, patch: Partial<Album>) => setAlbums((l) => l.map((a, j) => (j === i ? { ...a, ...patch } : a)));
  return (
    <div className="flex flex-col gap-4">
      {albums.length === 0 && <p className="text-sm text-muted">Цомог алга. «Цомог нэмэх» дарж эхлээрэй.</p>}
      {albums.map((a, i) => (
        <div key={a.id} className="a-card flex flex-col gap-4">
          <div className="grid gap-4 md:grid-cols-[1fr_200px_auto]">
            <Field label="Цомгийн нэр" value={a.title} onChange={(v) => set(i, { title: v })} />
            <Field label="Огноо" type="date" value={a.date} onChange={(v) => set(i, { date: v })} />
            <button type="button" className="a-danger self-end" onClick={() => { if (confirm("Энэ цомгийг устгах уу?")) setAlbums((l) => l.filter((_, j) => j !== i)); }}>Устгах</button>
          </div>
          <RowsEditor rows={a.photos} onChange={(photos) => set(i, { photos })} blank={() => ({ src: "", cap: "" })} addLabel="+ Зургийн холбоос нэмэх"
            cols={[{ key: "src", label: "Зураг (R2 зам эсвэл холбоос)" }, { key: "cap", label: "Тайлбар" }]}
            extra={(r) => r.src ? (
              <span className="flex items-center gap-2">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={mediaUrl(r.src)} alt="" className="h-10 w-14 rounded-lg object-cover" />
                <button type="button" className={`a-badge cursor-pointer ${a.cover === r.src ? "bg-brand text-white" : "bg-paper text-muted"}`} onClick={() => set(i, { cover: r.src })}>
                  {a.cover === r.src ? "Нүүр зураг" : "Нүүр болгох"}
                </button>
              </span>
            ) : null} />
          <MediaUpload kind="gallery" label="+ Зураг байршуулах" onUploaded={(src) => setAlbums((l) => l.map((x, j) => (j === i ? { ...x, photos: [...x.photos, { src, cap: "" }] } : x)))} />
        </div>
      ))}
      <div className="sticky bottom-3 flex flex-wrap items-center gap-3 rounded-full bg-white/90 p-2 backdrop-blur">
        <button type="button" className="a-ghost" onClick={() => setAlbums((l) => [...l, { id: "album-" + Date.now(), title: "Шинэ цомог", date: new Date().toISOString().slice(0, 10), cover: "", photos: [] }])}>+ Цомог нэмэх</button>
        <button type="button" disabled={pending} onClick={() => run(albums)} className="a-primary">{pending ? "Хадгалж байна…" : "Хадгалах"}</button>
        <Msg state={state} />
      </div>
    </div>
  );
}

// ---------------- sports ----------------

export function SportEditor({ sportKey, initial }: { sportKey: SportKey; initial: Sport }) {
  const [sp, setSp] = useState<Sport>({ ...initial, matches: initial.matches.filter((m) => !m.stage || m.stage === "group") });
  const [gen, setGen] = useState({ zone: "А", day: "2026-11-14", time: "10:00", step: "40", teams: "" });
  const { state, pending, run } = useSaver((v: Sport) => saveSport(sportKey, v));
  const f = <K extends keyof Sport>(k: K) => (v: string) => setSp((s) => ({ ...s, [k]: v }));
  const genTeams = gen.teams.split(",").map((x) => x.trim()).filter(Boolean);
  const zones = new Set(sp.matches.map((m) => m.zone || "А")).size;

  const generate = () => {
    if (genTeams.length < 2) { alert("Дор хаяж 2 баг таслалаар бичнэ үү."); return; }
    const z = gen.zone.trim() || "А";
    const made = roundRobin(genTeams, { zone: z, day: gen.day, start: gen.time, stepMin: Number(gen.step) || 0 });
    setSp((s) => ({ ...s, matches: [...s.matches.filter((m) => (m.zone || "А") !== z), ...made] }));
    setGen((g) => ({ ...g, teams: "", zone: String.fromCharCode(z.charCodeAt(0) + 1) }));
  };

  return (
    <div className="a-card flex flex-col gap-5">
      <h2 className="font-serif text-2xl text-navy">{SPORT_LABEL[sportKey]}</h2>
      <div className="grid gap-4 md:grid-cols-3">
        <Field label="Гарчиг" value={sp.title} onChange={f("title")} className="md:col-span-2" />
        <Field label="Төлөв" value={sp.status} onChange={f("status")} />
        <Field label="Огноо" value={sp.dates} onChange={f("dates")} />
        <Field label="Байршил" value={sp.place} onChange={f("place")} />
        <Field label="Хаяг" value={sp.address} onChange={f("address")} />
        <Field label="Зохион байгуулагч" value={sp.organizer} onChange={f("organizer")} />
        <Field label="Банк" value={sp.bankName} onChange={f("bankName")} />
        <Field label="IBAN" value={sp.iban} onChange={f("iban")} />
        <Field label="Дансны дугаар" value={sp.bankAccount} onChange={f("bankAccount")} />
        <Field label="Данс эзэмшигч" value={sp.bankHolder} onChange={f("bankHolder")} />
        <Field label="Танилцуулга" value={sp.intro} onChange={f("intro")} className="md:col-span-3" area />
      </div>
      <div className="flex flex-col gap-2">
        <span className="font-semibold text-navy">Бүртгэлийн хураамж</span>
        <RowsEditor rows={sp.fees} onChange={(fees) => setSp({ ...sp, fees })} blank={() => ({ l: "", v: "" })} cols={[{ key: "l", label: "Хэнд" }, { key: "v", label: "Дүн", className: "max-w-36" }]} />
      </div>

      <div className="flex flex-col gap-3 rounded-2xl border border-[#DCE5F5] bg-[#F3F6FC] p-4">
        <span className="text-sm font-semibold text-navy">Хурдан үүсгэх: багуудаа бичээд «Хуваарь үүсгэх» дарна</span>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
          <Field label="Зон" value={gen.zone} onChange={(v) => setGen({ ...gen, zone: v })} />
          <Field label="Өдөр" type="date" value={gen.day} onChange={(v) => setGen({ ...gen, day: v })} />
          <Field label="Эхлэх цаг" type="time" value={gen.time} onChange={(v) => setGen({ ...gen, time: v })} />
          <Field label="Тоглолт хоорондын зай (минут)" type="number" value={gen.step} onChange={(v) => setGen({ ...gen, step: v })} />
          <Field label="Багууд (таслалаар)" value={gen.teams} onChange={(v) => setGen({ ...gen, teams: v })} />
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <button type="button" onClick={generate} className="a-primary">Хуваарь үүсгэх</button>
          {genTeams.length >= 2 && <span className="text-sm text-slate-600">{genTeams.length} баг → {(genTeams.length * (genTeams.length - 1)) / 2} тоглолт үүснэ.</span>}
        </div>
      </div>

      <div className="flex flex-col gap-2">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <span className="font-semibold text-navy">Тоглолтууд · {sp.matches.filter((m) => m.home && m.away).length} тоглолт · {zones} зон</span>
          {sp.matches.length > 0 && (
            <button type="button" className="a-ghost" onClick={() => { if (confirm("Энэ спортын бүх тоглолтыг арилгах уу?")) setSp({ ...sp, matches: [] }); }}>Бүгдийг арилгах</button>
          )}
        </div>
        <RowsEditor<Match & Record<string, unknown>>
          rows={sp.matches as (Match & Record<string, unknown>)[]}
          onChange={(matches) => setSp({ ...sp, matches })}
          addLabel="+ Тоглолт нэмэх"
          blank={() => { const l = sp.matches[sp.matches.length - 1]; return { stage: "group", zone: l?.zone || "А", day: l?.day || "", time: "", home: "", away: "", hs: "", as: "" }; }}
          cols={[
            { key: "zone", label: "Зон", className: "max-w-16" }, { key: "day", label: "Өдөр", type: "date", className: "max-w-40" },
            { key: "time", label: "Цаг", type: "time", className: "max-w-28" }, { key: "home", label: "Гэрийн баг" }, { key: "away", label: "Зочин баг" },
            { key: "hs", label: "Оноо", className: "max-w-20" }, { key: "as", label: "Оноо", className: "max-w-20" },
          ]}
        />
      </div>
      <div className="sticky bottom-3 flex items-center gap-3 rounded-full bg-white/90 p-2 backdrop-blur">
        <button type="button" disabled={pending} onClick={() => run(sp)} className="a-primary">{pending ? "Хадгалж байна…" : "Хадгалах"}</button>
        <Msg state={state} />
      </div>
    </div>
  );
}

// ---------------- cohorts ----------------

export function CohortEditor({ year, initial }: { year: number; initial: Cohort }) {
  const [c, setC] = useState<Cohort>(initial);
  const { state, pending, run } = useSaver((v: Cohort) => saveCohort(year, v));
  const photo = mediaUrl(c.photo);
  return (
    <div className="a-card flex flex-col gap-5">
      <h2 className="font-serif text-2xl text-navy">{year} оны төгсөгчид</h2>
      <div className="flex flex-wrap items-end gap-4">
        <div className="grid h-36 w-48 place-items-center overflow-hidden rounded-2xl bg-paper text-xs text-muted">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          {photo ? <img src={photo} alt="" className="h-full w-full object-cover" /> : "Ангийн зураг"}
        </div>
        <div className="flex flex-1 flex-col gap-2">
          <Field label="Ангийн зураг (R2 зам эсвэл холбоос)" value={c.photo} onChange={(v) => setC({ ...c, photo: v })} />
          <div className="flex gap-2">
            <MediaUpload kind="cohort" label="Зураг байршуулах" onUploaded={(p) => setC((x) => ({ ...x, photo: p }))} />
            {c.photo && <button type="button" className="a-danger" onClick={() => setC({ ...c, photo: "" })}>Зураг хасах</button>}
          </div>
        </div>
      </div>
      <div className="grid gap-4 md:grid-cols-2">
        <Field label="Анги удирдсан багш" value={c.teacher} onChange={(v) => setC({ ...c, teacher: v })} />
        <Field label="Ангийн дарга" value={c.leader} onChange={(v) => setC({ ...c, leader: v })} />
      </div>
      <div className="flex flex-col gap-2">
        <span className="font-semibold text-navy">Дурсамж</span>
        <RowsEditor rows={c.memories} onChange={(memories) => setC({ ...c, memories })} blank={() => ({ t: "", by: "" })}
          cols={[{ key: "t", label: "Дурсамж" }, { key: "by", label: "Хэн", className: "max-w-48" }]} />
      </div>
      <div className="flex items-center gap-3">
        <button type="button" disabled={pending} onClick={() => run(c)} className="a-primary">{pending ? "Хадгалж байна…" : "Хадгалах"}</button>
        <Msg state={state} />
      </div>
    </div>
  );
}
