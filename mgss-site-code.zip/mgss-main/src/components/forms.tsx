"use client";

// Client forms for the public site. Each uses a server action through
// useActionState, so errors and notices come back without a page reload.
import { useActionState, useEffect, useRef, useState } from "react";
import { SubmitButton } from "./client";
import { Notice } from "./ui";
import type { FormState } from "@/app/actions/auth";
import { signIn, forgotPassword, updatePassword, join } from "@/app/actions/auth";
import { addJob, addVoice, bookNY, proposeEvent, saveProfile } from "@/app/actions/member";
import { CATS, ETYPES, JOB_TYPES, VOICE_TYPES } from "@/lib/format";

const init: FormState = {};

/** Resets the form after a successful submit. */
function useResetOnOk(state: FormState) {
  const ref = useRef<HTMLFormElement>(null);
  useEffect(() => {
    if (state.ok) ref.current?.reset();
  }, [state]);
  return ref;
}

export function LoginForm({ next, notice, error }: { next?: string; notice?: string; error?: string }) {
  const [state, action] = useActionState(signIn, init);
  const [fState, fAction] = useActionState(forgotPassword, init);
  return (
    <form action={action} className="card flex flex-col gap-4">
      <input type="hidden" name="next" value={next || "/dashboard"} />
      <label className="label">
        И-мэйл
        <input name="email" type="email" autoComplete="email" className="input" placeholder="ner@gmail.com" required />
      </label>
      <label className="label">
        Нууц үг
        <input name="pw" type="password" autoComplete="current-password" className="input" />
      </label>
      <Notice error={state.error || fState.error || error} notice={fState.notice || notice} />
      <SubmitButton>Нэвтрэх</SubmitButton>
      <button formAction={fAction} formNoValidate className="cursor-pointer self-start text-sm text-sky hover:underline">
        Нууц үгээ мартсан уу?
      </button>
      <p className="text-sm text-muted">
        Бүртгэлгүй юу? <a href="/join" className="text-sky hover:underline">Бүртгүүлэх</a>
      </p>
    </form>
  );
}

export function NewPasswordForm() {
  const [state, action] = useActionState(updatePassword, init);
  return (
    <form action={action} className="card flex flex-col gap-4">
      <label className="label">
        Шинэ нууц үг
        <input name="npw" type="password" autoComplete="new-password" className="input" minLength={6} required />
      </label>
      <label className="label">
        Шинэ нууц үгээ давтах
        <input name="npw2" type="password" autoComplete="new-password" className="input" minLength={6} required />
      </label>
      <Notice error={state.error} />
      <SubmitButton>Хадгалаад нэвтрэх</SubmitButton>
    </form>
  );
}

export function JoinForm({ needAccount, currentYear }: { needAccount: boolean; currentYear: number }) {
  const [state, action] = useActionState(join, init);
  const fe = state.fe || {};
  const cls = (k: string) => `input ${fe[k] ? "input-err" : ""}`;
  const err = (k: string) => fe[k] && <span className="field-err">{fe[k]}</span>;
  if (state.ok)
    return (
      <div className="card flex flex-col gap-4">
        <p className="notice">{state.notice}</p>
        <a href={needAccount ? "/login" : "/dashboard"} className="btn-primary self-start">
          {needAccount ? "Нэвтрэх" : "Миний самбар →"}
        </a>
      </div>
    );
  return (
    <form action={action} noValidate className="card grid gap-4 sm:grid-cols-2">
      {needAccount && (
        <>
          <label className="label sm:col-span-2">
            И-мэйл
            <input name="email" type="email" autoComplete="email" className={cls("email")} placeholder="ner@gmail.com" />
            {err("email")}
          </label>
          <label className="label">
            Нууц үг
            <input name="pw" type="password" autoComplete="new-password" className={cls("pw")} />
            {err("pw")}
          </label>
          <label className="label">
            Нууц үгээ давтах
            <input name="pw2" type="password" autoComplete="new-password" className={cls("pw2")} />
            {err("pw2")}
          </label>
        </>
      )}
      <label className="label">
        Овог, нэр
        <input name="name" className={cls("name")} placeholder="Б.Болд" />
        {err("name")}
      </label>
      <label className="label">
        Төгссөн он
        <input name="year" inputMode="numeric" className={cls("year")} placeholder="2006" min={1997} max={currentYear} />
        {err("year")}
      </label>
      <label className="label">
        Салбар
        <select name="cat" className={cls("cat")} defaultValue="">
          <option value="" disabled>Сонгох…</option>
          {CATS.map((c) => <option key={c}>{c}</option>)}
        </select>
        {err("cat")}
      </label>
      <label className="label">
        Ажил, мэргэжил
        <input name="job" className={cls("job")} placeholder="Ж.нь: Авто засварчин" />
        {err("job")}
      </label>
      <label className="label">
        Байгууллага
        <input name="org" className="input" placeholder="Компанийн нэр эсвэл хувиараа" />
      </label>
      <label className="label">
        Байршил
        <input name="loc" className="input" placeholder="Хот, сум" />
      </label>
      <label className="label">
        Утас
        <input name="phone" type="tel" className={cls("phone")} placeholder="9900 0000" />
        {err("phone")}
      </label>
      <label className="label">
        Түлхүүр үгс (таслалаар)
        <input name="tags" className="input" placeholder="машин, сэлбэг, засвар" />
      </label>
      <div className="flex flex-col gap-3 sm:col-span-2">
        <Notice error={state.error} />
        <SubmitButton>{needAccount ? "Бүртгүүлэх" : "Профайл үүсгэх"}</SubmitButton>
      </div>
    </form>
  );
}

export function ProfileForm({ me }: { me: { job: string; org: string; loc: string; phone: string | null; cat: string; tags: string[]; fb: string; ig: string; hide: boolean } }) {
  const [state, action] = useActionState(saveProfile, init);
  const [hide, setHide] = useState(me.hide);
  return (
    <form action={action} className="card grid gap-4 sm:grid-cols-2">
      <label className="label">Ажил, мэргэжил<input name="job" defaultValue={me.job} className="input" placeholder="Нягтлан бодогч" /></label>
      <label className="label">Байгууллага<input name="org" defaultValue={me.org} className="input" /></label>
      <label className="label">Байршил<input name="loc" defaultValue={me.loc} className="input" placeholder="Хархорин" /></label>
      <label className="label">Утас<input name="phone" type="tel" defaultValue={me.phone || ""} className="input" /></label>
      <label className="label">
        Салбар
        <select name="cat" defaultValue={me.cat} className="input">
          <option value="">—</option>
          {CATS.map((c) => <option key={c}>{c}</option>)}
        </select>
      </label>
      <label className="label">Түлхүүр үгс<input name="tags" defaultValue={me.tags.join(", ")} className="input" /></label>
      <label className="label">Facebook<input name="fb" defaultValue={me.fb} className="input" placeholder="https://facebook.com/tanii.ner" /></label>
      <label className="label">Instagram<input name="ig" defaultValue={me.ig} className="input" placeholder="@tanii_ner" /></label>
      <label className="flex cursor-pointer items-center justify-between gap-4 rounded-2xl border border-line bg-slate-50 p-4 sm:col-span-2">
        <span className="flex flex-col">
          <span className="font-semibold">Утасны дугаараа сүлжээнд харуулах</span>
          <span className="text-sm text-muted">Унтраавал бусад гишүүд таны дугаарыг харахгүй.</span>
        </span>
        {/* checkbox "hide" is the inverse of the visible switch */}
        <input type="checkbox" name="hide" checked={hide} onChange={(e) => setHide(e.target.checked)} className="sr-only" />
        <span aria-hidden className={`relative h-7 w-12 shrink-0 rounded-full transition ${hide ? "bg-slate-300" : "bg-brand"}`}>
          <span className={`absolute top-1 h-5 w-5 rounded-full bg-white transition-all ${hide ? "left-1" : "left-6"}`} />
        </span>
      </label>
      <div className="flex flex-wrap items-center gap-3 sm:col-span-2">
        <SubmitButton>Хадгалах</SubmitButton>
        <Notice error={state.error} notice={state.notice} />
      </div>
    </form>
  );
}

export function ProposeEventForm() {
  const [state, action] = useActionState(proposeEvent, init);
  const ref = useResetOnOk(state);
  return (
    <form ref={ref} action={action} className="card flex flex-col gap-4">
      <h3 className="h-serif text-2xl">Арга хэмжээ санал болгох</h3>
      <label className="label">Нэр<input name="title" required className="input" placeholder="Арга хэмжээний нэр (ж.нь: Хангайн нуруунд гарах аялал)" /></label>
      <div className="grid gap-4 sm:grid-cols-2">
        <label className="label">Огноо<input name="date" type="date" required className="input" /></label>
        <label className="label">
          Төрөл
          <select name="type" className="input">{ETYPES.map((t) => <option key={t}>{t}</option>)}</select>
        </label>
      </div>
      <label className="label">Байршил<input name="place" className="input" placeholder="Байршил" /></label>
      <label className="label">Тайлбар<textarea name="desc" rows={3} className="input" placeholder="Товч тайлбар" /></label>
      <Notice error={state.error} notice={state.notice} />
      <SubmitButton>Санал болгох</SubmitButton>
    </form>
  );
}

export function VoiceForm({ defaultBy }: { defaultBy: string }) {
  const [state, action] = useActionState(addVoice, init);
  const [type, setType] = useState(VOICE_TYPES[0]);
  const ref = useResetOnOk(state);
  return (
    <form ref={ref} action={action} className="card flex flex-col gap-4">
      <input type="hidden" name="type" value={type} />
      <div className="flex flex-wrap gap-2" role="radiogroup" aria-label="Төрөл">
        {VOICE_TYPES.map((t) => (
          <button key={t} type="button" role="radio" aria-checked={t === type} onClick={() => setType(t)} className={t === type ? "chip-on" : "chip-off"}>
            {t}
          </button>
        ))}
      </div>
      <textarea name="text" rows={5} required className="input" placeholder="Холбоо, сургууль болон хурал зөвлөгөөнд хандсан саналаа бичнэ үү" />
      <input name="by" className="input" defaultValue={defaultBy} placeholder="Нэр, төгссөн он (заавал бус)" />
      <Notice error={state.error} notice={state.notice} />
      <SubmitButton>Илгээх</SubmitButton>
    </form>
  );
}

export function JobForm() {
  const [state, action] = useActionState(addJob, init);
  const ref = useResetOnOk(state);
  return (
    <form ref={ref} action={action} className="card flex flex-col gap-4">
      <h3 className="h-serif text-2xl">Зар нийтлэх</h3>
      <div className="grid gap-4 sm:grid-cols-2">
        <label className="label">Төрөл<select name="type" className="input">{JOB_TYPES.map((t) => <option key={t}>{t}</option>)}</select></label>
        <label className="label">Эцсийн хугацаа<input name="deadline" type="date" className="input" /></label>
      </div>
      <label className="label">Гарчиг<input name="title" required className="input" placeholder="Нягтлан бодогч" /></label>
      <div className="grid gap-4 sm:grid-cols-2">
        <label className="label">Байгууллага<input name="org" className="input" /></label>
        <label className="label">Байршил<input name="loc" className="input" placeholder="Хархорин" /></label>
      </div>
      <label className="label">Холбоо барих<input name="contact" className="input" placeholder="Утас эсвэл и-мэйл" /></label>
      <label className="label">Тайлбар<textarea name="desc" rows={3} className="input" placeholder="Шаардлага, цалин, ажлын цаг…" /></label>
      <Notice error={state.error} notice={state.notice} />
      <SubmitButton>Нийтлэх</SubmitButton>
    </form>
  );
}

export function NyBookingForm({ defaults }: { defaults: { name: string; phone: string; year: string } }) {
  const [state, action] = useActionState(bookNY, init);
  if (state.ok) return <p className="notice">{state.notice || "Захиалга хүлээн авлаа."}</p>;
  return (
    <form action={action} className="grid gap-4 sm:grid-cols-2">
      {/* honeypot: hidden from people, bots fill it */}
      <input name="website" tabIndex={-1} autoComplete="off" className="hidden" aria-hidden />
      <label className="label">Нэр<input name="name" required defaultValue={defaults.name} className="input" /></label>
      <label className="label">Утас<input name="phone" type="tel" required defaultValue={defaults.phone} className="input" placeholder="9900 0000" /></label>
      <label className="label">Төгссөн он<input name="year" inputMode="numeric" defaultValue={defaults.year} className="input" placeholder="2006" /></label>
      <label className="label">Суудлын тоо<input name="seats" type="number" min={1} max={20} defaultValue={1} className="input" /></label>
      <label className="label sm:col-span-2">Тэмдэглэл<input name="note" className="input" /></label>
      <div className="flex flex-col gap-3 sm:col-span-2">
        <Notice error={state.error} />
        <SubmitButton>Суудал захиалах</SubmitButton>
      </div>
    </form>
  );
}
