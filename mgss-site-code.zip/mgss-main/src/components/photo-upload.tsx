"use client";

import { useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { uploadPhoto } from "@/lib/resize-image";
import { initial, tone } from "@/lib/format";

/** Profile photo: resize in the browser → /api/upload → R2. */
export function AvatarUpload({ name, src }: { name: string; src: string }) {
  const router = useRouter();
  const input = useRef<HTMLInputElement>(null);
  const [preview, setPreview] = useState(src);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  async function onFile(file?: File) {
    if (!file) return;
    setErr("");
    setBusy(true);
    const local = URL.createObjectURL(file);
    setPreview(local);
    try {
      await uploadPhoto(file, "avatar");
      router.refresh();
    } catch (e) {
      setPreview(src);
      setErr("Зураг хадгалагдсангүй: " + (e as Error).message);
    } finally {
      URL.revokeObjectURL(local);
      setBusy(false);
    }
  }

  async function remove() {
    setBusy(true);
    setErr("");
    const res = await fetch("/api/upload", { method: "DELETE" });
    if (res.ok) { setPreview(""); router.refresh(); }
    else setErr("Зургийг устгаж чадсангүй.");
    setBusy(false);
  }

  return (
    <div className="flex items-center gap-4">
      <button
        type="button"
        onClick={() => input.current?.click()}
        disabled={busy}
        className="relative grid h-24 w-24 shrink-0 cursor-pointer place-items-center overflow-hidden rounded-full font-serif text-3xl text-white"
        style={{ background: tone(name) }}
        aria-label="Профайл зураг солих"
      >
        {initial(name)}
        {/* eslint-disable-next-line @next/next/no-img-element */}
        {preview && <img src={preview} alt="" className="absolute inset-0 h-full w-full object-cover" />}
        <span className="absolute inset-x-0 bottom-0 bg-[rgba(6,20,50,.72)] pt-1 pb-1.5 text-center font-sans text-[11px] font-semibold">
          {busy ? "…" : "Солих"}
        </span>
      </button>
      <input ref={input} type="file" accept="image/*" className="hidden" onChange={(e) => { onFile(e.target.files?.[0]); e.target.value = ""; }} />
      <div className="flex flex-col gap-1 text-sm">
        <span className="text-slate-600">Зургийг 320×320 болгон жижигрүүлж хадгална.</span>
        {preview && !busy && (
          <button type="button" onClick={remove} className="cursor-pointer self-start font-semibold text-rose">Зургаа устгах</button>
        )}
        {err && <span className="text-rose">{err}</span>}
      </div>
    </div>
  );
}

/** Admin: upload a gallery/cohort photo and hand back the stored path. */
export function MediaUpload({ kind, onUploaded, label = "Зураг байршуулах" }: { kind: "gallery" | "cohort"; onUploaded: (path: string) => void; label?: string }) {
  const input = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  return (
    <span className="inline-flex flex-col gap-1">
      <button type="button" className="a-ghost" disabled={busy} onClick={() => input.current?.click()}>
        {busy ? "Байршуулж байна…" : label}
      </button>
      <input
        ref={input}
        type="file"
        accept="image/*"
        multiple={kind === "gallery"}
        className="hidden"
        onChange={async (e) => {
          const files = [...(e.target.files || [])];
          e.target.value = "";
          if (!files.length) return;
          setBusy(true);
          setErr("");
          for (const f of files) {
            try { onUploaded(await uploadPhoto(f, kind)); }
            catch (x) { setErr((x as Error).message); }
          }
          setBusy(false);
        }}
      />
      {err && <span className="text-xs text-accent">{err}</span>}
    </span>
  );
}
