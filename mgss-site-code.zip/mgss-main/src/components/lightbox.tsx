"use client";

import { useEffect, useState } from "react";

type Photo = { src: string; cap: string };

/** Masonry grid of photos; click opens a full-screen viewer with keyboard navigation. */
export function Lightbox({ photos }: { photos: Photo[] }) {
  const [i, setI] = useState<number | null>(null);
  const n = photos.length;
  const step = (d: number) => setI((x) => (x === null ? null : (x + d + n) % n));

  useEffect(() => {
    if (i === null) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setI(null);
      if (e.key === "ArrowRight") step(1);
      if (e.key === "ArrowLeft") step(-1);
    };
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => { window.removeEventListener("keydown", onKey); document.body.style.overflow = ""; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [i]);

  const cur = i === null ? null : photos[i];
  return (
    <>
      <ul className="columns-2 gap-3 md:columns-3 lg:columns-4">
        {photos.map((p, j) => (
          <li key={j} className="mb-3 break-inside-avoid">
            <button type="button" onClick={() => setI(j)} className="group block w-full cursor-pointer overflow-hidden rounded-2xl border border-line bg-white text-left shadow-[0_6px_20px_rgba(15,23,42,.06)]">
              <span className="block overflow-hidden">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={p.src} alt={p.cap} loading="lazy" className="w-full transition duration-300 group-hover:scale-[1.04]" />
              </span>
              {p.cap && <span className="block px-3 py-2 text-xs font-semibold text-muted">{p.cap}</span>}
            </button>
          </li>
        ))}
      </ul>

      {cur && (
        <div role="dialog" aria-modal="true" aria-label={cur.cap || "Зураг"} className="fixed inset-0 z-50 flex items-center justify-center bg-navy/90 p-3 backdrop-blur-sm" onClick={() => setI(null)}>
          <button type="button" aria-label="Хаах" onClick={() => setI(null)} className="absolute top-4 right-4 grid h-11 w-11 cursor-pointer place-items-center rounded-full bg-white/15 text-xl text-white hover:bg-white/30">✕</button>
          {n > 1 && (
            <>
              <button type="button" aria-label="Өмнөх" onClick={(e) => { e.stopPropagation(); step(-1); }} className="absolute left-3 grid h-12 w-12 cursor-pointer place-items-center rounded-full bg-white/15 text-2xl text-white hover:bg-white/30 sm:left-6">‹</button>
              <button type="button" aria-label="Дараах" onClick={(e) => { e.stopPropagation(); step(1); }} className="absolute right-3 grid h-12 w-12 cursor-pointer place-items-center rounded-full bg-white/15 text-2xl text-white hover:bg-white/30 sm:right-6">›</button>
            </>
          )}
          <figure className="flex max-h-full max-w-5xl flex-col items-center gap-3" onClick={(e) => e.stopPropagation()}>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={cur.src} alt={cur.cap} className="max-h-[80vh] max-w-full rounded-2xl object-contain shadow-2xl" />
            <figcaption className="text-center text-sm text-white/85">{cur.cap}{n > 1 && <span className="text-white/50"> · {i! + 1}/{n}</span>}</figcaption>
          </figure>
        </div>
      )}
    </>
  );
}
