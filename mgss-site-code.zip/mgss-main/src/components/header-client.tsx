"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState, useSyncExternalStore } from "react";
import { fmtAgo } from "@/lib/format";
import type { FeedItem } from "@/lib/feed";

type NavItem = { href: string; label: string; children?: { href: string; label: string; sub?: string }[] };

export const NAV: NavItem[] = [
  {
    href: "/school",
    label: "Сургууль",
    children: [
      { href: "/school", label: "Танилцуулга", sub: "Түүх, лого, сүлд дуу" },
      { href: "/school#founder", label: "Үүсгэн байгуулагч", sub: "М.Сугар багшийн намтар" },
      { href: "/school#staff", label: "Багш нар", sub: "2026–2027 оны хичээлийн жил" },
      { href: "/school/staff", label: "Хамт олон", sub: "Багш, ажилтнуудын намтар" },
      { href: "/school/history", label: "Түүхэн замнал", sub: "Үе үеийн багш, ажиллагсад" },
      { href: "/gallery", label: "Зургийн цомог", sub: "Дурсамжийн зургууд" },
    ],
  },
  { href: "/gallery", label: "Зургийн цомог" },
  { href: "/cohorts", label: "Төгсөгчид" },
  { href: "/network", label: "Сүлжээ" },
  { href: "/jobs", label: "Ажлын зар" },
  { href: "/events", label: "Арга хэмжээ" },
  { href: "/voice", label: "Санал хүсэлт" },
];

const linkCls = (on: boolean, mobile: boolean) =>
  `rounded-full px-2.5 py-2 text-[14.5px] font-bold whitespace-nowrap transition hover:bg-paper hover:text-brand ${on ? "bg-brand/[.08] text-brand" : "text-ink"} ${mobile ? "w-full py-3 text-[15px]" : ""}`;

export function NavLinks({ mobile = false, onNavigate }: { mobile?: boolean; onNavigate?: () => void }) {
  const path = usePathname();
  return (
    <>
      {NAV.map((item) => {
        const on = path === item.href || path.startsWith(item.href + "/");
        if (!item.children)
          return (
            <Link key={item.href} href={item.href} onClick={onNavigate} className={linkCls(on, mobile)}>
              {item.label}
            </Link>
          );
        if (mobile)
          return (
            <div key={item.href} className="flex flex-col">
              <Link href={item.href} onClick={onNavigate} className={linkCls(on, true)}>{item.label}</Link>
              <div className="ml-4 flex flex-col border-l-2 border-line pl-2">
                {item.children.map((c) => (
                  <Link key={c.href} href={c.href} onClick={onNavigate} className="rounded-full px-3 py-2 text-sm font-semibold text-muted hover:text-brand">{c.label}</Link>
                ))}
              </div>
            </div>
          );
        return (
          <div key={item.href} className="group relative">
            <Link href={item.href} className={`${linkCls(on, false)} inline-flex items-center gap-1`} aria-haspopup="menu">
              {item.label}
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" aria-hidden><path d="m6 9 6 6 6-6" /></svg>
            </Link>
            <div className="invisible absolute top-full left-0 z-50 pt-2 opacity-0 transition group-hover:visible group-hover:opacity-100 group-focus-within:visible group-focus-within:opacity-100">
              <div className="flex w-72 flex-col gap-0.5 rounded-3xl border border-line bg-white p-2 shadow-[0_18px_50px_rgba(15,23,42,.14)]">
                <Link href={item.href} className="mb-1 flex items-center gap-3 rounded-2xl bg-paper px-3 py-2.5 hover:bg-sky/10">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src="/img/logo-ebgs.png" alt="" width={44} height={44} />
                  <span className="flex flex-col leading-tight">
                    <span className="text-[13px] font-extrabold uppercase text-brand">Хархорин ЕБГС</span>
                    <span className="text-xs text-muted">МГСС Гүнзгий сургууль · 1997</span>
                  </span>
                </Link>
                {item.children.map((c) => (
                  <Link key={c.href} href={c.href} className="flex flex-col rounded-2xl px-3.5 py-2.5 hover:bg-paper">
                    <span className="text-[15px] font-bold text-ink">{c.label}</span>
                    {c.sub && <span className="text-xs text-muted">{c.sub}</span>}
                  </Link>
                ))}
              </div>
            </div>
          </div>
        );
      })}
    </>
  );
}

export function MobileMenu({ children }: { children: React.ReactNode }) {
  // Remembers which page the menu was opened on, so navigating closes it.
  const path = usePathname();
  const [openOn, setOpenOn] = useState<string | null>(null);
  const open = openOn === path;
  const setOpen = (v: boolean | ((o: boolean) => boolean)) =>
    setOpenOn((typeof v === "function" ? v(open) : v) ? path : null);
  return (
    <>
      <button
        type="button"
        aria-label="Цэс"
        aria-expanded={open}
        onClick={() => setOpen((o) => !o)}
        className="grid h-11 w-11 cursor-pointer place-items-center rounded-full border border-line text-lg text-brand hover:bg-paper xl:hidden"
      >
        {open ? "✕" : "☰"}
      </button>
      {open && (
        <div className="absolute inset-x-3 top-full mt-2 flex max-h-[calc(100vh-140px)] flex-col gap-1 overflow-y-auto rounded-3xl border border-line bg-white p-3 shadow-2xl xl:hidden">
          <NavLinks mobile onNavigate={() => setOpen(false)} />
          {children}
        </div>
      )}
    </>
  );
}

const SEEN_KEY = "mgss-seen";
const SEEN_EVENT = "mgss-seen-change";

// "Last opened" timestamp lives in localStorage (per browser, like mgss1).
function subscribeSeen(cb: () => void) {
  window.addEventListener("storage", cb);
  window.addEventListener(SEEN_EVENT, cb);
  return () => { window.removeEventListener("storage", cb); window.removeEventListener(SEEN_EVENT, cb); };
}
function readSeen() {
  try { return Number(localStorage.getItem(SEEN_KEY)) || 0; } catch { return 0; }
}
function writeSeen(ts: number) {
  try { localStorage.setItem(SEEN_KEY, String(ts)); } catch {}
  window.dispatchEvent(new Event(SEEN_EVENT));
}

export function Bell({ feed }: { feed: FeedItem[] }) {
  const seen = useSyncExternalStore(subscribeSeen, readSeen, () => null);
  // While open, keep highlighting items that were new when it was opened.
  const [openedFrom, setOpenedFrom] = useState<number | null>(null);
  const open = openedFrom !== null;
  const unread = seen === null ? 0 : feed.filter((f) => f.ts > seen).length;
  const highlight = (ts: number) => openedFrom !== null && ts > openedFrom;

  const toggle = () => {
    if (!open) { setOpenedFrom(seen ?? 0); writeSeen(Date.now()); }
    else setOpenedFrom(null);
  };

  return (
    <div className="relative">
      <button
        type="button"
        onClick={toggle}
        aria-label="Мэдэгдэл"
        className="relative grid h-11 w-11 cursor-pointer place-items-center rounded-full border border-line text-brand hover:bg-paper"
      >
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
          <path d="M6 8a6 6 0 1 1 12 0c0 7 3 9 3 9H3s3-2 3-9" />
          <path d="M10.3 21a1.94 1.94 0 0 0 3.4 0" />
        </svg>
        {unread > 0 && (
          <span className="absolute -top-1 -right-1 grid h-[18px] min-w-[18px] place-items-center rounded-full bg-accent px-1 text-[11px] font-bold text-white">
            {unread > 9 ? "9+" : unread}
          </span>
        )}
      </button>
      {open && (
        <div className="fixed inset-x-3 top-24 z-50 flex max-h-[min(70vh,520px)] flex-col gap-1 overflow-y-auto rounded-3xl border border-line bg-white p-2 shadow-2xl sm:absolute sm:inset-x-auto sm:top-14 sm:right-0 sm:w-[360px]">
          <span className="px-3 pt-2 pb-1 text-lg font-extrabold text-brand">Мэдэгдэл</span>
          {feed.length === 0 && <span className="p-3 text-sm text-muted">Одоогоор шинэ мэдээ алга.</span>}
          {feed.map((f, i) => (
            <Link
              key={i}
              href={f.href}
              onClick={() => setOpenedFrom(null)}
              className={`flex gap-3 rounded-2xl p-3 hover:bg-paper ${highlight(f.ts) ? "bg-sky/[.08]" : ""}`}
            >
              <span className="mt-1.5 h-2 w-2 shrink-0 rounded-full" style={{ background: f.color }} />
              <span className="flex min-w-0 flex-col gap-0.5">
                <span className="text-xs font-bold" style={{ color: f.color }}>
                  {f.kind} · {fmtAgo(f.ts)}
                </span>
                <span className="text-[15px] font-semibold">{f.title}</span>
                {f.sub && <span className="line-clamp-2 text-[13px] text-muted">{f.sub}</span>}
              </span>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
