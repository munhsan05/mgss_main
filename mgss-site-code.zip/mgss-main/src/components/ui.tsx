import Image from "next/image";
import { initial, tone } from "@/lib/format";
import { mediaUrl } from "@/lib/media";

/** Blue page banner with a faint school photo; text is white, so children must style themselves for a dark background. */
export function PageBanner({ eyebrow, title, lead, children, aside }: { eyebrow: string; title: string; lead?: string; children?: React.ReactNode; aside?: React.ReactNode }) {
  return (
    <section className="relative overflow-hidden bg-brand text-white">
      <Image src="/img/school.jpg" alt="" fill priority className="object-cover opacity-20" sizes="100vw" />
      <div className="absolute inset-0 bg-gradient-to-r from-brand via-brand/90 to-sky/70" />
      <div aria-hidden className="absolute -top-24 -right-24 h-72 w-72 rounded-full border-[28px] border-white/10" />
      <div aria-hidden className="absolute -bottom-20 left-1/3 h-48 w-48 rotate-12 rounded-3xl border-[18px] border-white/10" />
      <div className="relative mx-auto flex max-w-6xl items-center justify-between gap-8 px-5 pt-12 pb-12 sm:px-8 sm:pt-16 sm:pb-16">
        <div className="flex min-w-0 flex-col gap-4">
          <span className="eyebrow">{eyebrow}</span>
          {title && <h1 className="h-serif max-w-3xl text-3xl break-words sm:text-5xl">{title}</h1>}
          {lead && <p className="max-w-2xl text-lg text-white/85">{lead}</p>}
          {children}
        </div>
        {aside && <div className="hidden shrink-0 md:block">{aside}</div>}
      </div>
    </section>
  );
}

/** Section heading in the reference style: red pill + bold uppercase title. */
export function SectionTitle({ eyebrow, title, lead, right, className = "" }: { eyebrow: string; title: string; lead?: string; right?: React.ReactNode; className?: string }) {
  return (
    <div className={`flex flex-wrap items-end justify-between gap-4 ${className}`}>
      <div className="flex flex-col gap-3">
        <span className="eyebrow">{eyebrow}</span>
        <h2 className="h-serif text-3xl sm:text-4xl">{title}</h2>
        {lead && <p className="max-w-2xl text-muted">{lead}</p>}
      </div>
      {right}
    </div>
  );
}

export function Container({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return <div className={`mx-auto w-full max-w-6xl px-5 sm:px-8 ${className}`}>{children}</div>;
}

export function Avatar({ name, photo, size = 52, className = "" }: { name: string; photo?: string | null; size?: number; className?: string }) {
  const src = mediaUrl(photo);
  return (
    <span
      className={`relative inline-grid shrink-0 place-items-center overflow-hidden rounded-full font-serif font-semibold text-white ${className}`}
      style={{ width: size, height: size, background: tone(name), fontSize: Math.round(size * 0.34) }}
    >
      {initial(name)}
      {src && (
        // Already resized to 320 px on upload, so no Next image optimisation needed.
        // eslint-disable-next-line @next/next/no-img-element
        <img src={src} alt="" loading="lazy" className="absolute inset-0 h-full w-full object-cover" />
      )}
    </span>
  );
}

export function Empty({ children }: { children: React.ReactNode }) {
  return <p className="rounded-3xl border border-dashed border-line bg-white/60 px-5 py-8 text-center text-muted">{children}</p>;
}

export function Notice({ error, notice }: { error?: string; notice?: string }) {
  return (
    <>
      {error && <p className="error" role="alert">{error}</p>}
      {notice && <p className="notice" role="status">{notice}</p>}
    </>
  );
}
