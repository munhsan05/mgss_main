import Link from "next/link";
import type { HistoryGroup, Person } from "@/lib/school-data";
import { initial, tone } from "@/lib/format";

export const SCHOOL_TABS = [
  ["/school", "Танилцуулга"],
  ["/school/staff", "Хамт олон"],
  ["/school/history", "Түүхэн замнал"],
] as const;

/** Sub-navigation shared by the three school pages. */
export function SchoolNav({ active }: { active: string }) {
  return (
    <nav aria-label="Сургуулийн хэсгүүд" className="flex flex-wrap gap-2 pt-2">
      {SCHOOL_TABS.map(([href, label]) => (
        <Link key={href} href={href} className={`chip ${href === active ? "border-white bg-white text-brand" : "border-white/40 text-white hover:bg-white/15"}`} aria-current={href === active ? "page" : undefined}>
          {label}
        </Link>
      ))}
    </nav>
  );
}

/** 3:4 portrait. Photos in /public/img/staff are already resized to 480×640, so a plain <img> is enough. */
export function Portrait({ src, name, className = "" }: { src?: string; name: string; className?: string }) {
  return (
    <span className={`relative block aspect-[3/4] overflow-hidden rounded-2xl bg-slate-50 ${className}`} style={{ background: src ? undefined : tone(name) }}>
      {src ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={src} alt={name} loading="lazy" className="absolute inset-0 h-full w-full object-cover object-top" />
      ) : (
        <span className="absolute inset-0 grid place-items-center font-serif text-4xl text-white">{initial(name)}</span>
      )}
    </span>
  );
}

export function PersonCard({ p }: { p: Person }) {
  return (
    <li className="flex flex-col gap-2">
      <Portrait src={p.photo} name={p.name} />
      <span className="flex flex-col leading-tight">
        <span className="font-semibold">{p.name}</span>
        <span className="text-sm text-muted">{p.years}</span>
      </span>
    </li>
  );
}

export function StaffCard({ name, role, photo, degree, years }: { name: string; role: string; photo?: string; degree?: string; years?: number }) {
  return (
    <li className="card flex flex-col gap-3 p-3 sm:p-3">
      <Portrait src={photo} name={name} />
      <span className="flex flex-col gap-0.5 px-1 pb-1 leading-tight">
        <span className="font-semibold">{name}</span>
        {role && <span className="text-sm text-slate-600">{role}</span>}
        {(degree || years) && (
          <span className="pt-1 text-xs text-mist">
            {[degree ? `${degree} зэрэгтэй` : "", years ? `${years} жил ажилласан` : ""].filter(Boolean).join(" · ")}
          </span>
        )}
      </span>
    </li>
  );
}

export function HistoryTable({ group }: { group: HistoryGroup }) {
  return (
    <section className="card flex flex-col gap-3">
      <h3 className="font-serif text-xl">{group.title}</h3>
      <ol className="flex flex-col divide-y divide-line text-sm">
        {group.rows.map((r, i) => (
          <li key={i} className="flex items-baseline justify-between gap-3 py-1.5">
            <span className="flex gap-2"><span className="w-5 shrink-0 text-mist">{i + 1}.</span><span>{r.n}</span></span>
            <span className="shrink-0 text-right text-muted">{r.years}</span>
          </li>
        ))}
      </ol>
    </section>
  );
}
