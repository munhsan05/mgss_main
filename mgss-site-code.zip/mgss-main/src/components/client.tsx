"use client";

import { useState, useSyncExternalStore, useTransition } from "react";
import { useFormStatus } from "react-dom";

/** Runs an action; shows failures like mgss1 did instead of crashing the page. */
async function run(action: () => Promise<void>) {
  try {
    await action();
  } catch (e) {
    alert((e as Error).message || "Алдаа гарлаа. Дахин оролдоно уу.");
  }
}

export function SubmitButton({ children, className = "btn-primary", pending: pendingLabel = "Түр хүлээнэ үү…" }: { children: React.ReactNode; className?: string; pending?: string }) {
  const { pending } = useFormStatus();
  return (
    <button type="submit" disabled={pending} className={className}>
      {pending ? pendingLabel : children}
    </button>
  );
}

/** Runs a bound server action after a confirm() dialog. */
export function ConfirmButton({ action, message, children, className = "btn-danger" }: { action: () => Promise<void>; message: string; children: React.ReactNode; className?: string }) {
  const [pending, start] = useTransition();
  return (
    <button
      type="button"
      disabled={pending}
      className={className}
      onClick={(e) => {
        e.preventDefault(); // don't toggle a surrounding <details>
        if (confirm(message)) start(() => run(action));
      }}
    >
      {pending ? "…" : children}
    </button>
  );
}

/** Button that runs a bound server action (RSVP, vote) with pending state. */
export function ActionButton({ action, children, className }: { action: () => Promise<void>; children: React.ReactNode; className: string }) {
  const [pending, start] = useTransition();
  return (
    <button type="button" disabled={pending} className={className} onClick={(e) => { e.preventDefault(); start(() => run(action)); }}>
      {children}
    </button>
  );
}

export function CopyButton({ value, className = "" }: { value: string; className?: string }) {
  const [copied, setCopied] = useState(false);
  if (!value) return <span>—</span>;
  return (
    <button
      type="button"
      className={`cursor-pointer font-semibold text-sky underline-offset-4 hover:underline ${className}`}
      onClick={async () => {
        try { await navigator.clipboard.writeText(value); } catch {}
        setCopied(true);
        setTimeout(() => setCopied(false), 1800);
      }}
    >
      {copied ? "✓ Хуулагдлаа" : `${value} ⧉`}
    </button>
  );
}

function subscribeSecond(cb: () => void) {
  const id = setInterval(cb, 1000);
  return () => clearInterval(id);
}

export function Countdown({ target }: { target: string }) {
  const t = new Date(target).getTime();
  const now = useSyncExternalStore(subscribeSecond, () => Math.floor(Date.now() / 1000), () => null);
  if (isNaN(t)) return null;
  const left = Math.max(0, Math.floor(t / 1000) - (now ?? Math.floor(t / 1000)));
  const parts = [
    ["Өдөр", Math.floor(left / 86400)],
    ["Цаг", Math.floor((left % 86400) / 3600)],
    ["Минут", Math.floor((left % 3600) / 60)],
    ["Секунд", left % 60],
  ] as const;
  return (
    <div className="flex gap-2 sm:gap-3" aria-label="Үдэшлэг эхлэх хүртэл">
      {parts.map(([label, v]) => (
        <div key={label} className="flex min-w-16 flex-col items-center rounded-2xl border border-white/25 bg-white/10 px-3 py-2 text-white backdrop-blur">
          <span className="font-serif text-2xl tabular-nums sm:text-3xl" suppressHydrationWarning>
            {now === null ? "--" : String(v).padStart(2, "0")}
          </span>
          <span className="text-[11px] text-white/70">{label}</span>
        </div>
      ))}
    </div>
  );
}

/** Network card "Холбогдох" button: reveals the phone the server allowed us to see. */
export function PhoneReveal({ phone, hidden, loggedIn }: { phone: string | null; hidden: boolean; loggedIn: boolean }) {
  const [open, setOpen] = useState(false);
  if (!open)
    return (
      <button type="button" className="btn-light w-full" onClick={() => setOpen(true)}>
        Холбогдох
      </button>
    );
  if (!loggedIn && !hidden)
    return (
      <a href="/login?notice=1&next=/network" className="btn-ghost w-full">
        Нэвтэрч дугаар харах
      </a>
    );
  return (
    <span className="btn w-full border border-sky/60 bg-sky/10 text-brand">
      {hidden || !phone ? "Дугаараа нууцалсан" : <a href={`tel:${phone}`}>☏ {phone}</a>}
    </span>
  );
}

export function Snow() {
  return (
    <div aria-hidden className="snow pointer-events-none absolute inset-0 overflow-hidden">
      {Array.from({ length: 34 }, (_, i) => {
        const size = 2 + ((i * 7) % 4);
        return (
          <span
            key={i}
            className="absolute rounded-full"
            style={{
              left: `${(i * 37) % 100}%`, top: 0, width: size, height: size,
              background: `rgba(255,255,255,${0.25 + (i % 5) / 10})`,
              animation: `mgss-snow ${9 + ((i * 13) % 12)}s linear ${-((i * 17) % 20)}s infinite`,
            }}
          />
        );
      })}
    </div>
  );
}
