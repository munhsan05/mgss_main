import Link from "next/link";
import Image from "next/image";
import { getContent, getViewer } from "@/lib/data";
import { getFeed } from "@/lib/feed";
import { signOut } from "@/app/actions/auth";
import { Bell, MobileMenu, NavLinks } from "./header-client";
import { Avatar } from "./ui";

function Brand({ onDark = false }: { onDark?: boolean }) {
  return (
    <Link href="/" className="flex min-w-0 items-center gap-3">
      <Image src="/img/logo-alumni.png" alt="Төгсөгчдийн холбооны лого" width={56} height={56} className="rounded-full bg-white shadow-[0_0_0_2px_rgba(255,255,255,.95),0_6px_16px_rgba(0,0,0,.15)]" />
      <span className="hidden flex-col leading-tight min-[400px]:flex">
        <span className={`text-[13px] font-extrabold tracking-[.08em] whitespace-nowrap uppercase ${onDark ? "text-white/85" : "text-accent"}`}>Хархорин МГСС</span>
        <span className={`text-[15px] font-extrabold tracking-[.02em] whitespace-nowrap uppercase sm:text-[17px] ${onDark ? "text-white" : "text-brand"}`}>Төгсөгчдийн холбоо</span>
      </span>
    </Link>
  );
}

function SocialIcon({ kind }: { kind: "fb" | "ig" | "yt" }) {
  const paths = {
    fb: "M13.5 21v-7h2.4l.4-3h-2.8V9.2c0-.9.3-1.5 1.5-1.5h1.4V5.1c-.3 0-1.2-.1-2.2-.1-2.2 0-3.7 1.3-3.7 3.8V11H8v3h2.5v7h3Z",
    ig: "M7.8 2h8.4C19.4 2 22 4.6 22 7.8v8.4a5.8 5.8 0 0 1-5.8 5.8H7.8C4.6 22 2 19.4 2 16.2V7.8A5.8 5.8 0 0 1 7.8 2m-.2 2A3.6 3.6 0 0 0 4 7.6v8.8C4 18.39 5.61 20 7.6 20h8.8a3.6 3.6 0 0 0 3.6-3.6V7.6C20 5.61 18.39 4 16.4 4H7.6m9.65 1.5a1.25 1.25 0 0 1 1.25 1.25A1.25 1.25 0 0 1 17.25 8 1.25 1.25 0 0 1 16 6.75a1.25 1.25 0 0 1 1.25-1.25M12 7a5 5 0 0 1 5 5 5 5 0 0 1-5 5 5 5 0 0 1-5-5 5 5 0 0 1 5-5m0 2a3 3 0 0 0-3 3 3 3 0 0 0 3 3 3 3 0 0 0 3-3 3 3 0 0 0-3-3z",
    yt: "M21.6 7.2a2.5 2.5 0 0 0-1.8-1.8C18.2 5 12 5 12 5s-6.2 0-7.8.4A2.5 2.5 0 0 0 2.4 7.2 26 26 0 0 0 2 12a26 26 0 0 0 .4 4.8 2.5 2.5 0 0 0 1.8 1.8C5.8 19 12 19 12 19s6.2 0 7.8-.4a2.5 2.5 0 0 0 1.8-1.8A26 26 0 0 0 22 12a26 26 0 0 0-.4-4.8ZM10 15V9l5.2 3L10 15Z",
  };
  return (
    <span className="grid h-7 w-7 place-items-center rounded-full bg-white/15">
      <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor" aria-hidden><path d={paths[kind]} /></svg>
    </span>
  );
}

export async function Header() {
  const [viewer, feed] = await Promise.all([getViewer(), getFeed()]);
  const { user, me, isAdmin } = viewer;
  const account = user ? (
    <div className="flex items-center gap-2">
      <Link href="/dashboard" className="flex items-center gap-2 rounded-full border border-line py-1 pr-3.5 pl-1 text-sm font-bold text-brand hover:bg-paper">
        {me ? <Avatar name={me.name} photo={me.photo} size={32} /> : <span className="grid h-8 w-8 place-items-center rounded-full bg-brand text-white">{user.email[0]?.toUpperCase()}</span>}
        <span className="hidden sm:inline">Самбар</span>
      </Link>
      {isAdmin && (
        <Link href="/admin" className="hidden rounded-full border border-line px-3.5 py-2 text-sm font-bold text-brand hover:bg-paper sm:inline-flex">
          Админ
        </Link>
      )}
      <form action={signOut}>
        <button className="hidden cursor-pointer rounded-full px-3 py-2 text-sm text-muted hover:text-accent sm:inline">Гарах</button>
      </form>
    </div>
  ) : (
    <Link href="/login" className="rounded-full bg-brand px-4 py-2.5 text-sm font-extrabold text-white shadow-[0_8px_18px_rgba(0,75,144,.3)] hover:bg-brand-dark">
      Нэвтрэх
    </Link>
  );

  return (
    <header className="sticky top-0 z-40 bg-white shadow-[0_6px_24px_rgba(15,23,42,.08)]">
      {/* main nav */}
      <div className="mx-auto flex max-w-[1320px] items-center justify-between gap-4 px-4 py-2.5 sm:px-6">
        <Brand />
        <nav className="hidden items-center gap-0.5 xl:flex xl:shrink-0">
          <NavLinks />
        </nav>
        <div className="flex items-center gap-2">
          <Bell feed={feed} />
          {account}
          <MobileMenu>
            {isAdmin && <Link href="/admin" className="w-full rounded-full px-3.5 py-3 text-[15px] font-bold text-brand hover:bg-paper">Админ</Link>}
            {user && <form action={signOut}><button className="w-full cursor-pointer rounded-full px-3.5 py-3 text-left text-[15px] font-semibold text-muted hover:bg-paper">Гарах</button></form>}
          </MobileMenu>
        </div>
      </div>
    </header>
  );
}

const FOOTER_COLS: { title: string; links: [string, string][] }[] = [
  { title: "Бидний тухай", links: [["/school", "Сургуулийн танилцуулга"], ["/school#history", "Үүсэл түүх"], ["/school/staff", "Багш нар, хамт олон"], ["/school/history", "Түүхэн замнал"], ["/gallery", "Зургийн цомог"]] },
  { title: "Төгсөгчдийн холбоо", links: [["/cohorts", "Үе үеийн төгсөгчид"], ["/network", "Төгсөгчдийн сүлжээ"], ["/jobs", "Ажлын зар"], ["/events", "Арга хэмжээ"], ["/voice", "Санал хүсэлт"]] },
  { title: "Үйл ажиллагаа", links: [["/#news", "Мэдээ мэдээлэл"], ["/#about", "Бидний тухай"], ["/#ny", "Шинэ жилийн үдэшлэг"], ["/#sports", "Спорт тэмцээн"], ["/#fund", "Хөгжлийн сан"]] },
];

export async function Footer() {
  const [c, viewer] = await Promise.all([getContent(), getViewer()]);
  return (
    <footer className="px-3 pt-6 pb-5 sm:px-5">
      <div className="relative mx-auto max-w-[1240px] overflow-hidden rounded-[32px] bg-gradient-to-br from-[#0a63c4] via-brand to-[#002d5c] text-white shadow-[0_24px_60px_rgba(0,45,92,.3)]">
        <div aria-hidden className="pointer-events-none absolute inset-0 opacity-20">
          <span className="absolute -top-16 -left-10 h-56 w-56 rounded-full border-[22px] border-white" />
          <span className="absolute top-1/3 right-[12%] h-24 w-24 rotate-12 rounded-2xl border-[12px] border-white" />
          <span className="absolute -bottom-20 left-1/2 h-64 w-64 rounded-full border-[26px] border-white" />
          <span className="absolute top-10 right-[40%] h-0 w-0 border-r-[40px] border-b-[70px] border-l-[40px] border-r-transparent border-b-white border-l-transparent" />
        </div>
        <div className="relative grid gap-10 px-6 pt-12 pb-10 sm:px-10 lg:grid-cols-[1.3fr_1fr_1fr_1fr]">
          <div className="flex max-w-sm flex-col gap-5">
            <Brand onDark />
            <p className="text-sm text-white/80">Үе үеийн төгсөгчид хэн, хаана, ямар ажил эрхэлж байгааг мэдэж, бие биедээ туслах нээлттэй орчин.</p>
            <div className="flex flex-col gap-1.5 text-sm">
              <span className="font-extrabold tracking-wide uppercase">Холбоо барих</span>
              <span className="text-white/85">Өвөрхангай аймаг, Хархорин сум, МГСС Гүнзгий сургууль</span>
              {c.site.contactEmail && <a href={`mailto:${c.site.contactEmail}`} className="text-white/85 hover:underline">✉ {c.site.contactEmail}</a>}
              {c.site.contactPhone && <a href={`tel:${c.site.contactPhone}`} className="text-white/85 hover:underline">☎ {c.site.contactPhone}</a>}
            </div>
            <div className="flex items-center gap-2"><SocialIcon kind="fb" /><SocialIcon kind="ig" /><SocialIcon kind="yt" /></div>
          </div>
          {FOOTER_COLS.map((col) => (
            <div key={col.title} className="flex flex-col gap-3 text-sm">
              <span className="font-extrabold tracking-wide uppercase">{col.title}</span>
              <div className="flex flex-col gap-1.5 text-white/85">
                {col.links.map(([href, label]) => <Link key={href + label} href={href} className="hover:text-white hover:underline">{label}</Link>)}
                {col.title === "Төгсөгчдийн холбоо" && (
                  <Link href={viewer.me ? "/dashboard" : "/join"} className="hover:text-white hover:underline">{viewer.me ? "Миний самбар" : "Бүртгүүлэх"}</Link>
                )}
              </div>
            </div>
          ))}
        </div>
        <div className="relative flex flex-wrap items-center justify-between gap-2 border-t border-white/15 px-6 py-4 text-xs text-white/75 sm:px-10">
          <span>© {new Date().getFullYear()} Хархорин МГСС Төгсөгчдийн холбоо, бүх эрх хуулиар хамгаалагдсан</span>
          <span>Хархорин · {c.site.contactEmail || "info@alumni.mn"}</span>
        </div>
      </div>
    </footer>
  );
}
