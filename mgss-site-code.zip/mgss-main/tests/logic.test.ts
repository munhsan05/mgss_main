// Run: npm test   (Node's built-in test runner with type stripping)
import { test } from "node:test";
import assert from "node:assert/strict";
import { buildZones, roundRobin } from "../src/lib/sports.ts";
import { fmtAgo, dayLabel, cohortNo, decadeLabel, validateJoin, normalizePhone, authErrorMessage, initial } from "../src/lib/format.ts";

test("basketball standings: win 2, loss 1, sorted by pts then diff", () => {
  const z = buildZones("basket", [
    { zone: "А", home: "2006", away: "2010", hs: 50, as: 40 },
    { zone: "А", home: "2010", away: "2014", hs: 30, as: 31 },
    { zone: "А", home: "2006", away: "2014", hs: "", as: "" },
  ]);
  assert.equal(z.length, 1);
  const t = Object.fromEntries(z[0].table.map((r) => [r.team, r]));
  assert.equal(t["2006"].pts, 2);
  assert.equal(t["2014"].pts, 2);
  assert.equal(t["2010"].pts, 2); // two losses = 1 + 1
  assert.equal(z[0].table[0].team, "2006"); // +10 diff beats +1 and -11
  assert.equal(z[0].played, 2);
});

test("volleyball points: 2:0 → 3/0, 2:1 → 2/1", () => {
  const z = buildZones("volley", [
    { home: "A", away: "B", hs: 2, as: 0 },
    { home: "C", away: "D", hs: 1, as: 2 },
  ]);
  const t = Object.fromEntries(z[0].table.map((r) => [r.team, r.pts]));
  assert.deepEqual(t, { A: 3, B: 0, C: 1, D: 2 });
});

test("ties and knockout matches are ignored", () => {
  const z = buildZones("basket", [
    { home: "A", away: "B", hs: 3, as: 3 },
    { stage: "final", home: "A", away: "B", hs: 9, as: 1 },
  ]);
  assert.equal(z[0].table.every((r) => r.pts === 0), true);
  assert.equal(z[0].matches.length, 1);
});

test("round robin: n teams → n(n-1)/2 unique matches, odd count gets a bye", () => {
  for (const n of [2, 3, 4, 5, 6]) {
    const teams = Array.from({ length: n }, (_, i) => "T" + i);
    const ms = roundRobin(teams, { zone: "Б", day: "2026-11-14", start: "10:00", stepMin: 40 });
    assert.equal(ms.length, (n * (n - 1)) / 2);
    const keys = new Set(ms.map((m) => [m.home, m.away].sort().join("-")));
    assert.equal(keys.size, ms.length);
  }
  const ms = roundRobin(["A", "B", "C"], { zone: "Б", day: "d", start: "23:40", stepMin: 40 });
  assert.deepEqual(ms.map((m) => m.time), ["23:40", "00:20", "01:00"]);
  assert.equal(ms[0].zone, "Б");
});

test("fmtAgo / dayLabel / cohortNo / initial", () => {
  const now = new Date("2026-11-10T12:00:00Z").getTime();
  assert.equal(fmtAgo(now - 10 * 60e3, now), "Саяхан");
  assert.equal(fmtAgo(now - 3 * 3600e3, now), "3 цагийн өмнө");
  assert.equal(fmtAgo(now - 5 * 864e5, now), "5 өдрийн өмнө");
  assert.equal(fmtAgo("nonsense", now), "");
  assert.equal(dayLabel("2026-11-14"), "11-р сарын 14");
  assert.equal(dayLabel("soon"), "soon");
  assert.equal(cohortNo(2000), 1);
  assert.equal(cohortNo(2026), 27);
  assert.equal(initial("Б.Болд"), "Б");
});

test("decadeLabel follows vowel harmony", () => {
  assert.equal(decadeLabel(1960), "1960-аад");
  assert.equal(decadeLabel(1980), "1980-аад");
  assert.equal(decadeLabel(1990), "1990-ээд");
  assert.equal(decadeLabel(2000), "2000-аад");
  assert.equal(decadeLabel(2010), "2010-аад");
  assert.equal(decadeLabel(2020), "2020-иод");
});

test("join validation", () => {
  const ok = { email: "a@b.mn", pw: "secret1", pw2: "secret1", name: "Б.Болд", year: "2010", cat: "IT", job: "Dev", phone: "+976 9911-2233" };
  assert.deepEqual(validateJoin(ok, true, 2026), {});
  assert.equal(normalizePhone(ok.phone), "99112233");
  const bad = validateJoin({ ...ok, email: "x", pw2: "nope", name: "Бо1", year: "1990", phone: "123" }, true, 2026);
  assert.deepEqual(Object.keys(bad).sort(), ["email", "name", "phone", "pw2", "year"]);
  assert.deepEqual(validateJoin({ ...ok, email: "" }, false, 2026), {}); // signed-in users skip account fields
});

test("auth error mapping", () => {
  assert.equal(authErrorMessage("Invalid login credentials"), "И-мэйл эсвэл нууц үг буруу байна.");
  assert.equal(authErrorMessage("User already registered"), "Энэ и-мэйлээр бүртгэл үүссэн байна. Нэвтэрнэ үү.");
  assert.equal(authErrorMessage("other"), "other");
});
