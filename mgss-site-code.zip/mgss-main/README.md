# mgss2 — МГСС Төгсөгчдийн холбоо (Next.js)

Rewrite of `mgss1` (two bundled HTML files) as a Next.js app.

- **Next.js 16** (App Router, Server Components, Server Actions), Tailwind CSS v4
- **Supabase**: Auth (e-mail + password), Postgres with Row Level Security
- **Cloudflare R2**: photos (profile, New Year gallery, class photos)
- Hosting: **Vercel** (Supabase does not run Next.js servers)

The database schema is the **same as mgss1**, so mgss2 can point at the
existing Supabase project and all members, events, etc. keep working.

## Run locally

```bash
cp .env.example .env.local   # fill in values (see below)
npm install
npm run dev                  # http://localhost:3000
npm test                     # standings, schedule generator, validation
npm run build
```

## 1. Supabase

1. **SQL Editor** → paste `supabase/migrations/0001_mgss_schema.sql` → **Run**.
   It is safe to run on the existing mgss1 project (everything is guarded).
2. **Project Settings → API** → copy URL + anon key into `.env.local`
   (`NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`).
3. **Authentication → URL Configuration**
   - Site URL: your site, e.g. `https://mgss.mn`
   - Redirect URLs: `https://mgss.mn/**` and `http://localhost:3000/**`
4. **Authentication → Email Templates** (recommended, so links work on any device):
   - *Confirm signup*: link to
     `{{ .SiteURL }}/auth/confirm?token_hash={{ .TokenHash }}&type=email&next=/dashboard`
   - *Reset password*: link to
     `{{ .SiteURL }}/auth/confirm?token_hash={{ .TokenHash }}&type=recovery&next=/reset-password`

   (The default templates also work, but only in the browser that signed up.)
5. **Make an admin** (after that person has signed up):
   ```sql
   insert into admins (user_id) select id from auth.users where email = 'tanii@email.mn' on conflict do nothing;
   ```

## 2. Cloudflare R2 (photos)

1. R2 → **Create bucket** (e.g. `mgss-media`).
2. Bucket → **Settings → Public access**: connect a custom domain
   (e.g. `media.mgss.mn`) or enable the `r2.dev` URL.
   Put that URL in `NEXT_PUBLIC_MEDIA_BASE_URL` (no trailing slash).
3. R2 → **Manage API tokens** → create a token with *Object Read & Write* on the
   bucket. Put `R2_ACCOUNT_ID`, `R2_ACCESS_KEY_ID`, `R2_SECRET_ACCESS_KEY`,
   `R2_BUCKET` in `.env.local` (and in Vercel).
4. Optional: set a billing notification in Cloudflare (free tier = 10 GB).

How photos are stored:

| Photo | Resized in the browser to | Max upload | R2 key |
|---|---|---|---|
| Profile | 320×320, WebP q0.82 (~20–40 KB) | 1 MB | `avatars/<user_id>/<time>.webp` (old one deleted) |
| New Year gallery, class photos (admin) | longest side 1600 px, WebP q0.82 | 1 MB | `gallery/…`, `cohorts/…` |

The database stores only the **path**; the URL is built from
`NEXT_PUBLIC_MEDIA_BASE_URL`, so moving to another storage provider means
copying the files (`rclone`) and changing one setting. Old mgss1 values that are
full URLs (Supabase Storage, pasted links) still display as they are.

## 3. Deploy (Vercel)

Import the repo in Vercel, add all variables from `.env.example`
(+ `NEXT_PUBLIC_SITE_URL`), deploy. Then update the Supabase Site URL /
Redirect URLs to the real domain.

## Structure

```
src/
  proxy.ts                    refreshes the Supabase session cookie per request
  lib/
    data.ts                   all reads; strips hidden phones / contacts on the server
    content.ts                site_content JSON shapes + defaults (same as mgss1)
    sports.ts  format.ts      pure logic ported from mgss1 (tested in tests/)
    resize-image.ts           browser resize → WebP → POST /api/upload
    r2.ts  media.ts           R2 client, path → URL
  app/
    (site)/                   public pages: /, school, cohorts, network, events,
                              voice, jobs, join, login, reset-password, dashboard
    admin/                    11 tabs: overview, content, people, events, voices,
                              ny, sports, news, jobs, fund, cohorts
    actions/                  server actions (auth, member, admin)
    api/upload/route.ts       photo upload (auth, admin check, type sniffing, 1 MB cap)
    auth/confirm/route.ts     e-mail link landing (confirm sign-up, password reset)
supabase/migrations/          schema + RLS
```

## Changes from mgss1

- Every page has its own URL and is rendered on the server (good for sharing and SEO).
- Hidden phone numbers and job contacts never reach the browser (mgss1 only hid them visually).
- Admin saves one change at a time instead of re-syncing the whole site.
- The join form's profile is kept in the user's auth metadata until the
  e-mail is confirmed (mgss1 used localStorage, which broke across devices).
- No localStorage "demo mode" and no `admin2026` fallback password.
- Admin is granted by user id only (mgss1's schema granted it by matching a name).
- Photos moved from Supabase Storage to Cloudflare R2.
- Scroll-driven hero animations from mgss1 were simplified.
